import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

import { DataPipelineCard } from '@/components/DataPipelineCard'
import { AuditLogCard } from '@/components/station/AuditLogCard'
import { MembersCard } from '@/components/station/MembersCard'
import { NotificationsCard } from '@/components/station/NotificationsCard'
import { JoinStationCard } from '@/components/JoinStationCard'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { ErrorState, LoadingState } from '@/components/ui/States'
import { formatDateTime, formatInterval, formatValue } from '@/lib/format'
import { api } from '@/services/api'
import { queryKeys, useSettingsQuery } from '@/services/queries'
import { useIsAdmin, useStation } from '@/stations/StationContext'
import type { Settings } from '@/types/api'

const INTERVAL_OPTIONS = [2, 3, 5, 10, 30, 60, 300, 600, 1800, 3600]

interface FormState {
  name: string
  location: string
  readingIntervalSeconds: number
  pumpFlowLitersPerMinute: number
}

const toForm = (settings: Settings): FormState => ({
  name: settings.name,
  location: settings.location,
  readingIntervalSeconds: settings.readingIntervalSeconds,
  pumpFlowLitersPerMinute: settings.pumpFlowLitersPerMinute,
})

export function ConfigurationPage() {
  const station = useStation()
  const isAdmin = useIsAdmin()
  const queryClient = useQueryClient()
  const { data, isLoading, error, refetch } = useSettingsQuery(station.id)
  const [form, setForm] = useState<FormState | null>(null)
  const [message, setMessage] = useState<{ text: string; tone: 'ok' | 'error' } | null>(null)

  useEffect(() => {
    if (data && !form) setForm(toForm(data))
  }, [data, form])

  const save = useMutation({
    mutationFn: (values: FormState) => api.updateSettings(station.id, values),
    onSuccess: (updated) => {
      queryClient.setQueryData(queryKeys.settings(station.id), updated)
      void queryClient.invalidateQueries({ queryKey: queryKeys.stations })
      void queryClient.invalidateQueries({ queryKey: queryKeys.audit(station.id) })
      setForm(toForm(updated))
      setMessage({ text: 'Cambios guardados.', tone: 'ok' })
    },
    onError: (err) => setMessage({ text: err.message, tone: 'error' }),
  })

  if (isLoading) return <LoadingState label="Cargando configuración..." />
  if (error || !data || !form) return <ErrorState error={error} onRetry={() => void refetch()} />

  const intervals = INTERVAL_OPTIONS.includes(data.readingIntervalSeconds)
    ? INTERVAL_OPTIONS
    : [...INTERVAL_OPTIONS, data.readingIntervalSeconds].sort((a, b) => a - b)
  const { device } = data

  return (
    <div className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_360px]">
      <div className="space-y-4">
        <Card>
          <h2 className="text-xl font-semibold text-slate-900">Configuración general de la estación</h2>
          <p className="mt-1 text-sm text-slate-400">
            ID de la estación: <code className="text-slate-600">{data.code}</code>
          </p>
          {!isAdmin ? (
            <p className="mt-3 rounded-xl bg-slate-100 px-3 py-2 text-sm text-slate-600">
              Tienes acceso de <span className="font-medium">solo lectura</span> en esta estación. Pide a un administrador
              permisos para cambiar la configuración.
            </p>
          ) : null}
          <form
            className="mt-5"
            onSubmit={(event) => {
              event.preventDefault()
              setMessage(null)
              save.mutate(form)
            }}
          >
          <fieldset disabled={!isAdmin} className="space-y-4 disabled:opacity-70">
            <label className="block space-y-2">
              <span className="text-sm font-medium text-slate-500">Nombre de la estación IoT</span>
              <input
                required
                minLength={2}
                maxLength={80}
                className="w-full rounded-xl border border-slate-200 px-4 py-3"
                value={form.name}
                onChange={(event) => setForm({ ...form, name: event.target.value })}
              />
            </label>

            <label className="block space-y-2">
              <span className="text-sm font-medium text-slate-500">Ubicación / sector</span>
              <input
                maxLength={160}
                className="w-full rounded-xl border border-slate-200 px-4 py-3"
                value={form.location}
                placeholder="Ej. Invernadero 2, Campus"
                onChange={(event) => setForm({ ...form, location: event.target.value })}
              />
            </label>

            <div className="grid gap-4 md:grid-cols-2">
              <label className="block space-y-2">
                <span className="text-sm font-medium text-slate-500">Intervalo de medición y transmisión</span>
                <select
                  value={form.readingIntervalSeconds}
                  onChange={(event) => setForm({ ...form, readingIntervalSeconds: Number(event.target.value) })}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3"
                >
                  {intervals.map((seconds) => (
                    <option key={seconds} value={seconds}>
                      Cada {formatInterval(seconds)}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-slate-400">Se envía al ESP32 junto con la configuración de riego.</p>
              </label>

              <label className="block space-y-2">
                <span className="text-sm font-medium text-slate-500">Caudal de la bomba (L/min)</span>
                <input
                  type="number"
                  step="0.1"
                  min={0.1}
                  max={100}
                  required
                  className="w-full rounded-xl border border-slate-200 px-4 py-3"
                  value={Number.isNaN(form.pumpFlowLitersPerMinute) ? '' : form.pumpFlowLitersPerMinute}
                  onChange={(event) => setForm({ ...form, pumpFlowLitersPerMinute: event.target.valueAsNumber })}
                />
                <p className="text-xs text-slate-400">Se usa para estimar el agua consumida en cada riego.</p>
              </label>
            </div>

            {message ? (
              <p
                className={`rounded-xl px-4 py-3 text-sm ${
                  message.tone === 'ok' ? 'bg-emerald-50 text-green-800' : 'bg-red-50 text-red-700'
                }`}
              >
                {message.text}
              </p>
            ) : null}

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={save.isPending}
                className="rounded-xl bg-green-700 px-5 py-3 text-sm font-semibold text-white hover:bg-green-800 disabled:opacity-60"
              >
                {save.isPending ? 'Guardando...' : 'Guardar cambios'}
              </button>
              <button
                type="button"
                onClick={() => setForm(toForm(data))}
                className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-600"
              >
                Restaurar
              </button>
            </div>
          </fieldset>
          </form>
        </Card>

        <MembersCard />
        <AuditLogCard />
        <DataPipelineCard />
        <JoinStationCard />
      </div>

      <div className="space-y-4">
        <Card>
          <h2 className="text-xl font-semibold text-slate-900">Umbrales de riego automático</h2>
          <p className="mt-2 text-sm text-slate-500">
            Rango de humedad del suelo para la activación de la bomba.{' '}
            <Link to="/riego" className="font-medium text-green-700 underline">
              Modificar
            </Link>
          </p>

          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between rounded-2xl bg-amber-50 p-4">
              <div>
                <p className="font-semibold text-amber-700">Activación (mínimo)</p>
                <p className="text-sm text-amber-600">Enciende la bomba bajo:</p>
              </div>
              <p className="text-3xl font-semibold text-amber-600">{formatValue(data.irrigation.activationThreshold, '%')}</p>
            </div>

            <div className="flex items-center justify-between rounded-2xl bg-emerald-50 p-4">
              <div>
                <p className="font-semibold text-green-700">Desactivación (máximo)</p>
                <p className="text-sm text-green-600">Apaga la bomba al alcanzar:</p>
              </div>
              <p className="text-3xl font-semibold text-green-700">
                {formatValue(data.irrigation.deactivationThreshold, '%')}
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold text-slate-900">Estado del dispositivo</h2>
          <dl className="mt-5 space-y-4 text-sm">
            <DeviceRow label="Hardware controlador" value={device.hardware} />
            <div className="flex items-center justify-between gap-4">
              <dt className="text-slate-500">Estado de red</dt>
              <dd>
                <Badge tone={device.online ? 'success' : 'neutral'}>{device.online ? 'Conectado' : 'Sin conexión'}</Badge>
              </dd>
            </div>
            <DeviceRow label="Última comunicación" value={formatDateTime(device.lastSeenAt)} />
            <DeviceRow label="Dirección MAC" value={device.macAddress ?? '—'} />
            <DeviceRow label="Dirección IP" value={device.ipAddress ?? '—'} />
            <DeviceRow label="Señal WiFi" value={device.wifiRssi === null ? '—' : `${device.wifiRssi} dBm`} />
            <DeviceRow label="Firmware" value={device.firmware ?? '—'} />
          </dl>
        </Card>

        <NotificationsCard />
      </div>
    </div>
  )
}

function DeviceRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-right font-medium text-slate-800">{value}</dd>
    </div>
  )
}
