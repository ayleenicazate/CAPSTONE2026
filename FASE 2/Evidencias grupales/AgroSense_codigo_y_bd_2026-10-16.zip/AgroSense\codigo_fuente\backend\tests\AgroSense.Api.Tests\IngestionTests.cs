using System.Text.Json.Nodes;
using AgroSense.Api.Data;
using AgroSense.Api.Ingestion;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Time.Testing;

namespace AgroSense.Api.Tests;

public class ReadingParserTests
{
    private static readonly DateTimeOffset Now = new(2026, 10, 1, 12, 0, 0, TimeSpan.Zero);

    [Fact]
    public void Parses_documented_contract()
    {
        var node = JsonNode.Parse("""
            {"ts": 1790000000000, "temperature": 24.5, "airHumidity": 60, "soilMoisture": 41.2, "light": 75, "pumpOn": false}
            """);
        var reading = ReadingParser.Parse("k1", node, Now)!;
        Assert.Equal(DateTimeOffset.FromUnixTimeMilliseconds(1790000000000), reading.Timestamp);
        Assert.Equal(24.5, reading.Temperature);
        Assert.Equal(60, reading.AirHumidity);
        Assert.Equal(41.2, reading.SoilMoisture);
        Assert.Equal(75, reading.Light);
        Assert.False(reading.PumpOn);
    }

    [Fact]
    public void Accepts_seconds_strings_aliases_and_numeric_booleans()
    {
        var node = JsonNode.Parse("""{"ts": 1790000000, "temp": "21.3", "humidity": 55, "pump": 1, "pumpMode": "MANUAL"}""");
        var reading = ReadingParser.Parse("k1", node, Now)!;
        Assert.Equal(DateTimeOffset.FromUnixTimeSeconds(1790000000), reading.Timestamp);
        Assert.Equal(21.3, reading.Temperature);
        Assert.Equal(55, reading.AirHumidity);
        Assert.True(reading.PumpOn);
        Assert.Equal("manual", reading.PumpMode);
    }

    [Fact]
    public void Discards_out_of_range_values_like_failed_dht11_reads()
    {
        var node = JsonNode.Parse("""{"temperature": 2147483647, "airHumidity": -1, "soilMoisture": 40}""");
        var reading = ReadingParser.Parse("k1", node, Now)!;
        Assert.Null(reading.Temperature);
        Assert.Null(reading.AirHumidity);
        Assert.Equal(40, reading.SoilMoisture);
        Assert.Equal(Now, reading.Timestamp);
    }

    [Fact]
    public void Parses_real_firmware_payload_with_nested_sensors()
    {
        // Lectura real enviada por el ESP32 (firmware agrosense-sensors-1.0).
        var node = JsonNode.Parse("""
            {"airHumidity": 57.45, "mq135": {"adcVoltage": 3.134, "raw": 4095, "sensorVoltage": 4.701},
             "pumpMode": "auto", "pumpOn": false, "soilMoisture": 45.5625, "soilRaw": 2271,
             "spectral": {"blue": 66.36202, "green": 59.10643, "orange": 48.40526, "red": 50.02265,
                          "total": 350.35767, "violet": 65.31939, "yellow": 61.14194},
             "temperature": 23.26, "ts": 1791140183300}
            """);
        var reading = ReadingParser.Parse("k1", node, Now)!;
        Assert.Equal(23.26, reading.Temperature);
        Assert.Equal(45.56, reading.SoilMoisture);
        Assert.Equal(2271, reading.SoilRaw);
        Assert.Equal(4095, reading.AirQualityRaw);
        Assert.Equal(4.701, reading.AirQualityVoltage);
        Assert.NotNull(reading.Spectrum);
        Assert.Equal(65.32, reading.Spectrum.Violet);
        Assert.Equal(50.02, reading.Spectrum.Red);
        Assert.Equal(350.36, reading.Spectrum.Total);
        Assert.False(reading.PumpOn);
    }

    [Fact]
    public void Computes_spectral_total_when_missing()
    {
        var node = JsonNode.Parse("""{"spectral": {"violet": 1, "blue": 2, "green": 3, "yellow": 4, "orange": 5, "red": 6}}""");
        Assert.Equal(21, ReadingParser.Parse("k1", node, Now)!.Spectrum!.Total);
    }

    [Fact]
    public void Returns_null_when_no_variables_present()
    {
        Assert.Null(ReadingParser.Parse("k1", JsonNode.Parse("""{"ts": 1}"""), Now));
        Assert.Null(ReadingParser.Parse("k1", JsonNode.Parse("42"), Now));
    }
}

public class IngestionServiceTests
{
    private static readonly DateTimeOffset T0 = new(2026, 10, 1, 12, 0, 0, TimeSpan.Zero);

    private static (AgroSenseDbContext Db, IngestionService Service, Station Station) Setup() => Setup(new LiveBroadcaster());

    private static (AgroSenseDbContext Db, IngestionService Service, Station Station) Setup(LiveBroadcaster live)
    {
        var db = new AgroSenseDbContext(new DbContextOptionsBuilder<AgroSenseDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options);
        var station = new Station { Code = "test-01", Name = "Test" };
        db.Stations.Add(station);
        db.SaveChanges();
        var clock = new FakeTimeProvider(T0.AddHours(1));
        return (db, new IngestionService(db, new RollupService(db), live, clock, NullLogger<IngestionService>.Instance), station);
    }

    private static IncomingReading R(string key, int minute, double soil, bool? pump, string? mode = null) =>
        new(key, T0.AddMinutes(minute), 20, 50, soil, 60, pump, mode);

    [Fact]
    public async Task Derives_irrigation_event_from_pump_transitions()
    {
        var (db, service, station) = Setup();

        await service.IngestAsync(station, [R("a", 0, 35, false), R("b", 5, 29, true), R("c", 7, 61, false)]);

        var ev = Assert.Single(db.IrrigationEvents);
        Assert.Equal(T0.AddMinutes(5), ev.StartedAt);
        Assert.Equal(T0.AddMinutes(7), ev.EndedAt);
        Assert.Equal(29, ev.StartMoisture);
        Assert.Equal(61, ev.EndMoisture);
        Assert.Equal(IrrigationModes.Auto, ev.Mode);
        Assert.Equal(T0.AddMinutes(7), station.LastSeenAt);
    }

    [Fact]
    public async Task Event_spanning_batches_is_closed_later()
    {
        var (db, service, station) = Setup();

        await service.IngestAsync(station, [R("a", 0, 29, true, "manual")]);
        Assert.Null(Assert.Single(db.IrrigationEvents).EndedAt);

        await service.IngestAsync(station, [R("b", 3, 50, true), R("c", 4, 62, false)]);
        var ev = Assert.Single(db.IrrigationEvents);
        Assert.Equal(T0.AddMinutes(4), ev.EndedAt);
        Assert.Equal("manual", ev.Mode);
    }

    [Fact]
    public async Task Duplicate_source_keys_are_ignored()
    {
        var (db, service, station) = Setup();

        Assert.Equal(2, await service.IngestAsync(station, [R("a", 0, 40, false), R("b", 1, 39, false)]));
        Assert.Equal(1, await service.IngestAsync(station, [R("a", 0, 40, false), R("c", 2, 38, false)]));
        Assert.Equal(3, await db.Readings.CountAsync());
    }

    [Fact]
    public async Task Reingesting_fills_new_fields_without_duplicating()
    {
        var (db, service, station) = Setup();
        await service.IngestAsync(station, [R("a", 0, 40, false)]);

        var richer = R("a", 0, 40, false) with
        {
            SoilRaw = 2300,
            AirQualityRaw = 1500,
            AirQualityVoltage = 1.2,
            Spectrum = new Spectrum(1, 2, 3, 4, 5, 6, 21),
        };
        Assert.Equal(0, await service.IngestAsync(station, [richer]));

        var stored = Assert.Single(db.Readings);
        Assert.Equal(2300, stored.SoilRaw);
        Assert.Equal(1.2, stored.AirQualityVoltage);
        Assert.Equal(21, stored.SpectralTotal);
    }

    [Fact]
    public async Task Ingestion_maintains_minute_rollups()
    {
        var (db, service, station) = Setup();
        // Tres lecturas en el mismo minuto y una en el siguiente.
        await service.IngestAsync(station,
        [
            R("a", 0, 40, false) with { Timestamp = T0.AddSeconds(5), Temperature = 20 },
            R("b", 0, 38, true) with { Timestamp = T0.AddSeconds(25), Temperature = 22 },
            R("c", 0, 36, false) with { Timestamp = T0.AddSeconds(50), Temperature = 24, AirQualityRaw = 4095, AirQualityVoltage = 4.7 },
            R("d", 0, 35, false) with { Timestamp = T0.AddSeconds(65) },
        ]);

        var minutes = db.ReadingMinutes.OrderBy(m => m.Minute).ToList();
        Assert.Equal(2, minutes.Count);
        var first = minutes[0];
        Assert.Equal(T0, first.Minute);
        Assert.Equal(3, first.Count);
        Assert.Equal(1, first.PumpOnCount);
        Assert.Equal(22, first.TemperatureAvg);
        Assert.Equal(20, first.TemperatureMin);
        Assert.Equal(24, first.TemperatureMax);
        Assert.Equal(36, first.SoilMoistureMin);
        Assert.Null(first.AirQualityAvg); // la lectura saturada no cuenta

        // Una lectura tardía del mismo minuto actualiza el resumen existente.
        await service.IngestAsync(station, [R("e", 0, 30, false) with { Timestamp = T0.AddSeconds(55) }]);
        Assert.Equal(4, db.ReadingMinutes.Single(m => m.Minute == T0).Count);
        Assert.Equal(30, db.ReadingMinutes.Single(m => m.Minute == T0).SoilMoistureMin);
    }

    [Fact]
    public async Task New_readings_are_pushed_to_live_subscribers()
    {
        var live = new LiveBroadcaster();
        var (_, service, station) = Setup(live);
        var (id, reader) = live.Subscribe(station.Id);

        await service.IngestAsync(station, [R("a", 0, 40, false), R("b", 1, 39, true)]);
        // Una lectura repetida no se vuelve a emitir.
        await service.IngestAsync(station, [R("a", 0, 40, false)]);

        Assert.True(reader.TryRead(out var first));
        Assert.True(reader.TryRead(out var second));
        Assert.False(reader.TryRead(out _));
        Assert.Equal(40, first!.SoilMoisture);
        Assert.True(second!.PumpOn);

        live.Unsubscribe(station.Id, id);
        Assert.Equal(0, live.SubscriberCount(station.Id));
    }

    [Fact]
    public async Task Future_device_clock_does_not_push_last_seen_ahead()
    {
        var (_, service, station) = Setup();
        await service.IngestAsync(station, [R("a", 600, 40, false)]); // 10 h adelante
        Assert.Equal(T0.AddHours(1), station.LastSeenAt);
    }
}
