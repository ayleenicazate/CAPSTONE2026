# Despliegue en Hostinger (VPS)

Guía paso a paso para publicar AgroSense en internet con HTTPS.

```
Internet ──HTTPS──► Caddy (certificado automático)
                      ├── /      → frontend React
                      └── /api   → API .NET ──► PostgreSQL (no expuesto)
                                       ▲
ESP32 ──► Firebase ◄───────────────────┘
```

Todo corre en Docker con un solo comando. El ESP32 no cambia: sigue escribiendo en Firebase.

---

## Fase 0 – Qué comprar

### VPS
En Hostinger: **VPS → KVM 1** (1 vCPU, 4 GB RAM, 50 GB). Alcanza de sobra para el MVP. KVM 2 solo si
quieres más holgura.

Durante la compra / configuración inicial:
- **Sistema operativo:** *Ubuntu 24.04 with Docker* (en "Aplicaciones" o "SO con panel"). Si no aparece,
  elige **Ubuntu 24.04** a secas; Docker se instala en la fase 2.
- **Ubicación del servidor:** la más cercana a Chile (por ejemplo **Brasil**), para menor latencia.
- **Contraseña root:** una fuerte; guárdala en tu gestor de contraseñas.
- **Clave SSH:** recomendado, ver fase 1.

### Dominio (opcional, pero recomendado)
Sin dominio no hay HTTPS: las contraseñas viajarían sin cifrar. Opciones:
- **.cl:** se compra en [nic.cl](https://www.nic.cl).
- **.com / otros:** en Hostinger (a veces viene gratis el primer año con planes anuales).

Revisa los precios vigentes en cada sitio antes de comprar.

---

## Fase 1 – Conectarte al servidor desde Windows

En **PowerShell** de tu PC:

```powershell
# 1. Crear una clave SSH (Enter a todo; opcionalmente pon una frase de paso)
ssh-keygen -t ed25519 -C "jo.gallardoj@duocuc.cl"

# 2. Mostrar la clave pública para copiarla
type $env:USERPROFILE\.ssh\id_ed25519.pub
```

En **hPanel → VPS → (tu servidor) → Configuración → Claves SSH → Agregar**, pega esa línea.

Luego conéctate (la IP aparece en la página del VPS):

```powershell
ssh root@IP_DEL_VPS
```

Todos los comandos siguientes se ejecutan **dentro del servidor**.

---

## Fase 2 – Preparar el servidor

```bash
apt update && apt upgrade -y

# Solo si elegiste Ubuntu sin Docker:
curl -fsSL https://get.docker.com | sh

docker --version          # debe mostrar una versión
docker compose version

# Firewall: solo SSH, HTTP y HTTPS
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443
ufw --force enable
```

Si en hPanel tienes activado el **Firewall del VPS**, abre ahí también los puertos 22, 80 y 443.

---

## Fase 3 – Apuntar el dominio al servidor (si compraste uno)

En el panel DNS de tu dominio (Hostinger o NIC Chile), crea dos registros **A**:

| Tipo | Nombre | Valor          |
|------|--------|----------------|
| A    | `@`    | `IP_DEL_VPS`   |
| A    | `www`  | `IP_DEL_VPS`   |

Borra cualquier otro registro A o AAAA de `@` / `www` que venga por defecto (por ejemplo, el de un
"parking"). La propagación tarda de minutos a pocas horas. Comprueba desde tu PC:

```powershell
nslookup tudominio.cl
```

Cuando responda con la IP del VPS, sigue.

---

## Fase 4 – Instalar AgroSense

### 4.1 Descargar el código

```bash
cd /opt
git clone https://github.com/ayleenicazate/AgroSense.git agrosense
cd agrosense
git checkout feature/backend-dotnet     # o main, si ya se fusionó la rama
```

### 4.2 Configuración de producción

```bash
cp deploy/env.prod.example .env.prod

# Generar secretos (copia cada resultado)
openssl rand -hex 24    # → POSTGRES_PASSWORD
openssl rand -hex 48    # → JWT_SIGNING_KEY

nano .env.prod
```

Completa en `.env.prod`:

| Variable | Con dominio | Sin dominio |
|---|---|---|
| `SITE_ADDRESS` | `tudominio.cl, www.tudominio.cl` | `:80` |
| `PUBLIC_URL` | `https://tudominio.cl` | `http://IP_DEL_VPS` |
| `POSTGRES_PASSWORD` | el primer `openssl` | igual |
| `JWT_SIGNING_KEY` | el segundo `openssl` | igual |
| `REGISTRATION_CODE` | un código que inventes, por ejemplo `agro-capstone-2026` | igual |
| `FIREBASE_DATABASE_URL` | `https://agrosense-a1b2c-default-rtdb.firebaseio.com` | igual |

Guarda con `Ctrl+O`, `Enter`, y sal con `Ctrl+X`.

> El `REGISTRATION_CODE` evita que cualquier persona de internet cree una cuenta y controle la bomba.
> Compártelo solo con tu equipo.

### 4.3 Subir la cuenta de servicio de Firebase

Desde **PowerShell en tu PC** (no en el servidor):

```powershell
ssh root@IP_DEL_VPS "mkdir -p /opt/agrosense/secrets"
scp C:\Users\johan\secretos\agrosense-a1b2c-firebase-adminsdk-fbsvc-5467c1ba95.json root@IP_DEL_VPS:/opt/agrosense/secrets/firebase.json
```

De vuelta en el servidor:

```bash
chmod 600 /opt/agrosense/secrets/firebase.json
```

### 4.4 Levantar todo

```bash
cd /opt/agrosense
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build
```

La primera vez tarda varios minutos (compila el backend y el frontend). Después:

```bash
docker compose -f docker-compose.prod.yml --env-file .env.prod ps     # todos "running"/"healthy"
docker compose -f docker-compose.prod.yml --env-file .env.prod logs -f api
```

En los logs de `api` debe aparecer `Ingesta desde Firebase activa`. Sal de los logs con `Ctrl+C`.

### 4.5 Comprobar

- `https://tudominio.cl/api/health` → `{"status":"ok","database":true,"firebase":true}`
- `https://tudominio.cl` → pantalla de login.

---

## Fase 5 – Primer uso

1. Entra a la web → **Regístrate aquí**.
2. Ingresa el **código de invitación** (`REGISTRATION_CODE`).
3. Deja vacío el *ID de estación*: quedarás vinculado a `agrosense-01`, la estación del ESP32.
4. Comparte la URL y el código con tu equipo para que creen sus cuentas.

En producción no hay usuario demo ni datos sintéticos: solo verás lo que envíe el ESP32.

> Cuando producción esté en marcha, **no corras la API local conectada al mismo Firebase**
> (borra o renombra tu `docker-compose.override.yml` local), para que haya un solo backend publicando la
> configuración de riego.

---

## Mantenimiento

### Actualizar a una nueva versión

```bash
cd /opt/agrosense
git pull
docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build
```

Las migraciones de base de datos se aplican solas al arrancar.

### Respaldos

Se genera uno diario en `/opt/agrosense/backups` (se guardan 14 días). Para descargarlos a tu PC:

```powershell
scp -r root@IP_DEL_VPS:/opt/agrosense/backups .
```

Restaurar un respaldo (reemplaza los datos actuales):

```bash
cd /opt/agrosense
docker compose -f docker-compose.prod.yml --env-file .env.prod exec -T postgres \
  pg_restore -U agrosense -d agrosense --clean --if-exists < backups/agrosense-AAAA-MM-DD.dump
```

### Recuperación de contraseña

No hay servidor de correo configurado: el enlace para restablecer contraseña aparece en los logs de la
API. El administrador lo copia y se lo envía a la persona:

```bash
docker compose -f docker-compose.prod.yml --env-file .env.prod logs api | grep restablecer
```

---

## Problemas frecuentes

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| El navegador dice que el certificado no es válido | El DNS aún no apunta al VPS, o los puertos 80/443 están cerrados | `nslookup`, revisar firewall (ufw y hPanel), luego `docker compose ... restart web` |
| Error 502 en `/api` | La API no arrancó | `docker compose ... logs api` |
| `firebase: false` en `/api/health` | Falta `FIREBASE_DATABASE_URL` en `.env.prod` | Completar y volver a `up -d` |
| Error de credenciales de Firebase en los logs | `secrets/firebase.json` no existe o está mal | Repetir paso 4.3 |
| "Falta X en .env.prod" al levantar | Variable vacía | Completar `.env.prod` |
