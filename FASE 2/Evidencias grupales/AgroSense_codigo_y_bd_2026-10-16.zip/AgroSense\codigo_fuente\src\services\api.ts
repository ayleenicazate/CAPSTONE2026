import type {
  AnalyticsData,
  AuditEntry,
  AuthResponse,
  Member,
  NotificationSettings,
  StationRole,
  TelegramLink,
  HeatmapData,
  HistoryData,
  LiveData,
  SystemStatus,
  HistoryRange,
  IrrigationData,
  SensorsData,
  Settings,
  StationInfo,
  Summary,
  User,
  VariableKey,
} from '@/types/api'

export const apiBaseUrl = import.meta.env.VITE_API_URL ?? '/api'

export const TOKEN_KEY = 'agrosense.token'

export class ApiError extends Error {
  readonly status: number

  constructor(status: number, message: string) {
    super(message)
    this.status = status
  }
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY) ?? sessionStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string | null, remember = true) {
  localStorage.removeItem(TOKEN_KEY)
  sessionStorage.removeItem(TOKEN_KEY)
  if (token) (remember ? localStorage : sessionStorage).setItem(TOKEN_KEY, token)
}

let onUnauthorized: (() => void) | null = null

/** El AuthProvider registra aquí qué hacer cuando la sesión expira (401). */
export function setUnauthorizedHandler(handler: (() => void) | null) {
  onUnauthorized = handler
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken()
  const headers = new Headers(init.headers)
  if (init.body) headers.set('Content-Type', 'application/json')
  if (token) headers.set('Authorization', `Bearer ${token}`)

  let response: Response
  try {
    response = await fetch(`${apiBaseUrl}${path}`, { ...init, headers })
  } catch {
    throw new ApiError(0, 'No se pudo conectar con el servidor. ¿Está corriendo el backend?')
  }

  if (response.status === 401 && token) onUnauthorized?.()

  if (!response.ok) {
    throw new ApiError(response.status, await readError(response))
  }

  if (response.status === 202 || response.status === 204) return undefined as T
  return (await response.json()) as T
}

async function readError(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { detail?: string; title?: string }
    if (body.detail) return body.detail
    if (body.title) return body.title
  } catch {
    // respuesta sin cuerpo JSON
  }
  if (response.status === 429) return 'Demasiados intentos. Espera un minuto e inténtalo de nuevo.'
  return `El servidor respondió ${response.status}.`
}

const json = (body: unknown) => JSON.stringify(body)

export const api = {
  // ---- Autenticación
  login: (email: string, password: string, remember: boolean) =>
    request<AuthResponse>('/auth/login', { method: 'POST', body: json({ email, password, remember }) }),
  authOptions: () => request<{ inviteRequired: boolean }>('/auth/options'),
  register: (name: string, email: string, password: string, stationCode?: string, inviteCode?: string) =>
    request<AuthResponse>('/auth/register', {
      method: 'POST',
      body: json({ name, email, password, stationCode: stationCode || null, inviteCode: inviteCode || null }),
    }),
  me: () => request<User>('/auth/me'),
  forgotPassword: (email: string) =>
    request<void>('/auth/forgot-password', { method: 'POST', body: json({ email }) }),
  resetPassword: (email: string, token: string, newPassword: string) =>
    request<void>('/auth/reset-password', { method: 'POST', body: json({ email, token, newPassword }) }),

  // ---- Estaciones
  stations: () => request<StationInfo[]>('/stations'),
  joinStation: (code: string) => request<StationInfo>('/stations/join', { method: 'POST', body: json({ code }) }),
  summary: (stationId: string) => request<Summary>(`/stations/${stationId}/summary`),
  sensors: (stationId: string, hours: number) => request<SensorsData>(`/stations/${stationId}/sensors?hours=${hours}`),
  history: (stationId: string, variable: VariableKey, range: HistoryRange) =>
    request<HistoryData>(`/stations/${stationId}/history?variable=${variable}&range=${range}`),
  live: (stationId: string, minutes: number) => request<LiveData>(`/stations/${stationId}/live?minutes=${minutes}`),
  heatmap: (stationId: string, variable: VariableKey, days: number) =>
    request<HeatmapData>(`/stations/${stationId}/heatmap?variable=${variable}&days=${days}`),
  systemStatus: () => request<SystemStatus>('/system/status'),
  analytics: (stationId: string) => request<AnalyticsData>(`/stations/${stationId}/analytics`),

  // ---- Miembros, registro de acciones y notificaciones
  members: (stationId: string) => request<Member[]>(`/stations/${stationId}/members`),
  updateMember: (stationId: string, userId: string, role: StationRole) =>
    request<void>(`/stations/${stationId}/members/${userId}`, { method: 'PUT', body: json({ role }) }),
  removeMember: (stationId: string, userId: string) =>
    request<void>(`/stations/${stationId}/members/${userId}`, { method: 'DELETE' }),
  audit: (stationId: string, take = 100) => request<AuditEntry[]>(`/stations/${stationId}/audit?take=${take}`),
  notifications: (stationId: string) => request<NotificationSettings>(`/stations/${stationId}/notifications`),
  updateNotifications: (
    stationId: string,
    body: { enabled: boolean; alertSoilDry: boolean; alertOffline: boolean; alertPumpLong: boolean },
  ) => request<NotificationSettings>(`/stations/${stationId}/notifications`, { method: 'PUT', body: json(body) }),
  updateMyNotifications: (stationId: string, emailAlerts: boolean) =>
    request<void>(`/stations/${stationId}/notifications/me`, { method: 'PUT', body: json({ emailAlerts }) }),
  linkTelegram: (stationId: string) =>
    request<TelegramLink>(`/stations/${stationId}/notifications/telegram/link`, { method: 'POST' }),
  unlinkTelegram: (stationId: string) =>
    request<void>(`/stations/${stationId}/notifications/telegram`, { method: 'DELETE' }),
  testNotification: (stationId: string) =>
    request<{ telegram: boolean; emails: number }>(`/stations/${stationId}/notifications/test`, { method: 'POST' }),
  irrigation: (stationId: string) => request<IrrigationData>(`/stations/${stationId}/irrigation`),
  updateIrrigation: (
    stationId: string,
    body: { autoIrrigation: boolean; activationThreshold: number; deactivationThreshold: number; maxPumpSeconds: number },
  ) => request<IrrigationData>(`/stations/${stationId}/irrigation`, { method: 'PUT', body: json(body) }),
  manualPump: (stationId: string, on: boolean) =>
    request<IrrigationData>(`/stations/${stationId}/irrigation/manual`, { method: 'POST', body: json({ on }) }),
  settings: (stationId: string) => request<Settings>(`/stations/${stationId}/settings`),
  updateSettings: (
    stationId: string,
    body: { name: string; location: string; readingIntervalSeconds: number; pumpFlowLitersPerMinute: number },
  ) => request<Settings>(`/stations/${stationId}/settings`, { method: 'PUT', body: json(body) }),

  /** Descarga el CSV con las lecturas del rango (requiere el token, por eso no es un simple enlace). */
  async downloadCsv(stationId: string, range: HistoryRange, fileName: string) {
    const response = await fetch(`${apiBaseUrl}/stations/${stationId}/history/export?range=${range}`, {
      headers: { Authorization: `Bearer ${getToken() ?? ''}` },
    })
    if (!response.ok) throw new ApiError(response.status, await readError(response))
    const url = URL.createObjectURL(await response.blob())
    const link = document.createElement('a')
    link.href = url
    link.download = fileName
    link.click()
    URL.revokeObjectURL(url)
  },
}
