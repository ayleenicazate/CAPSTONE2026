using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Metrics;
using Google.Cloud.BigQuery.V2;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.DataExport;

/// <summary>
/// Pronósticos con BigQuery ML: entrena periódicamente un modelo ARIMA_PLUS por variable sobre el histórico
/// por hora (últimos 30 días, todas las estaciones como series separadas) y guarda en PostgreSQL el pronóstico
/// de 48 h con su intervalo de confianza del 90 %. También crea las vistas usadas por Looker Studio.
/// </summary>
public class BigQueryMlService(
    IServiceScopeFactory scopes,
    BigQueryClientFactory bigQuery,
    IOptions<BigQueryOptions> options,
    TimeProvider clock,
    ILogger<BigQueryMlService> logger) : BackgroundService
{
    /// <summary>Horas con datos necesarias para entrenar (al menos dos ciclos diarios).</summary>
    public const int MinTrainingHours = 48;
    public const int HorizonHours = 48;
    public const string Zone = "America/Santiago";

    /// <summary>Variable del panel → expresión SQL sobre la tabla readings de BigQuery.</summary>
    public static readonly IReadOnlyDictionary<string, string> Columns = new Dictionary<string, string>
    {
        [Variables.Temperature] = "temperature",
        [Variables.AirHumidity] = "air_humidity",
        [Variables.SoilMoisture] = "soil_moisture",
        [Variables.Light] = "light_total",
        [Variables.AirQuality] = "IF(air_quality_saturated, NULL, air_quality_voltage)",
    };

    private readonly BigQueryOptions _options = options.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!_options.Enabled) return;

        // Deja que la exportación inicial termine antes del primer entrenamiento.
        await Task.Delay(TimeSpan.FromMinutes(2), clock, stoppingToken);
        var viewsReady = false;

        using var timer = new PeriodicTimer(TimeSpan.FromHours(Math.Max(1, _options.MlRetrainHours)));
        do
        {
            try
            {
                if (!viewsReady)
                {
                    await EnsureViewsAsync(stoppingToken);
                    viewsReady = true;
                }
                await TrainAllAsync(stoppingToken);
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Error en BigQuery ML; se reintentará en el próximo ciclo");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    /// <summary>Vistas resumidas (diaria y por hora, en hora de Chile) pensadas para Looker Studio y el análisis.</summary>
    public async Task EnsureViewsAsync(CancellationToken ct)
    {
        var readings = bigQuery.Table(BigQueryExporter.ReadingsTable);
        var events = bigQuery.Table(BigQueryExporter.EventsTable);

        await bigQuery.QueryAsync($"""
            CREATE OR REPLACE VIEW {bigQuery.Table("daily_summary")} AS
            WITH r AS (
              SELECT station_code, DATE(ts, '{Zone}') AS day, COUNT(*) AS readings,
                AVG(temperature) AS temperature_avg, MIN(temperature) AS temperature_min, MAX(temperature) AS temperature_max,
                AVG(air_humidity) AS air_humidity_avg,
                AVG(soil_moisture) AS soil_moisture_avg, MIN(soil_moisture) AS soil_moisture_min, MAX(soil_moisture) AS soil_moisture_max,
                AVG(light_total) AS light_avg, MAX(light_total) AS light_max,
                AVG(IF(air_quality_saturated, NULL, air_quality_voltage)) AS air_quality_avg
              FROM {readings}
              GROUP BY station_code, day
            ),
            e AS (
              SELECT station_code, DATE(started_at, '{Zone}') AS day, COUNT(*) AS irrigations,
                SUM(duration_seconds) / 60 AS irrigation_minutes, SUM(water_liters) AS water_liters
              FROM {events}
              GROUP BY station_code, day
            )
            SELECT r.*, IFNULL(e.irrigations, 0) AS irrigations,
              IFNULL(e.irrigation_minutes, 0) AS irrigation_minutes, IFNULL(e.water_liters, 0) AS water_liters
            FROM r LEFT JOIN e USING (station_code, day)
            """, ct: ct);

        await bigQuery.QueryAsync($"""
            CREATE OR REPLACE VIEW {bigQuery.Table("hourly_summary")} AS
            SELECT station_code,
              TIMESTAMP_TRUNC(ts, HOUR) AS hour_utc,
              DATETIME(TIMESTAMP_TRUNC(ts, HOUR), '{Zone}') AS hour_local,
              EXTRACT(HOUR FROM DATETIME(ts, '{Zone}')) AS hour_of_day,
              COUNT(*) AS readings,
              AVG(temperature) AS temperature, AVG(air_humidity) AS air_humidity,
              AVG(soil_moisture) AS soil_moisture, AVG(light_total) AS light,
              AVG(IF(air_quality_saturated, NULL, air_quality_voltage)) AS air_quality,
              LOGICAL_OR(IFNULL(pump_on, FALSE)) AS pump_on
            FROM {readings}
            GROUP BY station_code, hour_utc, hour_local, hour_of_day
            """, ct: ct);

        logger.LogInformation("BigQuery: vistas daily_summary y hourly_summary listas");
    }

    public async Task TrainAllAsync(CancellationToken ct)
    {
        foreach (var variable in Columns.Keys)
        {
            await TrainAsync(variable, ct);
        }
    }

    private async Task TrainAsync(string variable, CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
        var run = await db.MlModelRuns.FindAsync([variable], ct);
        if (run is null)
        {
            run = new MlModelRun { Variable = variable, Status = "pending" };
            db.MlModelRuns.Add(run);
        }
        run.RunAt = clock.GetUtcNow();

        var column = Columns[variable];
        var readings = bigQuery.Table(BigQueryExporter.ReadingsTable);
        var model = bigQuery.Table($"forecast_{variable.ToLowerInvariant()}");
        var trainingData = $"""
            SELECT station_code, TIMESTAMP_TRUNC(ts, HOUR) AS hour, AVG({column}) AS value
            FROM {readings}
            WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY) AND {column} IS NOT NULL
            GROUP BY station_code, hour
            """;

        try
        {
            // Solo se entrenan las estaciones con suficientes horas de datos (al menos dos ciclos diarios).
            var (counts, _) = await bigQuery.QueryAsync(
                $"SELECT station_code, COUNT(*) AS n FROM ({trainingData}) GROUP BY station_code", ct: ct);
            var hoursByStation = counts.ToDictionary(r => (string)r["station_code"], r => Convert.ToInt32(r["n"]));
            var qualified = hoursByStation.Where(kv => kv.Value >= MinTrainingHours).Select(kv => kv.Key).ToList();
            run.TrainingPoints = qualified.Sum(code => hoursByStation[code]);

            if (qualified.Count == 0)
            {
                run.Status = "insufficient_data";
                run.Message = $"Ninguna estación tiene al menos {MinTrainingHours} horas con datos en los últimos 30 días "
                    + $"(máximo: {(hoursByStation.Count == 0 ? 0 : hoursByStation.Values.Max())}).";
                await db.MlForecasts.Where(f => f.Variable == variable).ExecuteDeleteAsync(ct);
                await db.SaveChangesAsync(ct);
                return;
            }

            var stationFilter = string.Join(", ", qualified.Select(code => $"'{code.Replace("'", "")}'"));
            await bigQuery.QueryAsync($"""
                CREATE OR REPLACE MODEL {model}
                OPTIONS (
                  model_type = 'ARIMA_PLUS',
                  time_series_timestamp_col = 'hour',
                  time_series_data_col = 'value',
                  time_series_id_col = 'station_code',
                  data_frequency = 'HOURLY',
                  clean_spikes_and_dips = TRUE
                ) AS
                SELECT * FROM ({trainingData}) WHERE station_code IN ({stationFilter})
                """, ct: ct);
            var trainedAt = clock.GetUtcNow();

            var (evaluation, _) = await bigQuery.QueryAsync(
                $"SELECT * FROM ML.ARIMA_EVALUATE(MODEL {model})", ct: ct);
            var descriptions = evaluation.ToDictionary(r => (string)r["station_code"], r => Describe(r));

            var (forecast, _) = await bigQuery.QueryAsync($"""
                SELECT station_code, forecast_timestamp, forecast_value,
                  prediction_interval_lower_bound AS lower_bound, prediction_interval_upper_bound AS upper_bound
                FROM ML.FORECAST(MODEL {model}, STRUCT({HorizonHours} AS horizon, 0.9 AS confidence_level))
                """, ct: ct);

            var stations = await db.Stations.AsNoTracking().ToDictionaryAsync(s => s.Code, s => s.Id, ct);
            var (min, max) = Bounds(variable);
            var points = new List<MlForecast>();
            foreach (var row in forecast)
            {
                var code = (string)row["station_code"];
                if (!stations.TryGetValue(code, out var stationId)) continue;
                points.Add(new MlForecast
                {
                    StationId = stationId,
                    Variable = variable,
                    Timestamp = new DateTimeOffset(DateTime.SpecifyKind((DateTime)row["forecast_timestamp"], DateTimeKind.Utc)),
                    Value = Clamp((double)row["forecast_value"], min, max),
                    Lower = row["lower_bound"] is double lo ? Clamp(lo, min, max) : null,
                    Upper = row["upper_bound"] is double hi ? Clamp(hi, min, max) : null,
                    TrainedAt = trainedAt,
                    Model = descriptions.GetValueOrDefault(code),
                    TrainingHours = hoursByStation.GetValueOrDefault(code),
                });
            }

            await db.MlForecasts.Where(f => f.Variable == variable).ExecuteDeleteAsync(ct);
            db.MlForecasts.AddRange(points);
            run.Status = "ok";
            run.TrainedAt = trainedAt;
            run.Description = $"{qualified.Count} estación(es) entrenada(s)";
            run.Message = null;
            await db.SaveChangesAsync(ct);
            logger.LogInformation("BigQuery ML: modelo {Variable} entrenado para {Stations} ({Models}); {Points} puntos de pronóstico",
                variable, string.Join(", ", qualified), string.Join(" | ", descriptions.Select(d => $"{d.Key}: {d.Value}")), points.Count);
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            logger.LogWarning(ex, "BigQuery ML: no se pudo entrenar el modelo {Variable}", variable);
            run.Status = "error";
            run.Message = ex.Message.Length > 1900 ? ex.Message[..1900] : ex.Message;
            await db.SaveChangesAsync(ct);
        }
    }

    /// <summary>Describe el modelo elegido automáticamente, por ejemplo "ARIMA(2,1,1) · estacionalidad diaria".</summary>
    private static string? Describe(BigQueryRow? row)
    {
        if (row is null) return null;
        string Field(string name)
        {
            try { return row[name]?.ToString() ?? "?"; }
            catch (KeyNotFoundException) { return "?"; }
        }

        var description = $"ARIMA({Field("non_seasonal_p")},{Field("non_seasonal_d")},{Field("non_seasonal_q")})";
        try
        {
            if (row["seasonal_periods"] is string[] periods && periods.Length > 0)
            {
                var names = periods.Where(p => p != "NO_SEASONALITY").Select(p => p switch
                {
                    "DAILY" => "diaria",
                    "WEEKLY" => "semanal",
                    "MONTHLY" => "mensual",
                    _ => p.ToLowerInvariant(),
                }).ToList();
                description += names.Count > 0 ? $" · estacionalidad {string.Join(", ", names)}" : " · sin estacionalidad";
            }
        }
        catch (KeyNotFoundException)
        {
            // Columna no presente en esta versión de BigQuery ML.
        }
        return description;
    }

    private static (double? Min, double? Max) Bounds(string variable) => variable switch
    {
        Variables.AirHumidity or Variables.SoilMoisture => (0, 100),
        Variables.Light or Variables.AirQuality => (0, null),
        _ => (null, null),
    };

    private static double Clamp(double value, double? min, double? max)
    {
        if (min is not null && value < min) value = min.Value;
        if (max is not null && value > max) value = max.Value;
        return Math.Round(value, 3);
    }
}
