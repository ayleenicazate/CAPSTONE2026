import { Download } from 'lucide-react'
import { useState } from 'react'

import { MetricCard } from '@/components/MetricCard'
import { Heatmap } from '@/components/charts/Heatmap'
import { TrendChart, type TrendPoint } from '@/components/charts/TrendChart'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States'
import { formatDateTime, formatNumber, formatValue } from '@/lib/format'
import { api } from '@/services/api'
import { useHeatmapQuery, useHistoryQuery } from '@/services/queries'
import { useStation } from '@/stations/StationContext'
import type { HistoryData, HistoryRange, VariableKey } from '@/types/api'

const RANGES: Array<{ value: HistoryRange; label: string }> = [
  { value: '1h', label: '1 hora' },
  { value: '24h', label: '24 horas' },
  { value: '7d', label: '7 días' },
  { value: '30d', label: '30 días' },
]

const BUCKET_LABEL: Record<string, string> = {
  minute: 'Promedio por minuto',
  '15min': 'Promedio cada 15 minutos',
  '2h': 'Promedio cada 2 horas',
  '6h': 'Promedio cada 6 horas',
}

const HEATMAP_DAYS = [7, 14, 30]

const VARIABLES: Array<{ key: VariableKey; label: string }> = [
  { key: 'temperature', label: 'Temperatura' },
  { key: 'airHumidity', label: 'Humedad ambiental' },
  { key: 'soilMoisture', label: 'Humedad del suelo' },
  { key: 'light', label: 'Luz (AS7262)' },
  { key: 'airQuality', label: 'Calidad del aire (MQ135)' },
]

export function HistoryPage() {
  const station = useStation()
  const [variable, setVariable] = useState<VariableKey>('temperature')
  const [range, setRange] = useState<HistoryRange>('24h')
  const [exportError, setExportError] = useState('')
  const [heatmapDays, setHeatmapDays] = useState(14)
  const { data, isLoading, error, refetch, isFetching } = useHistoryQuery(station.id, variable, range)
  const heatmap = useHeatmapQuery(station.id, variable, heatmapDays)

  async function handleExport() {
    setExportError('')
    try {
      await api.downloadCsv(station.id, range, `${station.code}-${range}.csv`)
    } catch (err) {
      setExportError(err instanceof Error ? err.message : 'No se pudo exportar.')
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2">
              <span className="text-sm font-medium text-slate-500">Variable</span>
              <select
                value={variable}
                onChange={(event) => setVariable(event.target.value as VariableKey)}
                className="w-full rounded-xl border border-slate-200 px-4 py-3"
              >
                {VARIABLES.map((item) => (
                  <option key={item.key} value={item.key}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>

            <div className="space-y-2">
              <span className="text-sm font-medium text-slate-500">Rango de tiempo</span>
              <div className="flex flex-wrap gap-2">
                {RANGES.map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setRange(item.value)}
                    className={`rounded-xl px-4 py-3 text-sm font-medium ${
                      range === item.value
                        ? 'border border-green-700 bg-emerald-50 text-green-800'
                        : 'border border-slate-200 bg-white text-slate-500'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start gap-2 xl:items-end">
            <button
              type="button"
              onClick={() => void handleExport()}
              className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-600 hover:bg-slate-50"
            >
              <Download size={16} />
              Exportar CSV ({RANGES.find((item) => item.value === range)?.label})
            </button>
            {exportError ? <p className="text-sm text-red-600">{exportError}</p> : null}
          </div>
        </div>
      </Card>

      {isLoading && !data ? <LoadingState label="Cargando historial..." /> : null}
      {error && !data ? <ErrorState error={error} onRetry={() => void refetch()} /> : null}
      {data ? <HistoryContent data={data} range={range} refreshing={isFetching} /> : null}

      {heatmap.data ? (
        <Heatmap
          data={heatmap.data}
          title={`${heatmap.data.variable.label} por día y hora`}
          actions={
            <div className="flex gap-2">
              {HEATMAP_DAYS.map((days) => (
                <button
                  key={days}
                  type="button"
                  onClick={() => setHeatmapDays(days)}
                  className={`rounded-lg px-3 py-1.5 text-sm font-medium ${
                    heatmapDays === days
                      ? 'border border-green-700 bg-emerald-50 text-green-800'
                      : 'border border-slate-200 text-slate-500'
                  }`}
                >
                  {days} días
                </button>
              ))}
            </div>
          }
        />
      ) : null}
    </div>
  )
}

function HistoryContent({ data, range, refreshing }: { data: HistoryData; range: HistoryRange; refreshing: boolean }) {
  const { unit, label } = data.variable
  const { stats } = data

  const points: TrendPoint[] = [
    ...data.series.map((point) => ({ timestamp: point.timestamp, value: point.average, min: point.min, max: point.max })),
    ...data.forecast.map((point) => ({
      timestamp: point.timestamp,
      forecast: point.value,
      forecastLow: point.lower ?? undefined,
      forecastHigh: point.upper ?? undefined,
    })),
  ]
  // Une la línea estimada con el último valor medido para que no quede un hueco.
  const lastMeasured = data.series.at(-1)
  if (lastMeasured && data.forecast.length > 0) {
    points[data.series.length - 1] = { ...points[data.series.length - 1], forecast: lastMeasured.average }
  }

  // En 24 h el ciclo día/noche domina y una recta no representa una tendencia real.
  const trend = range === '24h' || range === '1h' ? null : (stats?.trendPerDay ?? null)

  return (
    <div className={`space-y-4 transition-opacity ${refreshing ? 'opacity-70' : ''}`}>
      <TrendChart
        title={`${label} – ${RANGES.find((item) => item.value === range)?.label.toLowerCase()}`}
        subtitle={[
          BUCKET_LABEL[data.bucket],
          data.forecastMethod ? `Pronóstico${data.forecastSource === 'bigquery-ml' ? ' (machine learning)' : ''}: ${data.forecastMethod}` : null,
        ]
          .filter(Boolean)
          .join(' · ')}
        data={points}
        unit={unit}
        height={300}
        axis={range === '1h' || range === '24h' ? 'time' : 'date'}
        digits={unit === 'V' ? 2 : unit === 'µW/cm²' ? 0 : 1}
        domain={unit === '%' ? [0, 100] : ['auto', 'auto']}
        seriesLabel={label}
      />

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Promedio del período" value={formatValue(stats?.average, unit)} footer={`${stats?.count ?? 0} lecturas`} />
        <MetricCard label="Mínimo" value={formatValue(stats?.min, unit)} footer={stats ? formatDateTime(stats.minAt) : null} />
        <MetricCard label="Máximo" value={formatValue(stats?.max, unit)} footer={stats ? formatDateTime(stats.maxAt) : null} />
        <MetricCard
          label="Tendencia"
          value={trend === null ? '—' : `${trend > 0 ? '+' : ''}${formatNumber(trend)} ${unit === '%' ? 'pts' : unit}/día`}
          badge={trend === null ? null : Math.abs(trend) < 0.5 ? 'Estable' : trend > 0 ? 'Subiendo' : 'Bajando'}
          tone={trend === null || Math.abs(trend) < 0.5 ? 'neutral' : 'info'}
          footer={range === '24h' || range === '1h' ? 'Disponible en los rangos de 7 y 30 días' : 'Regresión lineal sobre el período'}
        />
      </section>

      <Card>
        <h2 className="mb-4 text-xl font-semibold text-slate-900">Registros detallados</h2>
        {data.records.length === 0 ? (
          <EmptyState>No hay registros en este período.</EmptyState>
        ) : (
          <div className="max-h-[480px] overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="sticky top-0 bg-white text-slate-400">
                <tr className="border-b border-slate-200">
                  <th className="pb-3 font-medium">Fecha/hora</th>
                  <th className="pb-3 font-medium">Valor registrado</th>
                  <th className="pb-3 font-medium">Estado</th>
                </tr>
              </thead>
              <tbody>
                {data.records.map((record) => (
                  <tr key={record.timestamp} className="border-b border-slate-100">
                    <td className="py-3 text-slate-700">{formatDateTime(record.timestamp)}</td>
                    <td className="py-3 text-slate-700">{formatValue(record.value, unit)}</td>
                    <td className="py-3">
                      <Badge tone={record.status.tone}>{record.status.label}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {data.records.length >= 200 ? (
              <p className="pt-3 text-xs text-slate-400">Se muestran las 200 lecturas más recientes. Usa “Exportar CSV” para ver todas.</p>
            ) : null}
          </div>
        )}
      </Card>
    </div>
  )
}
