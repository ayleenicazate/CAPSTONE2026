import type { HTMLAttributes, PropsWithChildren } from 'react'

interface CardProps extends PropsWithChildren, HTMLAttributes<HTMLDivElement> {}

export function Card({ children, className = '', ...props }: CardProps) {
  return (
    <div
      className={`rounded-2xl border border-slate-200 bg-white p-4 md:p-5 ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}
