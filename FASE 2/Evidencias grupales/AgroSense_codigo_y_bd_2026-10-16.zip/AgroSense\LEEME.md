# AgroSense - Código fuente y bases de datos

Fecha: 16-10-2026. Código tomado del repositorio github.com/ayleenicazate/AgroSense (rama main, commit 5d9f3a6).

## codigo_fuente/
- `src/`: panel web (React + TypeScript + Vite).
- `backend/`: API en .NET 10 (`backend/src/AgroSense.Api`), pruebas (`backend/tests`) y simulador (`backend/tools`).
- `docker-compose*.yml`, `Dockerfile`, `deploy/`: despliegue en el servidor.
- `docs/`: documentación técnica.

No incluye contraseñas, llaves ni archivos `.env.prod` (se configuran aparte en el servidor).

## bases_de_datos/
| Base | Archivo | Qué es |
|---|---|---|
| Firebase Realtime Database | `firebase/database.rules.json` | Reglas de seguridad |
| | `firebase/estructura-ejemplo.json` | Estructura de los datos (config, status, readings) con valores reales de ejemplo |
| | `firebase/contrato-dispositivo.md` | Contrato entre el ESP32 y la plataforma |
| PostgreSQL | `postgresql/01_esquema.sql` | Esquema completo (13 tablas, índices y llaves) de producción |
| | `postgresql/02_consultas_reportes.sql` | 10 consultas de reporte |
| BigQuery | `bigquery/01_tablas_y_vistas.sql` | 2 tablas y 7 vistas del dataset `agrosense` |
| | `bigquery/02_modelos_ml.sql` | Modelos de predicción ARIMA_PLUS (BigQuery ML) |
| | `bigquery/03_consultas_reportes.sql` | 9 consultas de reporte |

Firebase no usa SQL: es una base JSON, por eso se entregan sus reglas y su estructura.
