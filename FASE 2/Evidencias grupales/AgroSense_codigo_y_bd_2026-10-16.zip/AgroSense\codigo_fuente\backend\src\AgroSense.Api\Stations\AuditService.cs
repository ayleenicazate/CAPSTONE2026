using AgroSense.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Stations;

public record AuditEntryDto(long Id, DateTimeOffset At, string UserName, string Action, string Summary);

/// <summary>Registro de acciones sobre una estación: quién cambió qué y cuándo.</summary>
public class AuditService(AgroSenseDbContext db, TimeProvider clock)
{
    public static class Actions
    {
        public const string IrrigationConfig = "irrigation.config";
        public const string ManualPump = "irrigation.manual";
        public const string Settings = "station.settings";
        public const string MemberJoined = "member.joined";
        public const string MemberRole = "member.role";
        public const string MemberRemoved = "member.removed";
        public const string Notifications = "notifications.settings";
        public const string TelegramLinked = "notifications.telegram";
    }

    /// <summary>Agrega una entrada (se guarda con el próximo SaveChanges del contexto).</summary>
    public void Add(Station station, User? user, string action, string summary) =>
        db.AuditEntries.Add(new AuditEntry
        {
            StationId = station.Id,
            UserId = user?.Id,
            UserName = user?.Name ?? "Sistema",
            Action = action,
            Summary = summary.Length > 1000 ? summary[..1000] : summary,
            At = clock.GetUtcNow(),
        });

    public Task<List<AuditEntryDto>> ListAsync(Guid stationId, int take, CancellationToken ct) =>
        db.AuditEntries.AsNoTracking()
            .Where(a => a.StationId == stationId)
            .OrderByDescending(a => a.At)
            .Take(Math.Clamp(take, 1, 500))
            .Select(a => new AuditEntryDto(a.Id, a.At, a.UserName, a.Action, a.Summary))
            .ToListAsync(ct);

    /// <summary>"Umbral de activación: 30 % → 25 %" para cada valor que cambió; vacío si no cambió nada.</summary>
    public static List<string> Diff(params (string Label, object? Before, object? After)[] fields) =>
        fields
            .Where(f => !Equals(f.Before, f.After))
            .Select(f => $"{f.Label}: {Show(f.Before)} → {Show(f.After)}")
            .ToList();

    private static string Show(object? value) => value switch
    {
        null or "" => "(vacío)",
        bool b => b ? "sí" : "no",
        double d => d.ToString("0.##", System.Globalization.CultureInfo.GetCultureInfo("es-CL")),
        _ => value.ToString()!,
    };
}
