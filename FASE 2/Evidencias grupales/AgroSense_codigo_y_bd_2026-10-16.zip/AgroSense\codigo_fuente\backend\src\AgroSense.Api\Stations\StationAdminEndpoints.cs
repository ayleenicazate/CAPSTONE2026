using System.Security.Cryptography;
using AgroSense.Api.Auth;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Notifications;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Stations;

public record MemberDto(Guid UserId, string Name, string Email, string Role, DateTimeOffset JoinedAt, bool IsMe);
public record UpdateMemberRequest(string Role);

public record NotificationSettingsDto(
    bool Enabled,
    bool AlertSoilDry,
    bool AlertOffline,
    bool AlertPumpLong,
    bool TelegramAvailable,
    bool TelegramLinked,
    string? TelegramChat,
    bool EmailAvailable,
    bool MyEmailAlerts);

public record UpdateNotificationsRequest(bool Enabled, bool AlertSoilDry, bool AlertOffline, bool AlertPumpLong);
public record MyNotificationsRequest(bool EmailAlerts);
public record TelegramLinkDto(string Code, string? Url, string? BotUsername, DateTimeOffset ExpiresAt);

/// <summary>Miembros y roles, registro de acciones y notificaciones de una estación.</summary>
public static class StationAdminEndpoints
{
    public static void MapStationAdminEndpoints(this RouteGroupBuilder station)
    {
        // ---- Miembros (solo administradores)
        station.MapGet("/members", ListMembersAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
        station.MapPut("/members/{userId:guid}", UpdateMemberAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
        station.MapDelete("/members/{userId:guid}", RemoveMemberAsync).AddEndpointFilter(StationEndpoints.AdminOnly);

        // ---- Registro de acciones (todos los miembros)
        station.MapGet("/audit", (HttpContext http, AuditService audit, int? take, CancellationToken ct) =>
            audit.ListAsync(StationEndpoints.Current(http).Id, take ?? 100, ct));

        // ---- Notificaciones
        station.MapGet("/notifications", GetNotificationsAsync);
        station.MapPut("/notifications", UpdateNotificationsAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
        station.MapPut("/notifications/me", UpdateMyNotificationsAsync);
        station.MapPost("/notifications/telegram/link", LinkTelegramAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
        station.MapDelete("/notifications/telegram", UnlinkTelegramAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
        station.MapPost("/notifications/test", TestAsync).AddEndpointFilter(StationEndpoints.AdminOnly);
    }

    private static async Task<List<MemberDto>> ListMembersAsync(HttpContext http, AgroSenseDbContext db, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var me = http.User.GetUserId();
        return await db.StationMembers.AsNoTracking()
            .Where(m => m.StationId == station.Id)
            .OrderBy(m => m.JoinedAt)
            .Select(m => new MemberDto(m.UserId, m.User.Name, m.User.Email, m.Role, m.JoinedAt, m.UserId == me))
            .ToListAsync(ct);
    }

    private static async Task<IResult> UpdateMemberAsync(
        Guid userId, UpdateMemberRequest request, HttpContext http, AgroSenseDbContext db, AuditService audit, CancellationToken ct)
    {
        if (!StationRoles.IsValid(request.Role)) return Problems.BadRequest("Rol no válido: usa admin o viewer.");
        var station = StationEndpoints.Current(http);
        var member = await db.StationMembers.Include(m => m.User)
            .FirstOrDefaultAsync(m => m.StationId == station.Id && m.UserId == userId, ct);
        if (member is null) return Problems.NotFound("Ese usuario no es miembro de la estación.");
        if (member.Role == request.Role) return Results.NoContent();
        if (member.Role == StationRoles.Admin && await IsLastAdminAsync(db, station.Id, ct))
            return Problems.Conflict("La estación debe tener al menos un administrador.");

        member.Role = request.Role;
        audit.Add(station, await StationEndpoints.CurrentUserAsync(http, db, ct), AuditService.Actions.MemberRole,
            $"{member.User.Name}: {RoleName(request.Role == StationRoles.Admin ? StationRoles.Viewer : StationRoles.Admin)} → {RoleName(request.Role)}");
        await db.SaveChangesAsync(ct);
        return Results.NoContent();
    }

    private static async Task<IResult> RemoveMemberAsync(
        Guid userId, HttpContext http, AgroSenseDbContext db, AuditService audit, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var member = await db.StationMembers.Include(m => m.User)
            .FirstOrDefaultAsync(m => m.StationId == station.Id && m.UserId == userId, ct);
        if (member is null) return Problems.NotFound("Ese usuario no es miembro de la estación.");
        if (member.Role == StationRoles.Admin && await IsLastAdminAsync(db, station.Id, ct))
            return Problems.Conflict("No puedes quitar al último administrador de la estación.");

        db.StationMembers.Remove(member);
        audit.Add(station, await StationEndpoints.CurrentUserAsync(http, db, ct), AuditService.Actions.MemberRemoved,
            $"Quitó a {member.User.Name} de la estación");
        await db.SaveChangesAsync(ct);
        return Results.NoContent();
    }

    private static async Task<bool> IsLastAdminAsync(AgroSenseDbContext db, Guid stationId, CancellationToken ct) =>
        await db.StationMembers.CountAsync(m => m.StationId == stationId && m.Role == StationRoles.Admin, ct) <= 1;

    private static string RoleName(string role) => role == StationRoles.Admin ? "administrador" : "solo lectura";

    // ---------------------------------------------------------------- Notificaciones

    private static async Task<NotificationSettingsDto> GetNotificationsAsync(
        HttpContext http, AgroSenseDbContext db, TelegramClient telegram, IOptions<SmtpOptions> smtp, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var me = http.User.GetUserId();
        var myEmail = await db.StationMembers.AsNoTracking()
            .Where(m => m.StationId == station.Id && m.UserId == me)
            .Select(m => m.EmailAlerts)
            .FirstOrDefaultAsync(ct);
        return new NotificationSettingsDto(
            station.NotificationsEnabled, station.AlertSoilDry, station.AlertOffline, station.AlertPumpLong,
            telegram.Enabled, station.TelegramChatId is not null, station.TelegramChatTitle,
            smtp.Value.Enabled, myEmail);
    }

    private static async Task<IResult> UpdateNotificationsAsync(
        UpdateNotificationsRequest request, HttpContext http, AgroSenseDbContext db, AuditService audit,
        TelegramClient telegram, IOptions<SmtpOptions> smtp, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var changes = AuditService.Diff(
            ("Notificaciones", station.NotificationsEnabled, request.Enabled),
            ("Aviso de suelo seco", station.AlertSoilDry, request.AlertSoilDry),
            ("Aviso de dispositivo fuera de línea", station.AlertOffline, request.AlertOffline),
            ("Aviso de bomba encendida demasiado tiempo", station.AlertPumpLong, request.AlertPumpLong));
        station.NotificationsEnabled = request.Enabled;
        station.AlertSoilDry = request.AlertSoilDry;
        station.AlertOffline = request.AlertOffline;
        station.AlertPumpLong = request.AlertPumpLong;
        if (changes.Count > 0)
        {
            audit.Add(station, await StationEndpoints.CurrentUserAsync(http, db, ct), AuditService.Actions.Notifications, string.Join(" · ", changes));
        }
        await db.SaveChangesAsync(ct);
        return Results.Ok(await GetNotificationsAsync(http, db, telegram, smtp, ct));
    }

    private static async Task<IResult> UpdateMyNotificationsAsync(
        MyNotificationsRequest request, HttpContext http, AgroSenseDbContext db, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var me = http.User.GetUserId();
        var member = await db.StationMembers.FirstAsync(m => m.StationId == station.Id && m.UserId == me, ct);
        member.EmailAlerts = request.EmailAlerts;
        await db.SaveChangesAsync(ct);
        return Results.NoContent();
    }

    /// <summary>
    /// Genera un código de un solo uso (válido 15 min). La persona abre el enlace del bot (o le escribe
    /// <c>/vincular CÓDIGO</c>) y el chat queda vinculado a la estación.
    /// </summary>
    private static async Task<IResult> LinkTelegramAsync(
        HttpContext http, AgroSenseDbContext db, TelegramClient telegram, TimeProvider clock, CancellationToken ct)
    {
        if (!telegram.Enabled) return Problems.Conflict("Telegram no está configurado en el servidor (Telegram:BotToken).");
        var station = StationEndpoints.Current(http);
        const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var code = new string(Enumerable.Range(0, 8).Select(_ => alphabet[RandomNumberGenerator.GetInt32(alphabet.Length)]).ToArray());
        station.TelegramLinkCode = code;
        station.TelegramLinkExpiresAt = clock.GetUtcNow().AddMinutes(15);
        await db.SaveChangesAsync(ct);

        var bot = await telegram.GetUsernameAsync(ct);
        return Results.Ok(new TelegramLinkDto(code, bot is null ? null : $"https://t.me/{bot}?start={code}", bot, station.TelegramLinkExpiresAt.Value));
    }

    private static async Task<IResult> UnlinkTelegramAsync(HttpContext http, AgroSenseDbContext db, AuditService audit, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        if (station.TelegramChatId is null) return Results.NoContent();
        audit.Add(station, await StationEndpoints.CurrentUserAsync(http, db, ct), AuditService.Actions.TelegramLinked,
            $"Desvinculó Telegram (chat \"{station.TelegramChatTitle}\")");
        station.TelegramChatId = null;
        station.TelegramChatTitle = null;
        await db.SaveChangesAsync(ct);
        return Results.NoContent();
    }

    private static async Task<IResult> TestAsync(HttpContext http, AgroSenseDbContext db, Notifier notifier, CancellationToken ct)
    {
        var station = StationEndpoints.Current(http);
        var user = await StationEndpoints.CurrentUserAsync(http, db, ct);
        var result = await notifier.SendAsync(station, "Prueba de notificaciones",
            $"{user.Name} envió este mensaje de prueba desde el panel. Si lo ves, las alertas llegarán aquí.", ct);
        return result.Any
            ? Results.Ok(new { result.Telegram, result.Emails })
            : Problems.Conflict("No hay ningún canal listo: vincula Telegram o activa las alertas por correo (y configura SMTP en el servidor).");
    }
}
