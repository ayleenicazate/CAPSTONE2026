import { ClipboardList } from 'lucide-react'

import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/States'
import { formatDateTime } from '@/lib/format'
import { useAuditQuery } from '@/services/queries'
import { useStation } from '@/stations/StationContext'

const ACTION_LABEL: Record<string, string> = {
  'irrigation.config': 'Riego',
  'irrigation.manual': 'Riego manual',
  'station.settings': 'Estación',
  'member.joined': 'Miembros',
  'member.role': 'Miembros',
  'member.removed': 'Miembros',
  'notifications.settings': 'Notificaciones',
  'notifications.telegram': 'Telegram',
}

/** Registro de acciones: quién cambió qué y cuándo (visible para todos los miembros). */
export function AuditLogCard() {
  const station = useStation()
  const { data } = useAuditQuery(station.id)

  return (
    <Card>
      <h2 className="flex items-center gap-2 text-xl font-semibold text-slate-900">
        <ClipboardList size={18} className="text-green-700" />
        Registro de actividad
      </h2>
      <p className="mt-1 text-sm text-slate-500">Cambios de configuración, riegos manuales y permisos, del más reciente al más antiguo.</p>
      {!data || data.length === 0 ? (
        <EmptyState>Todavía no hay acciones registradas.</EmptyState>
      ) : (
        <div className="mt-4 max-h-[420px] overflow-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="sticky top-0 bg-white text-slate-400">
              <tr className="border-b border-slate-200">
                <th className="pb-3 font-medium">Fecha y hora</th>
                <th className="pb-3 font-medium">Persona</th>
                <th className="pb-3 font-medium">Área</th>
                <th className="pb-3 font-medium">Cambio</th>
              </tr>
            </thead>
            <tbody>
              {data.map((entry) => (
                <tr key={entry.id} className="border-b border-slate-100 align-top">
                  <td className="py-3 pr-3 whitespace-nowrap text-slate-500">{formatDateTime(entry.at)}</td>
                  <td className="py-3 pr-3 whitespace-nowrap font-medium text-slate-700">{entry.userName}</td>
                  <td className="py-3 pr-3 whitespace-nowrap text-slate-500">{ACTION_LABEL[entry.action] ?? entry.action}</td>
                  <td className="py-3 text-slate-700">{entry.summary}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  )
}
