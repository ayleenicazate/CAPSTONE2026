import { CalendarClock, Droplets, Sun, Thermometer } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'

import { AlertsPanel } from '@/components/AlertsPanel'
import { MetricCard } from '@/components/MetricCard'
import { LivePanel } from '@/components/charts/LivePanel'
import { TrendChart } from '@/components/charts/TrendChart'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { ErrorState, LoadingState } from '@/components/ui/States'
import { formatDateTime, formatNumber, formatRelative, formatValue } from '@/lib/format'
import { useSummaryQuery } from '@/services/queries'
import { useStation } from '@/stations/StationContext'

export function SummaryPage() {
  const station = useStation()
  const { data, isLoading, error, refetch } = useSummaryQuery(station.id)

  if (isLoading) return <LoadingState label="Cargando resumen..." />
  if (error || !data) return <ErrorState error={error} onRetry={() => void refetch()} />

  const { irrigation, today } = data

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-3xl font-semibold tracking-tight text-slate-900">
          Monitoreo de la estación agroambiental
        </h2>
        <p className="mt-2 text-sm text-slate-500">
          <span className="font-medium text-green-700">{data.station.name}</span>
          {data.station.location ? (
            <>
              <span className="mx-2">•</span>
              {data.station.location}
            </>
          ) : null}
          <span className="mx-2">•</span>
          Última lectura: {data.latest ? formatDateTime(data.latest.timestamp) : 'sin datos todavía'}
        </p>
      </section>

      {!data.latest ? (
        <Card className="border-dashed text-sm text-slate-500">
          Esta estación aún no ha enviado lecturas. Cuando el ESP32 comience a escribir en Firebase (o el simulador
          esté corriendo) los datos aparecerán aquí automáticamente.
        </Card>
      ) : null}

      <AlertsPanel alerts={data.alerts} />

      <LivePanel station={data.station} />

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {data.metrics.map((metric) => {
          const digits = metric.unit === 'kPa' || metric.unit === 'V' ? 2 : metric.unit === 'µW/cm²' ? 0 : 1
          return (
            <MetricCard
              key={metric.key}
              label={metric.label}
              value={formatValue(metric.value, metric.unit, digits)}
              badge={metric.status?.label}
              tone={metric.status?.tone}
              hint={metric.hint}
              sparkline={metric.sparkline}
              unit={metric.unit}
              digits={digits}
            />
          )
        })}
      </section>

      <section className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_340px]">
        <TrendChart
          title="Humedad del suelo – últimas 24 horas"
          subtitle="Promedio por hora"
          data={data.soilMoisture24h}
          unit="%"
          domain={[0, 100]}
          seriesLabel="Humedad"
          references={[
            { y: irrigation.activationThreshold, label: 'Activación', color: '#d97706' },
            { y: irrigation.deactivationThreshold, label: 'Desactivación', color: '#15803d' },
          ]}
        />

        <Card className="flex flex-col">
          <h3 className="text-lg font-semibold text-slate-800">Estado del riego</h3>
          <div className="mt-5 flex flex-wrap gap-2 rounded-2xl bg-slate-100 p-4">
            <Badge tone={irrigation.pumpOn ? 'info' : 'neutral'}>
              Bomba {irrigation.pumpOn ? 'regando' : 'detenida'}
            </Badge>
            <Badge tone={irrigation.autoIrrigation ? 'success' : 'warning'}>
              {irrigation.autoIrrigation ? 'Modo automático' : 'Modo manual'}
            </Badge>
          </div>

          <dl className="mt-5 space-y-3 text-sm">
            <Row label="Humedad actual" value={formatValue(irrigation.currentMoisture, '%')} />
            <Row
              label="Umbral de activación"
              value={formatValue(irrigation.activationThreshold, '%')}
              className="text-amber-600"
            />
            <Row
              label="Próximo riego estimado"
              value={
                irrigation.estimatedNextIrrigationAt
                  ? formatRelative(irrigation.estimatedNextIrrigationAt)
                  : 'Sin tendencia de secado'
              }
            />
          </dl>

          <Link
            to="/riego"
            className="mt-6 rounded-xl bg-green-700 px-4 py-3 text-center text-sm font-semibold text-white transition hover:bg-green-800"
          >
            Ir a controles de riego
          </Link>
        </Card>
      </section>

      <section>
        <h3 className="mb-3 text-lg font-semibold text-slate-800">Hoy</h3>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <TodayTile
            icon={<Droplets size={18} />}
            label="Riegos"
            value={`${today.irrigationCount}`}
            detail={`${formatNumber(today.pumpMinutes)} min de bomba`}
          />
          <TodayTile
            icon={<Droplets size={18} />}
            label="Agua estimada"
            value={`${formatNumber(today.waterLiters)} L`}
            detail="Según caudal configurado"
          />
          <TodayTile
            icon={<Thermometer size={18} />}
            label="Temperatura mín / máx"
            value={`${formatNumber(today.temperatureMin)} / ${formatNumber(today.temperatureMax)} °C`}
            detail="Desde la medianoche"
          />
          <TodayTile
            icon={<Sun size={18} />}
            label="Horas de luz"
            value={today.lightHours === null ? '—' : `${today.lightHours} h`}
            detail="Horas con luz ≥ 40 % del máximo reciente"
          />
        </div>
      </section>

      {irrigation.estimatedNextIrrigationAt ? (
        <Card className="flex items-start gap-3 text-sm text-slate-600">
          <CalendarClock size={18} className="mt-0.5 shrink-0 text-sky-600" />
          <p>
            Con la tendencia de secado desde el último riego, la humedad del suelo llegaría al umbral de activación (
            {formatValue(irrigation.activationThreshold, '%')}) el{' '}
            <span className="font-semibold">{formatDateTime(irrigation.estimatedNextIrrigationAt)}</span>.
          </p>
        </Card>
      ) : null}
    </div>
  )
}

function Row({ label, value, className = 'text-slate-800' }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-slate-500">{label}</dt>
      <dd className={`font-semibold ${className}`}>{value}</dd>
    </div>
  )
}

function TodayTile({ icon, label, value, detail }: { icon: ReactNode; label: string; value: string; detail: string }) {
  return (
    <Card>
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <span className="text-green-700">{icon}</span>
        {label}
      </div>
      <p className="mt-3 text-2xl font-semibold text-slate-800">{value}</p>
      <p className="mt-1 text-xs text-slate-400">{detail}</p>
    </Card>
  )
}
