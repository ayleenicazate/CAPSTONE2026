using System.Net.Http.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Notifications;

/// <summary>Cliente mínimo de la API de bots de Telegram (https://core.telegram.org/bots/api).</summary>
public class TelegramClient(HttpClient http, IOptions<TelegramOptions> options)
{
    private readonly TelegramOptions _options = options.Value;
    private string? _username;

    public bool Enabled => _options.Enabled;

    private string Url(string method) => $"https://api.telegram.org/bot{_options.BotToken}/{method}";

    /// <summary>Nombre de usuario del bot (@...), para armar el enlace de vinculación.</summary>
    public async Task<string?> GetUsernameAsync(CancellationToken ct)
    {
        if (!Enabled) return null;
        if (_username is not null) return _username;
        var me = await http.GetFromJsonAsync<JsonObject>(Url("getMe"), ct);
        _username = me?["result"]?["username"]?.GetValue<string>();
        return _username;
    }

    public async Task SendMessageAsync(long chatId, string html, CancellationToken ct)
    {
        using var response = await http.PostAsJsonAsync(Url("sendMessage"),
            new { chat_id = chatId, text = html, parse_mode = "HTML", disable_web_page_preview = true }, ct);
        if (!response.IsSuccessStatusCode)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            throw new HttpRequestException($"Telegram respondió {(int)response.StatusCode}: {body}");
        }
    }

    /// <summary>Long polling: espera hasta <paramref name="timeoutSeconds"/> por mensajes nuevos.</summary>
    public async Task<JsonArray> GetUpdatesAsync(long offset, int timeoutSeconds, CancellationToken ct)
    {
        var result = await http.GetFromJsonAsync<JsonObject>(
            $"{Url("getUpdates")}?offset={offset}&timeout={timeoutSeconds}&allowed_updates=%5B%22message%22%5D", ct);
        return result?["result"] as JsonArray ?? [];
    }
}
