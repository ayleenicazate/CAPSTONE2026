using AgroSense.Api.Data;
using AgroSense.Api.Metrics;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Ingestion;

/// <summary>Mantiene la tabla <c>reading_minutes</c> a partir de las lecturas crudas.</summary>
public class RollupService(AgroSenseDbContext db)
{
    public static DateTimeOffset MinuteOf(DateTimeOffset t) =>
        new(t.UtcTicks - t.UtcTicks % TimeSpan.TicksPerMinute, TimeSpan.Zero);

    /// <summary>
    /// Recalcula los minutos que cubren [from, to]. Es idempotente: se puede llamar varias veces
    /// sobre el mismo rango (por ejemplo, al completar lecturas antiguas con datos nuevos).
    /// </summary>
    public async Task RefreshAsync(Guid stationId, DateTimeOffset from, DateTimeOffset to, CancellationToken ct = default)
    {
        var start = MinuteOf(from);
        var end = MinuteOf(to).AddMinutes(1);

        var readings = await db.Readings.AsNoTracking()
            .Where(r => r.StationId == stationId && r.Timestamp >= start && r.Timestamp < end)
            .ToListAsync(ct);
        // Incluye lecturas recién agregadas al contexto y aún no guardadas.
        readings.AddRange(db.ChangeTracker.Entries<Reading>()
            .Where(e => e.State == EntityState.Added && e.Entity.StationId == stationId
                && e.Entity.Timestamp >= start && e.Entity.Timestamp < end)
            .Select(e => e.Entity));

        var existing = await db.ReadingMinutes
            .Where(m => m.StationId == stationId && m.Minute >= start && m.Minute < end)
            .ToDictionaryAsync(m => m.Minute, ct);

        foreach (var group in readings.GroupBy(r => MinuteOf(r.Timestamp)))
        {
            var fresh = Aggregate(stationId, group.Key, group.ToList());
            if (existing.TryGetValue(group.Key, out var row))
            {
                db.Entry(row).CurrentValues.SetValues(fresh);
            }
            else
            {
                db.ReadingMinutes.Add(fresh);
            }
        }
    }

    public static ReadingMinute Aggregate(Guid stationId, DateTimeOffset minute, IReadOnlyCollection<Reading> readings)
    {
        static (double? Avg, double? Min, double? Max) Stat(IEnumerable<double?> values)
        {
            var list = values.Where(v => v is not null).Select(v => v!.Value).ToList();
            return list.Count == 0 ? (null, null, null) : (Math.Round(list.Average(), 3), list.Min(), list.Max());
        }

        var t = Stat(readings.Select(r => r.Temperature));
        var h = Stat(readings.Select(r => r.AirHumidity));
        var s = Stat(readings.Select(r => r.SoilMoisture));
        var l = Stat(readings.Select(r => r.SpectralTotal));
        var a = Stat(readings.Select(r => Variables.IsAirQualitySaturated(r) ? null : r.AirQualityVoltage));

        return new ReadingMinute
        {
            StationId = stationId,
            Minute = minute,
            Count = readings.Count,
            PumpOnCount = readings.Count(r => r.PumpOn == true),
            TemperatureAvg = t.Avg, TemperatureMin = t.Min, TemperatureMax = t.Max,
            AirHumidityAvg = h.Avg, AirHumidityMin = h.Min, AirHumidityMax = h.Max,
            SoilMoistureAvg = s.Avg, SoilMoistureMin = s.Min, SoilMoistureMax = s.Max,
            LightAvg = l.Avg, LightMin = l.Min, LightMax = l.Max,
            AirQualityAvg = a.Avg, AirQualityMin = a.Min, AirQualityMax = a.Max,
            SpectralVioletAvg = Stat(readings.Select(r => r.SpectralViolet)).Avg,
            SpectralBlueAvg = Stat(readings.Select(r => r.SpectralBlue)).Avg,
            SpectralGreenAvg = Stat(readings.Select(r => r.SpectralGreen)).Avg,
            SpectralYellowAvg = Stat(readings.Select(r => r.SpectralYellow)).Avg,
            SpectralOrangeAvg = Stat(readings.Select(r => r.SpectralOrange)).Avg,
            SpectralRedAvg = Stat(readings.Select(r => r.SpectralRed)).Avg,
        };
    }
}
