namespace AgroSense.Api.Infrastructure;

public class JwtOptions
{
    public const string Section = "Jwt";
    public string Issuer { get; set; } = "AgroSense";
    public string Audience { get; set; } = "AgroSense.Web";
    public string SigningKey { get; set; } = string.Empty;
    public int ExpirationHours { get; set; } = 12;
    public int RememberMeExpirationDays { get; set; } = 14;
}

public class FirebaseOptions
{
    public const string Section = "Firebase";

    /// <summary>Ej: https://agrosense-xxxx-default-rtdb.firebaseio.com. Vacío = integración desactivada.</summary>
    public string DatabaseUrl { get; set; } = string.Empty;

    /// <summary>Ruta al JSON de la cuenta de servicio (Configuración del proyecto → Cuentas de servicio).</summary>
    public string? ServiceAccountPath { get; set; }

    /// <summary>Alternativa: secreto heredado de la base de datos (no recomendado, pero sirve para pruebas).</summary>
    public string? DatabaseSecret { get; set; }

    /// <summary>Cada cuánto se consultan lecturas nuevas. Con lecturas cada 2–3 s conviene 2 s.</summary>
    public int PollIntervalSeconds { get; set; } = 2;

    /// <summary>
    /// Las lecturas ya importadas se borran de Firebase cuando tienen más de estas horas
    /// (el plan gratuito de Realtime Database tiene 1 GB). 0 = no borrar.
    /// </summary>
    public int PruneAfterHours { get; set; } = 48;
    public int BatchSize { get; set; } = 500;

    public bool Enabled => !string.IsNullOrWhiteSpace(DatabaseUrl);
}

public class RetentionOptions
{
    public const string Section = "Retention";

    /// <summary>
    /// Días que se conservan las lecturas crudas en PostgreSQL (los resúmenes por minuto se conservan siempre).
    /// Si BigQuery está activo, solo se borran lecturas ya exportadas. 0 = conservar todo.
    /// </summary>
    public int RawReadingDays { get; set; } = 30;
}

public class BigQueryOptions
{
    public const string Section = "BigQuery";

    public bool Enabled { get; set; }

    /// <summary>Proyecto de Google Cloud (el mismo de Firebase, por ejemplo agrosense-a1b2c).</summary>
    public string ProjectId { get; set; } = string.Empty;
    public string Dataset { get; set; } = "agrosense";
    public string Location { get; set; } = "US";

    /// <summary>JSON de una cuenta de servicio con roles BigQuery Data Editor y BigQuery Job User.</summary>
    public string? ServiceAccountPath { get; set; }

    public int ExportIntervalMinutes { get; set; } = 5;

    /// <summary>Cada cuántas horas se reentrenan los modelos de pronóstico de BigQuery ML.</summary>
    public int MlRetrainHours { get; set; } = 12;
    public int BatchSize { get; set; } = 20000;
}

public class StationOptions
{
    public const string Section = "Stations";
    public string DefaultCode { get; set; } = "agrosense-01";
    public string DefaultName { get; set; } = "AgroSense 01";
    public string TimeZone { get; set; } = "America/Santiago";
}

public class DeviceIngestOptions
{
    public const string Section = "DeviceIngest";

    /// <summary>Clave compartida que el dispositivo envía en X-Device-Key al usar la ingesta HTTP directa.</summary>
    public string DeviceKey { get; set; } = string.Empty;
}

public class SeedOptions
{
    public const string Section = "Seed";
    public bool DemoData { get; set; }
    public int DemoDays { get; set; } = 14;
    public string? DemoUserEmail { get; set; }
    public string? DemoUserPassword { get; set; }
    public string DemoUserName { get; set; } = "Estudiante MVP";
}

public class AppOptions
{
    public const string Section = "App";
    public string FrontendUrl { get; set; } = "http://localhost:5173";
    public string[] CorsOrigins { get; set; } = [];

    /// <summary>
    /// Si se define, registrarse exige este código (lo entrega el equipo). Vacío = registro abierto.
    /// En un servidor público debe estar definido.
    /// </summary>
    public string? RegistrationCode { get; set; }

    /// <summary>URL del reporte de Looker Studio (se configura después de crearlo y compartirlo).</summary>
    public string? LookerStudioUrl { get; set; }
}
