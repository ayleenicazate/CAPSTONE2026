import { useOutletContext } from 'react-router-dom'

import type { StationInfo } from '@/types/api'

export interface StationOutletContext {
  station: StationInfo
}

/** Estación seleccionada actualmente (la entrega AppLayout a cada página). */
export function useStation(): StationInfo {
  return useOutletContext<StationOutletContext>().station
}

/** true si el usuario puede cambiar la estación (riego, configuración, miembros, notificaciones). */
export function useIsAdmin(): boolean {
  return useStation().role === 'admin'
}

export const SELECTED_STATION_KEY = 'agrosense.station'
