import { BrainCircuit, Database, ExternalLink, Lightbulb, PieChart } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

import { MetricCard } from '@/components/MetricCard'
import { TrendChart } from '@/components/charts/TrendChart'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States'
import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatDateTime, formatNumber, formatRelative, formatValue } from '@/lib/format'
import { useAnalyticsQuery } from '@/services/queries'
import { useStation } from '@/stations/StationContext'
import type { AnalyticsData, MlModel, StatusTone } from '@/types/api'

const MODEL_STATUS: Record<MlModel['status'], { label: string; tone: StatusTone }> = {
  ok: { label: 'Entrenado', tone: 'success' },
  insufficient_data: { label: 'Faltan datos', tone: 'warning' },
  error: { label: 'Error', tone: 'warning' },
  pending: { label: 'Pendiente', tone: 'neutral' },
}

const STRENGTH_TONE: Record<string, StatusTone> = { fuerte: 'success', moderada: 'info', débil: 'neutral' }

export function AnalysisPage() {
  const station = useStation()
  const { data, isLoading, error, refetch } = useAnalyticsQuery(station.id)

  if (isLoading) return <LoadingState label="Consultando BigQuery..." />
  if (error || !data) return <ErrorState error={error} onRetry={() => void refetch()} />

  return (
    <div className="space-y-6">
      <section className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-3xl font-semibold tracking-tight text-slate-900">Análisis histórico</h2>
          <p className="mt-1 text-sm text-slate-500">
            Calculado en BigQuery sobre todas las lecturas guardadas de la estación.
          </p>
        </div>
        {data.enabled && data.totals ? (
          <p className="flex items-center gap-2 text-xs text-slate-400">
            <Database size={14} />
            {formatNumber(data.bytesProcessed / 1024, 0)} KB procesados · actualizado {formatRelative(data.generatedAt)}
          </p>
        ) : null}
      </section>

      {data.message ? (
        <Card className="border-amber-200 bg-amber-50 text-sm text-amber-800">{data.message}</Card>
      ) : null}

      {data.totals ? <Totals totals={data.totals} /> : null}

      {data.insights.length > 0 ? <Insights data={data} /> : null}

      <MlModels models={data.models} />

      {data.daily.length > 0 ? <DailyTrends daily={data.daily} /> : null}

      {data.monthly.length > 0 ? <Monthly monthly={data.monthly} /> : null}

      {data.looker ? <LookerCard looker={data.looker} /> : null}
    </div>
  )
}

function Totals({ totals }: { totals: NonNullable<AnalyticsData['totals']> }) {
  return (
    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <MetricCard
        label="Lecturas registradas"
        value={formatNumber(totals.readings, 0)}
        footer={totals.firstReadingAt ? `Desde ${formatDateTime(totals.firstReadingAt)}` : null}
      />
      <MetricCard label="Días con datos" value={formatNumber(totals.daysWithData, 0)} footer={totals.lastReadingAt ? `Última: ${formatRelative(totals.lastReadingAt)}` : null} />
      <MetricCard label="Riegos" value={formatNumber(totals.irrigations, 0)} footer="Ciclos de la bomba registrados" />
      <MetricCard label="Agua estimada total" value={formatValue(totals.waterLiters, 'L', 1)} footer="Según el caudal configurado" />
    </section>
  )
}

function Insights({ data }: { data: AnalyticsData }) {
  return (
    <section>
      <h3 className="mb-3 flex items-center gap-2 text-lg font-semibold text-slate-800">
        <Lightbulb size={18} className="text-amber-500" />
        Hallazgos
      </h3>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.insights.map((insight) => (
          <Card key={insight.key} className="flex flex-col gap-2">
            <div className="flex items-start justify-between gap-2">
              <p className="text-sm font-medium text-slate-500">{insight.title}</p>
              {insight.strength ? (
                <Badge tone={STRENGTH_TONE[insight.strength] ?? 'neutral'}>Relación {insight.strength}</Badge>
              ) : null}
            </div>
            <p className="text-2xl font-semibold tabular-nums text-slate-800">{insight.value}</p>
            <p className="text-sm text-slate-600">{insight.detail}</p>
          </Card>
        ))}
      </div>
    </section>
  )
}

function MlModels({ models }: { models: MlModel[] }) {
  return (
    <Card>
      <h3 className="flex items-center gap-2 text-lg font-semibold text-slate-800">
        <BrainCircuit size={18} className="text-sky-700" />
        Modelos de pronóstico (BigQuery ML)
      </h3>
      <p className="mt-1 text-sm text-slate-500">
        Un modelo ARIMA_PLUS por variable, reentrenado cada 12 horas con el histórico por hora de los últimos 30 días.
        Sus pronósticos de 48 h, con intervalo de confianza del 90 %, se muestran en Historial.
      </p>
      <div className="mt-4 overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="text-slate-400">
            <tr className="border-b border-slate-200">
              <th className="pb-3 font-medium">Variable</th>
              <th className="pb-3 font-medium">Estado</th>
              <th className="pb-3 font-medium">Horas de datos</th>
              <th className="pb-3 font-medium">Modelo elegido</th>
              <th className="pb-3 font-medium">Entrenado</th>
            </tr>
          </thead>
          <tbody>
            {models.map((model) => {
              const status = MODEL_STATUS[model.status] ?? MODEL_STATUS.pending
              return (
                <tr key={model.variable} className="border-b border-slate-100 align-top">
                  <td className="py-3 font-medium text-slate-700">{model.label}</td>
                  <td className="py-3">
                    <Badge tone={status.tone}>{status.label}</Badge>
                  </td>
                  <td className="py-3 tabular-nums text-slate-700">{model.trainingPoints || '—'}</td>
                  <td className="py-3 text-slate-700">
                    {model.description ?? <span className="text-slate-400">{model.message ?? '—'}</span>}
                  </td>
                  <td className="py-3 text-slate-500">{model.trainedAt ? formatRelative(model.trainedAt) : '—'}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Card>
  )
}

function DailyTrends({ daily }: { daily: AnalyticsData['daily'] }) {
  const series = (pick: (d: AnalyticsData['daily'][number]) => number | null, band?: boolean) =>
    daily
      .filter((d) => pick(d) !== null)
      .map((d) => ({
        timestamp: `${d.day}T12:00:00`,
        value: pick(d) as number,
        ...(band && d.temperatureMin !== null && d.temperatureMax !== null
          ? { min: d.temperatureMin, max: d.temperatureMax }
          : {}),
      }))

  return (
    <section className="space-y-4">
      <h3 className="text-lg font-semibold text-slate-800">Tendencia diaria (últimos 90 días)</h3>
      <TrendChart
        title="Temperatura diaria"
        subtitle="Promedio del día, con el mínimo y máximo registrados"
        data={series((d) => d.temperatureAvg, true)}
        unit="°C"
        axis="date"
        maxGapMs={36 * 3600_000}
        showDots
        height={240}
        seriesLabel="Promedio"
      />
      <div className="grid gap-4 xl:grid-cols-2">
        <TrendChart
          title="Humedad del suelo diaria"
          data={series((d) => d.soilMoistureAvg)}
          unit="%"
          axis="date"
        maxGapMs={36 * 3600_000}
        showDots
          height={200}
          domain={[0, 100]}
          seriesLabel="Promedio"
        />
        <TrendChart
          title="Luz diaria (AS7262)"
          data={series((d) => d.lightAvg)}
          unit="µW/cm²"
          axis="date"
        maxGapMs={36 * 3600_000}
        showDots
          height={200}
          digits={0}
          seriesLabel="Promedio"
        />
      </div>
    </section>
  )
}

function Monthly({ monthly }: { monthly: AnalyticsData['monthly'] }) {
  const monthLabel = (m: string) => {
    const label = new Date(`${m}-15T12:00:00`).toLocaleDateString('es-CL', { month: 'long', year: 'numeric' })
    return label.charAt(0).toUpperCase() + label.slice(1)
  }

  return (
    <section className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
      <Card>
        <h3 className="text-lg font-semibold text-slate-800">Agua estimada por mes</h3>
        <div className="mt-4 h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthly.map((m) => ({ ...m, label: monthLabel(m.month) }))} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
              <CartesianGrid stroke={chart.grid} strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: chart.axis, fontSize: 11 }} />
              <YAxis axisLine={false} tickLine={false} width={48} tick={{ fill: chart.axis, fontSize: 12 }} tickFormatter={(v: number) => `${v} L`} />
              <Tooltip
                {...tooltipStyle}
                cursor={{ fill: '#f1f5f9' }}
                formatter={(value: number, _n, item) => [`${formatNumber(value)} L · ${item.payload.irrigations} riegos`, 'Agua estimada']}
              />
              <Bar dataKey="waterLiters" fill={chart.water} radius={[4, 4, 0, 0]} maxBarSize={48} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card>
        <h3 className="mb-4 text-lg font-semibold text-slate-800">Resumen mensual</h3>
        {monthly.length === 0 ? (
          <EmptyState>Sin datos.</EmptyState>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-400">
                <tr className="border-b border-slate-200">
                  <th className="pb-3 font-medium">Mes</th>
                  <th className="pb-3 text-right font-medium">Lecturas</th>
                  <th className="pb-3 text-right font-medium">Temp. prom (mín–máx)</th>
                  <th className="pb-3 text-right font-medium">Hum. aire</th>
                  <th className="pb-3 text-right font-medium">Suelo</th>
                  <th className="pb-3 text-right font-medium">Riegos</th>
                  <th className="pb-3 text-right font-medium">Agua</th>
                </tr>
              </thead>
              <tbody className="tabular-nums">
                {monthly.map((m) => (
                  <tr key={m.month} className="border-b border-slate-100">
                    <td className="py-3 text-slate-700">{monthLabel(m.month)}</td>
                    <td className="py-3 text-right text-slate-700">{formatNumber(m.readings, 0)}</td>
                    <td className="py-3 text-right text-slate-700">
                      {formatValue(m.temperatureAvg, '°C')}{' '}
                      <span className="text-slate-400">
                        ({formatNumber(m.temperatureMin)}–{formatNumber(m.temperatureMax)})
                      </span>
                    </td>
                    <td className="py-3 text-right text-slate-700">{formatValue(m.airHumidityAvg, '%')}</td>
                    <td className="py-3 text-right text-slate-700">{formatValue(m.soilMoistureAvg, '%')}</td>
                    <td className="py-3 text-right text-slate-700">{m.irrigations}</td>
                    <td className="py-3 text-right text-slate-700">{formatValue(m.waterLiters, 'L')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </section>
  )
}

function LookerCard({ looker }: { looker: NonNullable<AnalyticsData['looker']> }) {
  return (
    <Card>
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div className="flex gap-3">
          <PieChart size={22} className="mt-0.5 shrink-0 text-indigo-600" />
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Reporte en Looker Studio</h3>
            <p className="text-sm text-slate-500">
              {looker.reportUrl
                ? 'Reporte interactivo conectado a BigQuery, ideal para presentaciones y anexos de la tesis.'
                : 'Reporte interactivo sobre BigQuery para la presentación o los anexos de la tesis. Se crea una vez:'}
            </p>
            {looker.reportUrl ? null : (
              <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-slate-600">
                <li>
                  Haz clic en <span className="font-medium">Crear reporte</span> (entra con la cuenta de Google del proyecto de
                  Firebase).
                </li>
                <li>
                  En “Agregar datos al informe” elige <span className="font-medium">BigQuery</span> → <span className="font-medium">Mis proyectos</span> →{' '}
                  <code>agrosense-a1b2c</code> → <code>agrosense</code> → <code>daily_summary</code> → <span className="font-medium">Agregar</span>.
                </li>
                <li>
                  Repite con <span className="font-medium">Recurso → Administrar fuentes de datos → Agregar</span> para <code>hourly_summary</code>.
                </li>
                <li>Arma los gráficos, guarda y comparte con “Cualquier persona con el enlace”.</li>
                <li>Envía el enlace para configurarlo en el servidor: este botón pasará a abrir tu reporte.</li>
              </ol>
            )}
          </div>
        </div>
        <a
          href={looker.reportUrl ?? looker.createUrl}
          target="_blank"
          rel="noreferrer"
          className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
        >
          <ExternalLink size={16} />
          {looker.reportUrl ? 'Abrir reporte' : 'Crear reporte'}
        </a>
      </div>
    </Card>
  )
}
