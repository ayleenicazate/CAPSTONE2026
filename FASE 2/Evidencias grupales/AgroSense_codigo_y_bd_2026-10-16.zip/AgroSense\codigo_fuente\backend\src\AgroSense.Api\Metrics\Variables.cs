using AgroSense.Api.Data;

namespace AgroSense.Api.Metrics;

public enum Tone { Normal, Warning, Info, Neutral, Success }

public record MetricStatus(string Label, string Tone);

public record VariableInfo(
    string Key,
    string Label,
    string Unit,
    Func<Reading, double?> Selector,
    Func<ReadingMinute, (double? Avg, double? Min, double? Max)> Minute,
    int Digits = 1);

/// <summary>Variables medidas por el hardware actual (SHT3x, sensor de suelo, AS7262, MQ135).</summary>
public static class Variables
{
    public const string Temperature = "temperature";
    public const string AirHumidity = "airHumidity";
    public const string SoilMoisture = "soilMoisture";
    public const string Light = "light";
    public const string AirQuality = "airQuality";

    /// <summary>El ADC de 12 bits del ESP32 satura en 4095: la lectura no es válida (calentamiento o falta divisor).</summary>
    public const int AdcSaturation = 4090;

    public static bool IsAirQualitySaturated(Reading r) => r.AirQualityRaw >= AdcSaturation;

    public static readonly IReadOnlyList<VariableInfo> All =
    [
        new(Temperature, "Temperatura", "°C", r => r.Temperature,
            m => (m.TemperatureAvg, m.TemperatureMin, m.TemperatureMax)),
        new(AirHumidity, "Humedad ambiental", "%", r => r.AirHumidity,
            m => (m.AirHumidityAvg, m.AirHumidityMin, m.AirHumidityMax)),
        new(SoilMoisture, "Humedad del suelo", "%", r => r.SoilMoisture,
            m => (m.SoilMoistureAvg, m.SoilMoistureMin, m.SoilMoistureMax)),
        new(Light, "Luz (AS7262)", "µW/cm²", r => r.SpectralTotal,
            m => (m.LightAvg, m.LightMin, m.LightMax)),
        new(AirQuality, "Calidad del aire (MQ135)", "V", r => IsAirQualitySaturated(r) ? null : r.AirQualityVoltage,
            m => (m.AirQualityAvg, m.AirQualityMin, m.AirQualityMax), Digits: 2),
    ];

    public static VariableInfo? Find(string key) =>
        All.FirstOrDefault(v => string.Equals(v.Key, key, StringComparison.OrdinalIgnoreCase));

    /// <summary>
    /// Clasifica un valor en un estado legible. Los rangos son referenciales para cultivos de hortalizas
    /// en invernadero; la humedad del suelo usa los umbrales configurados en la estación.
    /// </summary>
    public static MetricStatus Evaluate(string variable, double value, Station station) => variable switch
    {
        Temperature => value switch
        {
            < 5 => Status("Helada", Tone.Info),
            < 12 => Status("Baja", Tone.Warning),
            <= 30 => Status("Normal", Tone.Normal),
            <= 35 => Status("Alta", Tone.Warning),
            _ => Status("Crítica", Tone.Warning),
        },
        AirHumidity => value switch
        {
            < 30 => Status("Muy seca", Tone.Warning),
            < 40 => Status("Baja", Tone.Warning),
            <= 80 => Status("Normal", Tone.Normal),
            _ => Status("Alta", Tone.Info),
        },
        SoilMoisture when value < station.ActivationThreshold => Status("Seco", Tone.Warning),
        SoilMoisture when value > station.DeactivationThreshold + 15 => Status("Saturado", Tone.Info),
        SoilMoisture => Status("Normal", Tone.Normal),
        // Suma de las 6 bandas del AS7262. Referencial: interior ~100–500, sol directo varios miles.
        Light => value switch
        {
            < 20 => Status("Oscuro", Tone.Neutral),
            < 500 => Status("Luz baja", Tone.Info),
            _ => Status("Luz alta", Tone.Normal),
        },
        // MQ135 alimentado a 5 V, sin calibrar: a mayor voltaje, más gases (CO2, NH3, alcohol, humo).
        AirQuality => value switch
        {
            < 1.5 => Status("Buena", Tone.Normal),
            < 2.5 => Status("Moderada", Tone.Info),
            _ => Status("Deficiente", Tone.Warning),
        },
        _ => Status("—", Tone.Neutral),
    };

    public static MetricStatus Status(string label, Tone tone) => new(label, tone.ToString().ToLowerInvariant());
}
