import { useQuery } from '@tanstack/react-query'

import { api } from '@/services/api'
import type { HistoryRange, VariableKey } from '@/types/api'

// Las lecturas llegan cada 2–3 s: la vista "en vivo" se consulta a ese ritmo (endpoint liviano);
// los resúmenes y gráficos agregados cambian más lento y se refrescan con menos frecuencia.
const SUMMARY = { refetchInterval: 15_000, staleTime: 5_000 }
const SLOW = { refetchInterval: 60_000, staleTime: 30_000 }

export const queryKeys = {
  stations: ['stations'] as const,
  summary: (id: string) => ['summary', id] as const,
  live: (id: string, minutes: number) => ['live', id, minutes] as const,
  sensors: (id: string, hours: number) => ['sensors', id, hours] as const,
  history: (id: string, variable: VariableKey, range: HistoryRange) => ['history', id, variable, range] as const,
  heatmap: (id: string, variable: VariableKey, days: number) => ['heatmap', id, variable, days] as const,
  irrigation: (id: string) => ['irrigation', id] as const,
  settings: (id: string) => ['settings', id] as const,
  system: ['system-status'] as const,
  analytics: (id: string) => ['analytics', id] as const,
  members: (id: string) => ['members', id] as const,
  audit: (id: string) => ['audit', id] as const,
  notifications: (id: string) => ['notifications', id] as const,
}

export const useStationsQuery = () => useQuery({ queryKey: queryKeys.stations, queryFn: api.stations, ...SUMMARY })

export const useSummaryQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.summary(id), queryFn: () => api.summary(id), ...SUMMARY })

/**
 * Lecturas de los últimos minutos. Con el canal en tiempo real activo solo se usa para la carga inicial y
 * una resincronización ocasional (`refetchMs`); si el canal falla, se consulta al ritmo del dispositivo.
 */
export const useLiveQuery = (id: string, minutes: number, refetchMs: number) =>
  useQuery({
    queryKey: queryKeys.live(id, minutes),
    queryFn: () => api.live(id, minutes),
    refetchInterval: refetchMs,
    refetchIntervalInBackground: false,
    placeholderData: (previous) => previous,
  })

export const useSensorsQuery = (id: string, hours: number) =>
  useQuery({
    queryKey: queryKeys.sensors(id, hours),
    queryFn: () => api.sensors(id, hours),
    ...SUMMARY,
    placeholderData: (previous) => previous,
  })

export const useHistoryQuery = (id: string, variable: VariableKey, range: HistoryRange) =>
  useQuery({
    queryKey: queryKeys.history(id, variable, range),
    queryFn: () => api.history(id, variable, range),
    refetchInterval: range === '1h' ? 15_000 : 60_000,
    placeholderData: (previous) => previous,
  })

export const useHeatmapQuery = (id: string, variable: VariableKey, days: number) =>
  useQuery({
    queryKey: queryKeys.heatmap(id, variable, days),
    queryFn: () => api.heatmap(id, variable, days),
    ...SLOW,
    placeholderData: (previous) => previous,
  })

export const useIrrigationQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.irrigation(id), queryFn: () => api.irrigation(id), ...SUMMARY })

export const useSettingsQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.settings(id), queryFn: () => api.settings(id) })

export const useSystemStatusQuery = () =>
  useQuery({ queryKey: queryKeys.system, queryFn: api.systemStatus, ...SLOW })

/** Análisis en BigQuery: el backend lo guarda 10 min en caché, así que no tiene sentido consultar más seguido. */
export const useAnalyticsQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.analytics(id), queryFn: () => api.analytics(id), staleTime: 5 * 60_000, refetchInterval: 10 * 60_000 })

export const useMembersQuery = (id: string, enabled: boolean) =>
  useQuery({ queryKey: queryKeys.members(id), queryFn: () => api.members(id), enabled })

export const useAuditQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.audit(id), queryFn: () => api.audit(id), refetchInterval: 60_000 })

export const useNotificationsQuery = (id: string) =>
  useQuery({ queryKey: queryKeys.notifications(id), queryFn: () => api.notifications(id) })
