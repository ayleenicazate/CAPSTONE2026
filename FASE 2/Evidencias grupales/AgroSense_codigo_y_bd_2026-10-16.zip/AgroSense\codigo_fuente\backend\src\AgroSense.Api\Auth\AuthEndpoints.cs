using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Stations;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Auth;

public record RegisterRequest(string Name, string Email, string Password, string? StationCode, string? InviteCode);
public record AuthOptionsDto(bool InviteRequired);
public record LoginRequest(string Email, string Password, bool Remember);
public record ForgotPasswordRequest(string Email);
public record ResetPasswordRequest(string Email, string Token, string NewPassword);

public record StationRefDto(Guid Id, string Code, string Name);
public record UserDto(Guid Id, string Name, string Email, IReadOnlyList<StationRefDto> Stations);
public record AuthResponse(string Token, DateTimeOffset ExpiresAt, UserDto User);

public static class AuthEndpoints
{
    private const int MinPasswordLength = 8;

    public static RouteGroupBuilder MapAuthEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/auth").WithTags("Autenticación");

        group.MapGet("/options", (IOptions<AppOptions> app) =>
            new AuthOptionsDto(!string.IsNullOrWhiteSpace(app.Value.RegistrationCode))).AllowAnonymous();
        group.MapPost("/register", RegisterAsync).AllowAnonymous().RequireRateLimiting("auth");
        group.MapPost("/login", LoginAsync).AllowAnonymous().RequireRateLimiting("auth");
        group.MapPost("/forgot-password", ForgotPasswordAsync).AllowAnonymous().RequireRateLimiting("auth");
        group.MapPost("/reset-password", ResetPasswordAsync).AllowAnonymous().RequireRateLimiting("auth");
        group.MapGet("/me", MeAsync).RequireAuthorization();

        return group;
    }

    private static async Task<IResult> RegisterAsync(
        RegisterRequest request,
        AgroSenseDbContext db,
        IPasswordHasher<User> hasher,
        StationService stations,
        TokenService tokens,
        IOptions<AppOptions> app,
        AuditService audit,
        CancellationToken ct)
    {
        var requiredCode = app.Value.RegistrationCode;
        if (!string.IsNullOrWhiteSpace(requiredCode) &&
            !CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(requiredCode.Trim()),
                Encoding.UTF8.GetBytes(request.InviteCode?.Trim() ?? string.Empty)))
        {
            return Problems.BadRequest("El código de invitación no es válido. Pídeselo al administrador del proyecto.");
        }

        var name = request.Name?.Trim() ?? string.Empty;
        var email = NormalizeEmail(request.Email);

        if (name.Length is < 2 or > 120) return Problems.BadRequest("Ingresa tu nombre completo.");
        if (email is null) return Problems.BadRequest("Ingresa un correo válido.");
        if ((request.Password?.Length ?? 0) < MinPasswordLength)
            return Problems.BadRequest($"La contraseña debe tener al menos {MinPasswordLength} caracteres.");
        if (await db.Users.AnyAsync(u => u.Email == email, ct))
            return Problems.Conflict("Ese correo ya está registrado.");

        Station station;
        if (string.IsNullOrWhiteSpace(request.StationCode))
        {
            station = await stations.GetOrCreateDefaultAsync(ct);
        }
        else
        {
            var code = StationService.NormalizeCode(request.StationCode);
            if (!StationService.IsValidCode(code))
                return Problems.BadRequest("El ID de estación solo puede tener minúsculas, números y guiones (3 a 40 caracteres).");
            station = await stations.GetOrCreateAsync(code, ct);
        }

        var user = new User { Name = name, Email = email };
        user.PasswordHash = hasher.HashPassword(user, request.Password!);
        db.Users.Add(user);
        await db.SaveChangesAsync(ct);
        var member = await stations.AddMemberAsync(user, station, ct);
        if (member is not null)
        {
            audit.Add(station, user, AuditService.Actions.MemberJoined,
                $"{user.Name} creó su cuenta y se unió como {(member.Role == StationRoles.Admin ? "administrador" : "solo lectura")}");
            await db.SaveChangesAsync(ct);
        }

        var (token, expires) = tokens.CreateToken(user, remember: true);
        return Results.Ok(new AuthResponse(token, expires, await ToDtoAsync(db, user.Id, ct)));
    }

    private static async Task<IResult> LoginAsync(
        LoginRequest request,
        AgroSenseDbContext db,
        IPasswordHasher<User> hasher,
        TokenService tokens,
        CancellationToken ct)
    {
        var email = NormalizeEmail(request.Email);
        var user = email is null ? null : await db.Users.FirstOrDefaultAsync(u => u.Email == email, ct);
        if (user is null || string.IsNullOrEmpty(request.Password))
            return Problems.Unauthorized("Correo o contraseña incorrectos.");

        var result = hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password);
        if (result == PasswordVerificationResult.Failed)
            return Problems.Unauthorized("Correo o contraseña incorrectos.");
        if (result == PasswordVerificationResult.SuccessRehashNeeded)
        {
            user.PasswordHash = hasher.HashPassword(user, request.Password);
            await db.SaveChangesAsync(ct);
        }

        var (token, expires) = tokens.CreateToken(user, request.Remember);
        return Results.Ok(new AuthResponse(token, expires, await ToDtoAsync(db, user.Id, ct)));
    }

    private static async Task<IResult> MeAsync(HttpContext http, AgroSenseDbContext db, CancellationToken ct)
    {
        var userId = http.User.GetUserId();
        if (!await db.Users.AnyAsync(u => u.Id == userId, ct)) return Results.Unauthorized();
        return Results.Ok(await ToDtoAsync(db, userId, ct));
    }

    private static async Task<IResult> ForgotPasswordAsync(
        ForgotPasswordRequest request,
        AgroSenseDbContext db,
        IEmailSender email,
        IOptions<AppOptions> app,
        TimeProvider clock,
        CancellationToken ct)
    {
        var address = NormalizeEmail(request.Email);
        var user = address is null ? null : await db.Users.FirstOrDefaultAsync(u => u.Email == address, ct);

        // Siempre se responde igual para no revelar qué correos están registrados.
        if (user is not null)
        {
            var token = TokenService.CreateOpaqueToken();
            user.PasswordResetTokenHash = TokenService.HashOpaqueToken(token);
            user.PasswordResetExpiresAt = clock.GetUtcNow().AddHours(1);
            await db.SaveChangesAsync(ct);

            var link = $"{app.Value.FrontendUrl.TrimEnd('/')}/restablecer?email={Uri.EscapeDataString(user.Email)}&token={token}";
            await email.SendAsync(user.Email, "AgroSense – Restablecer contraseña",
                $"Hola {user.Name},\n\nPara crear una nueva contraseña abre este enlace (válido por 1 hora):\n{link}\n\nSi no lo solicitaste, ignora este mensaje.", ct);
        }

        return Results.Accepted();
    }

    private static async Task<IResult> ResetPasswordAsync(
        ResetPasswordRequest request,
        AgroSenseDbContext db,
        IPasswordHasher<User> hasher,
        TimeProvider clock,
        CancellationToken ct)
    {
        var address = NormalizeEmail(request.Email);
        var user = address is null ? null : await db.Users.FirstOrDefaultAsync(u => u.Email == address, ct);
        var valid = user is { PasswordResetTokenHash: not null, PasswordResetExpiresAt: not null }
            && user.PasswordResetExpiresAt > clock.GetUtcNow()
            && !string.IsNullOrEmpty(request.Token)
            && user.PasswordResetTokenHash == TokenService.HashOpaqueToken(request.Token);

        if (!valid) return Problems.BadRequest("El enlace no es válido o ya expiró. Solicita uno nuevo.");
        if ((request.NewPassword?.Length ?? 0) < MinPasswordLength)
            return Problems.BadRequest($"La contraseña debe tener al menos {MinPasswordLength} caracteres.");

        user!.PasswordHash = hasher.HashPassword(user, request.NewPassword!);
        user.PasswordResetTokenHash = null;
        user.PasswordResetExpiresAt = null;
        await db.SaveChangesAsync(ct);
        return Results.NoContent();
    }

    public static async Task<UserDto> ToDtoAsync(AgroSenseDbContext db, Guid userId, CancellationToken ct)
    {
        var user = await db.Users.AsNoTracking().FirstAsync(u => u.Id == userId, ct);
        var stations = await db.StationMembers.AsNoTracking()
            .Where(m => m.UserId == userId)
            .OrderBy(m => m.JoinedAt)
            .Select(m => new StationRefDto(m.Station.Id, m.Station.Code, m.Station.Name))
            .ToListAsync(ct);
        return new UserDto(user.Id, user.Name, user.Email, stations);
    }

    private static string? NormalizeEmail(string? email)
    {
        if (string.IsNullOrWhiteSpace(email)) return null;
        var trimmed = email.Trim().ToLowerInvariant();
        return trimmed.Length <= 200 && MailAddress.TryCreate(trimmed, out var parsed) && parsed.Address == trimmed
            ? trimmed
            : null;
    }
}
