import { Eye, EyeOff, Lock } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'

import { useAuth } from '@/auth/AuthContext'
import { AuthCard, BrandMark } from '@/components/auth/AuthShell'

export function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const { login } = useAuth()
  const passwordReset = Boolean((location.state as { passwordReset?: boolean } | null)?.passwordReset)

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [remember, setRemember] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      await login(email, password, remember)
      navigate('/', { replace: true })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo iniciar sesión.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard>
      <div className="mb-6 flex justify-center">
        <BrandMark />
      </div>

      <h2 className="text-[1.65rem] font-bold tracking-tight text-slate-900">Iniciar Sesión</h2>
      <p className="mt-1 text-sm text-slate-500">Ingresa tus credenciales para acceder a tu estación</p>

      {passwordReset ? (
        <p className="mt-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-green-800">
          Contraseña actualizada. Ya puedes iniciar sesión.
        </p>
      ) : null}

      <form className="mt-6 space-y-4" onSubmit={(event) => void handleSubmit(event)}>
        <label className="block">
          <span className="mb-1.5 block text-sm text-slate-600">Correo electrónico</span>
          <input
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="tu@correo.com"
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#1a7a3a] focus:ring-2 focus:ring-[#1a7a3a]/15"
          />
        </label>

        <label className="block">
          <span className="mb-1.5 block text-sm text-slate-600">Contraseña</span>
          <div className="relative">
            <Lock size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="••••••••"
              className="w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-10 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#1a7a3a] focus:ring-2 focus:ring-[#1a7a3a]/15"
            />
            <button
              type="button"
              onClick={() => setShowPassword((current) => !current)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              aria-label={showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </label>

        <div className="flex items-center justify-between gap-3 pt-1">
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={remember}
              onChange={(event) => setRemember(event.target.checked)}
              className="h-4 w-4 rounded border-slate-300 accent-[#1a7a3a]"
            />
            Recordarme
          </label>
          <Link to="/recuperar" className="text-sm font-medium text-[#1a7a3a] hover:underline">
            ¿Olvidaste tu contraseña?
          </Link>
        </div>

        {error ? <p className="text-sm text-red-600">{error}</p> : null}

        <button
          type="submit"
          disabled={busy}
          className="mt-1 w-full rounded-lg bg-[#1a7a3a] py-2.5 text-sm font-semibold text-white transition hover:bg-[#166834] disabled:opacity-60"
        >
          {busy ? 'Ingresando...' : 'Entrar al Panel'}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-500">
        ¿No tienes una cuenta aún?{' '}
        <Link to="/registro" className="font-semibold text-[#1a7a3a] hover:underline">
          Regístrate aquí
        </Link>
      </p>
    </AuthCard>
  )
}
