// Simulador del ESP32 de AgroSense.
// Genera lecturas como lo haría el dispositivo real y aplica la misma lógica de riego
// (lee la configuración, enciende/apaga la bomba según la humedad del suelo).
//
// Modo API (sin Firebase):
//   dotnet run --project tools/AgroSense.Simulator -- --target api --interval 5
//
// Modo Firebase (igual que el ESP32: se autentica con Web API key + usuario del dispositivo):
//   dotnet run --project tools/AgroSense.Simulator -- --target firebase \
//       --db-url https://<proyecto>-default-rtdb.firebaseio.com \
//       --api-key <WEB_API_KEY> --email device-agrosense-01@agrosense.local --password <clave>

using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;

var options = ParseArgs(args);
string Opt(string key, string fallback) => options.TryGetValue(key, out var v) ? v : fallback;

var target = Opt("target", "api");
var station = Opt("station", "agrosense-01");
var interval = TimeSpan.FromSeconds(double.Parse(Opt("interval", "5"), System.Globalization.CultureInfo.InvariantCulture));
// Cuánto baja la humedad del suelo por lectura (acelerado para ver riegos en minutos y no en días).
var dryRate = double.Parse(Opt("dry-rate", "1.5"), System.Globalization.CultureInfo.InvariantCulture);

using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
IDeviceChannel channel = target switch
{
    "api" => new ApiChannel(http, Opt("api", "http://localhost:5080"), station, Opt("device-key", "dev-device-key")),
    "firebase" => new FirebaseChannel(http, Opt("db-url", ""), station, Opt("api-key", ""), Opt("email", ""), Opt("password", ""), Opt("secret", "")),
    _ => throw new ArgumentException("--target debe ser 'api' o 'firebase'"),
};

Console.WriteLine($"Simulador AgroSense → {target}, estación '{station}', cada {interval.TotalSeconds}s. Ctrl+C para salir.");
using var cts = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; cts.Cancel(); };

var random = new Random();
var soil = 45.0;
var pumpOn = false;
var pumpStartedAt = DateTimeOffset.MinValue;
// Una orden manual se ejecuta una sola vez: tras apagarse (por tiempo o suelo saturado) no se repite
// hasta que el dashboard la desactive y la vuelva a activar.
var manualConsumed = false;
var config = new DeviceConfig();
var statusSent = false;

// ---- Historia simulada (opcional): --backfill-days N [--backfill-only]
// Envía lecturas cada 10 min de los últimos N días con su fecha original, para que el análisis y los
// modelos de pronóstico tengan datos de inmediato. Solo con --target api (ingesta HTTP con "ts").
var backfillDays = int.Parse(Opt("backfill-days", "0"));
if (backfillDays > 0 && channel is ApiChannel api)
{
    var zone = TimeZoneInfo.FindSystemTimeZoneById("America/Santiago");
    var step = TimeSpan.FromMinutes(10);
    var end = DateTimeOffset.UtcNow.AddMinutes(-1);
    var start = end.AddDays(-backfillDays);
    start = new DateTimeOffset(start.UtcTicks - start.UtcTicks % step.Ticks, TimeSpan.Zero);
    var batch = new List<Dictionary<string, object?>>();
    var sent = 0;
    var irrigations = 0;

    Dictionary<string, object?> Sample(DateTimeOffset t, bool pump)
    {
        var local = TimeZoneInfo.ConvertTime(t, zone);
        var h = local.Hour + local.Minute / 60.0;
        var day = Math.Sin((h - 9) / 24 * 2 * Math.PI);
        var drift = Math.Sin((t - start).TotalDays / 5 * Math.PI) * 2; // variación de varios días
        var temp = Math.Round(19 + 7 * day + drift + Noise(0.3), 1);
        var hum = Math.Round(Math.Clamp(62 - 18 * day - drift * 2 + Noise(2), 20, 98));
        var lightPct = h is > 6.5 and < 20.5 ? Math.Clamp(85 * Math.Sin((h - 6.5) / 14 * Math.PI) + Noise(4), 0, 100) : 0;
        var lux = lightPct * 6 + 20;
        var bands = new Dictionary<string, double>
        {
            ["violet"] = Math.Round(lux * 0.17, 2), ["blue"] = Math.Round(lux * 0.19, 2), ["green"] = Math.Round(lux * 0.17, 2),
            ["yellow"] = Math.Round(lux * 0.18, 2), ["orange"] = Math.Round(lux * 0.14, 2), ["red"] = Math.Round(lux * 0.15, 2),
        };
        bands["total"] = Math.Round(bands.Values.Sum(), 2);
        var mq = Math.Round(1.1 + 0.3 * Math.Sin(h / 24 * 2 * Math.PI) + Noise(0.05), 3);
        return new Dictionary<string, object?>
        {
            ["id"] = $"bf-{t.ToUnixTimeMilliseconds()}",
            ["ts"] = t.ToUnixTimeMilliseconds(),
            ["temperature"] = temp,
            ["airHumidity"] = hum,
            ["soilMoisture"] = Math.Round(soil, 1),
            ["soilRaw"] = (int)Math.Round(3400 - soil * 25),
            ["spectral"] = bands,
            ["mq135"] = new Dictionary<string, object> { ["raw"] = (int)Math.Round(mq / 1.5 / 3.3 * 4095), ["adcVoltage"] = Math.Round(mq / 1.5, 3), ["sensorVoltage"] = mq },
            ["pumpOn"] = pump,
            ["pumpMode"] = "auto",
        };
    }

    async Task Flush()
    {
        if (batch.Count == 0) return;
        await api.SendBatchAsync(batch, cts.Token);
        sent += batch.Count;
        batch.Clear();
    }

    Console.WriteLine($"Generando historia simulada: {backfillDays} días desde {start:yyyy-MM-dd HH:mm} UTC...");
    soil = 55;
    for (var t = start; t < end; t += step)
    {
        // Secado: más rápido con calor (permite que el análisis encuentre la relación temperatura-secado).
        var temp = (double)Sample(t, false)["temperature"]!;
        soil -= dryRate * 60 * (0.4 + Math.Max(0, temp - 12) / 12) * (0.8 + random.NextDouble() * 0.4);
        soil = Math.Clamp(soil, 5, 95);
        batch.Add(Sample(t, false));

        if (soil < config.ActivationThreshold)
        {
            irrigations++;
            batch.Add(Sample(t.AddSeconds(20), true));
            soil = config.DeactivationThreshold + 2 + random.NextDouble() * 4;
            batch.Add(Sample(t.AddSeconds(20 + 80 + random.Next(40)), false));
        }
        if (batch.Count >= 500) await Flush();
    }
    await Flush();
    Console.WriteLine($"Historia simulada enviada: {sent} lecturas, {irrigations} riegos.");
    if (Opt("backfill-only", "false") == "true") return;
}

while (!cts.IsCancellationRequested)
{
    try
    {
        if (!statusSent)
        {
            await channel.SendStatusAsync(cts.Token);
            statusSent = true;
        }
        config = await channel.GetConfigAsync(cts.Token) ?? config;

        var now = DateTimeOffset.Now;
        var hour = now.Hour + now.Minute / 60.0;
        var dayFactor = Math.Sin((hour - 9) / 24 * 2 * Math.PI);
        var temperature = Math.Round(19 + 7 * dayFactor + Noise(0.3), 1);
        var humidity = Math.Round(Math.Clamp(62 - 18 * dayFactor + Noise(2), 20, 98));
        var light = hour is > 6.5 and < 20.5 ? Math.Round(Math.Clamp(85 * Math.Sin((hour - 6.5) / 14 * Math.PI) + Noise(4), 0, 100)) : 0;

        soil = pumpOn ? soil + 8 : soil - dryRate * (0.6 + random.NextDouble() * 0.8);
        soil = Math.Clamp(soil, 5, 95);

        // ---- misma lógica que debe tener el firmware
        var wasOn = pumpOn;
        var mode = config.AutoIrrigation ? "auto" : "manual";
        var pumpTooLong = pumpOn && (now - pumpStartedAt).TotalSeconds >= config.MaxPumpSeconds;
        if (config.AutoIrrigation)
        {
            if (!pumpOn && soil < config.ActivationThreshold) pumpOn = true;
            else if (pumpOn && (soil >= config.DeactivationThreshold || pumpTooLong)) pumpOn = false;
        }
        else
        {
            if (!config.ManualPump) manualConsumed = false;
            var wantsPump = config.ManualPump && !manualConsumed;
            if (pumpOn && (pumpTooLong || soil >= 95)) manualConsumed = true;
            pumpOn = wantsPump && !manualConsumed;
        }
        if (pumpOn && !wasOn) pumpStartedAt = now;

        // Mismo formato que el firmware real (agrosense-sensors-1.0): SHT3x, suelo, AS7262 y MQ135.
        var lux = light * 6 + 20;
        var spectral = new Dictionary<string, double>
        {
            ["violet"] = Math.Round(lux * 0.17 + Noise(2), 2),
            ["blue"] = Math.Round(lux * 0.19 + Noise(2), 2),
            ["green"] = Math.Round(lux * 0.17 + Noise(2), 2),
            ["yellow"] = Math.Round(lux * 0.18 + Noise(2), 2),
            ["orange"] = Math.Round(lux * 0.14 + Noise(2), 2),
            ["red"] = Math.Round(lux * 0.15 + Noise(2), 2),
        };
        spectral["total"] = Math.Round(spectral.Values.Sum(), 2);
        var mqVoltage = Math.Round(1.1 + 0.3 * Math.Sin(hour / 24 * 2 * Math.PI) + Noise(0.05), 3);

        var reading = new Dictionary<string, object?>
        {
            ["temperature"] = temperature,
            ["airHumidity"] = humidity,
            ["soilMoisture"] = Math.Round(soil, 1),
            ["soilRaw"] = (int)Math.Round(3400 - soil * 25),
            ["spectral"] = spectral,
            ["mq135"] = new Dictionary<string, object>
            {
                ["raw"] = (int)Math.Round(mqVoltage / 1.5 / 3.3 * 4095),
                ["adcVoltage"] = Math.Round(mqVoltage / 1.5, 3),
                ["sensorVoltage"] = mqVoltage,
            },
            ["pumpOn"] = pumpOn,
            ["pumpMode"] = mode,
        };
        await channel.SendReadingAsync(reading, cts.Token);
        await channel.SendStatusAsync(cts.Token);

        Console.WriteLine($"{now:HH:mm:ss}  T={temperature,5:0.0}°C  HR={humidity,3}%  suelo={soil,5:0.0}%  luz={spectral["total"],6:0}µW  MQ135={mqVoltage:0.00}V  bomba={(pumpOn ? "ON " : "off")} ({mode})");
        await Task.Delay(interval, cts.Token);
    }
    catch (OperationCanceledException) when (cts.IsCancellationRequested)
    {
        break;
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error: {ex.Message}. Reintentando…");
        await Task.Delay(TimeSpan.FromSeconds(5), CancellationToken.None);
    }
}

double Noise(double scale) => (random.NextDouble() * 2 - 1) * scale;

static Dictionary<string, string> ParseArgs(string[] args)
{
    var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    for (var i = 0; i < args.Length; i++)
    {
        if (!args[i].StartsWith("--")) continue;
        var key = args[i][2..];
        result[key] = i + 1 < args.Length && !args[i + 1].StartsWith("--") ? args[++i] : "true";
    }
    return result;
}

record DeviceConfig
{
    public bool AutoIrrigation { get; init; } = true;
    public double ActivationThreshold { get; init; } = 30;
    public double DeactivationThreshold { get; init; } = 60;
    public int MaxPumpSeconds { get; init; } = 120;
    public bool ManualPump { get; init; }
}

interface IDeviceChannel
{
    Task<DeviceConfig?> GetConfigAsync(CancellationToken ct);
    Task SendReadingAsync(Dictionary<string, object?> reading, CancellationToken ct);
    Task SendStatusAsync(CancellationToken ct);
}

/// <summary>Ingesta HTTP directa contra la API (/api/devices/{code}/...).</summary>
class ApiChannel(HttpClient http, string baseUrl, string station, string deviceKey) : IDeviceChannel
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private DeviceConfig? _lastConfig;

    public Task<DeviceConfig?> GetConfigAsync(CancellationToken ct) => Task.FromResult(_lastConfig);

    public async Task SendReadingAsync(Dictionary<string, object?> reading, CancellationToken ct)
    {
        reading["id"] = Guid.NewGuid().ToString("N");
        using var response = await http.SendAsync(Request(HttpMethod.Post, "readings", reading), ct);
        response.EnsureSuccessStatusCode();
        var body = await response.Content.ReadFromJsonAsync<JsonObject>(Json, ct);
        _lastConfig = body?["config"].Deserialize<DeviceConfig>(Json);
    }

    public async Task SendStatusAsync(CancellationToken ct)
    {
        using var response = await http.SendAsync(Request(HttpMethod.Post, "status", Status()), ct);
        response.EnsureSuccessStatusCode();
        _lastConfig = await response.Content.ReadFromJsonAsync<DeviceConfig>(Json, ct);
    }

    /// <summary>Envía varias lecturas en una sola petición (la API acepta hasta 1000).</summary>
    public async Task SendBatchAsync(IReadOnlyCollection<Dictionary<string, object?>> readings, CancellationToken ct)
    {
        using var response = await http.SendAsync(Request(HttpMethod.Post, "readings", readings), ct);
        response.EnsureSuccessStatusCode();
    }

    private HttpRequestMessage Request(HttpMethod method, string path, object body)
    {
        var request = new HttpRequestMessage(method, $"{baseUrl.TrimEnd('/')}/api/devices/{station}/{path}")
        {
            Content = JsonContent.Create(body, options: Json),
        };
        request.Headers.Add("X-Device-Key", deviceKey);
        return request;
    }

    public static object Status() => new { mac = "SIM:00:00:00:00:01", ip = "127.0.0.1", rssi = -55, firmware = "simulador-1.0" };
}

/// <summary>Escribe en Firebase Realtime Database igual que el ESP32 con la librería Firebase ESP Client.</summary>
class FirebaseChannel(HttpClient http, string dbUrl, string station, string apiKey, string email, string password, string secret) : IDeviceChannel
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
    private string? _idToken;
    private DateTimeOffset _tokenExpires;

    public async Task<DeviceConfig?> GetConfigAsync(CancellationToken ct)
    {
        var node = await http.GetFromJsonAsync<JsonNode>(await UrlAsync("config", ct), ct);
        return node?.Deserialize<DeviceConfig>(Json);
    }

    public async Task SendReadingAsync(Dictionary<string, object?> reading, CancellationToken ct)
    {
        // POST = push(): Firebase genera una clave cronológica; ts lo pone el servidor de Firebase.
        reading["ts"] = new Dictionary<string, string> { [".sv"] = "timestamp" };
        using var response = await http.PostAsJsonAsync(await UrlAsync("readings", ct), reading, Json, ct);
        await EnsureAsync(response, ct);
    }

    public async Task SendStatusAsync(CancellationToken ct)
    {
        var status = new Dictionary<string, object>
        {
            ["mac"] = "SIM:00:00:00:00:01",
            ["ip"] = "127.0.0.1",
            ["rssi"] = -55,
            ["firmware"] = "simulador-1.0",
            ["lastSeen"] = new Dictionary<string, string> { [".sv"] = "timestamp" },
        };
        using var response = await http.PutAsJsonAsync(await UrlAsync("status", ct), status, Json, ct);
        await EnsureAsync(response, ct);
    }

    private async Task<string> UrlAsync(string path, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(dbUrl)) throw new ArgumentException("Falta --db-url");
        var url = $"{dbUrl.TrimEnd('/')}/stations/{station}/{path}.json";
        if (!string.IsNullOrEmpty(secret)) return $"{url}?auth={Uri.EscapeDataString(secret)}";
        if (string.IsNullOrEmpty(apiKey)) return url; // reglas abiertas (modo prueba)
        return $"{url}?auth={Uri.EscapeDataString(await TokenAsync(ct))}";
    }

    /// <summary>Inicia sesión con correo/contraseña (Firebase Auth) como lo hace el ESP32.</summary>
    private async Task<string> TokenAsync(CancellationToken ct)
    {
        if (_idToken is not null && DateTimeOffset.UtcNow < _tokenExpires) return _idToken;
        using var response = await http.PostAsJsonAsync(
            $"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={apiKey}",
            new { email, password, returnSecureToken = true }, ct);
        await EnsureAsync(response, ct);
        var body = await response.Content.ReadFromJsonAsync<JsonObject>(ct);
        _idToken = body!["idToken"]!.GetValue<string>();
        _tokenExpires = DateTimeOffset.UtcNow.AddSeconds(int.Parse(body["expiresIn"]!.GetValue<string>()) - 120);
        return _idToken;
    }

    private static async Task EnsureAsync(HttpResponseMessage response, CancellationToken ct)
    {
        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"{(int)response.StatusCode}: {await response.Content.ReadAsStringAsync(ct)}");
    }
}
