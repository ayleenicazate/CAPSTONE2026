using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using AgroSense.Api.Data;
using AgroSense.Api.Firebase;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Stations;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Ingestion;

/// <summary>
/// Alternativa a Firebase: el ESP32 (o el simulador) envía las lecturas directo por HTTP.
/// Se autentica con la cabecera X-Device-Key.
/// </summary>
public static class DeviceEndpoints
{
    public static RouteGroupBuilder MapDeviceEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/devices/{code}").WithTags("Dispositivo (ingesta HTTP)").AllowAnonymous();

        group.AddEndpointFilter(async (context, next) =>
        {
            var http = context.HttpContext;
            var expected = http.RequestServices.GetRequiredService<IOptions<DeviceIngestOptions>>().Value.DeviceKey;
            var provided = http.Request.Headers["X-Device-Key"].ToString();
            if (string.IsNullOrEmpty(expected) || !FixedTimeEquals(expected, provided))
                return Problems.Unauthorized("Clave de dispositivo inválida o ingesta HTTP desactivada (DeviceIngest:DeviceKey).");
            if (!StationService.IsValidCode(StationService.NormalizeCode((string)http.Request.RouteValues["code"]!)))
                return Problems.BadRequest("Código de estación inválido.");
            return await next(context);
        });

        group.MapPost("/readings", PostReadingsAsync);
        group.MapPost("/status", PostStatusAsync);
        group.MapGet("/config", async (string code, StationService stations, CancellationToken ct) =>
            DeviceConfig.From(await stations.GetOrCreateAsync(code, ct)));

        return group;
    }

    /// <summary>Acepta una lectura (objeto) o varias (arreglo). Campo opcional "id" para evitar duplicados al reintentar.</summary>
    private static async Task<IResult> PostReadingsAsync(
        string code, JsonNode? body, StationService stations, IngestionService ingestion, TimeProvider clock, CancellationToken ct)
    {
        var items = body switch
        {
            JsonArray array => array.ToList(),
            JsonObject obj => [obj],
            _ => [],
        };
        if (items.Count is 0 or > 1000) return Problems.BadRequest("Envía un objeto de lectura o un arreglo de 1 a 1000 lecturas.");

        var now = clock.GetUtcNow();
        var readings = items
            .Select(item =>
            {
                var id = item?["id"] is JsonValue v && v.GetValueKind() == JsonValueKind.String ? v.GetValue<string>() : null;
                var key = string.IsNullOrWhiteSpace(id) ? $"http-{Guid.CreateVersion7(now):N}" : $"http-{id[..Math.Min(id.Length, 58)]}";
                return ReadingParser.Parse(key, item, now);
            })
            .OfType<IncomingReading>()
            .ToList();
        if (readings.Count == 0) return Problems.BadRequest("Ninguna lectura contenía variables reconocidas.");

        var station = await stations.GetOrCreateAsync(code, ct);
        var inserted = await ingestion.IngestAsync(station, readings, ct);
        return Results.Ok(new { received = items.Count, inserted, config = DeviceConfig.From(station) });
    }

    private static async Task<IResult> PostStatusAsync(
        string code, JsonNode? body, StationService stations, AgroSenseDbContext db, TimeProvider clock, CancellationToken ct)
    {
        var station = await stations.GetOrCreateAsync(code, ct);
        var status = ReadingParser.ParseStatus(body);
        IngestionService.ApplyStatus(station, status with { LastSeen = status.LastSeen ?? clock.GetUtcNow() }, clock.GetUtcNow());
        await db.SaveChangesAsync(ct);
        return Results.Ok(DeviceConfig.From(station));
    }

    private static bool FixedTimeEquals(string a, string b) =>
        CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(a), Encoding.UTF8.GetBytes(b));
}
