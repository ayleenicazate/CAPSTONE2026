import { BarChart3, BrainCircuit, Droplets, History, LayoutDashboard, LogOut, Settings, Sprout, X } from 'lucide-react'
import { NavLink } from 'react-router-dom'

import { useAuth } from '@/auth/AuthContext'

const navItems: Array<{
  label: string
  path: string
  icon: typeof LayoutDashboard
}> = [
  { label: 'Resumen', path: '/', icon: LayoutDashboard },
  { label: 'Sensores', path: '/sensores', icon: BarChart3 },
  { label: 'Riego', path: '/riego', icon: Droplets },
  { label: 'Historial', path: '/historial', icon: History },
  { label: 'Análisis', path: '/analisis', icon: BrainCircuit },
  { label: 'Configuración', path: '/configuracion', icon: Settings },
]

function SidebarContent({ onNavigate, onClose }: { onNavigate?: () => void; onClose?: () => void }) {
  const { user, logout } = useAuth()
  const name = user?.name ?? 'Usuario'
  const initial = name.charAt(0).toUpperCase()

  return (
    <div className="flex h-full flex-col px-5 py-6">
      <div className="mb-8 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-green-700 text-white">
            <Sprout size={20} />
          </div>
          <p className="text-2xl font-bold tracking-tight text-slate-900">AgroSense</p>
        </div>
        {onClose ? (
          <button type="button" onClick={onClose} className="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Cerrar menú">
            <X size={20} />
          </button>
        ) : null}
      </div>

      <nav className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              onClick={onNavigate}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition ${
                  isActive ? 'bg-emerald-50 text-green-800' : 'text-slate-600 hover:bg-slate-50'
                }`
              }
            >
              <Icon size={18} />
              {item.label}
            </NavLink>
          )
        })}
      </nav>

      <div className="mt-auto rounded-2xl bg-slate-50 p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-green-700 text-sm font-semibold text-white">
            {initial}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-800">{name}</p>
            <p className="truncate text-xs text-slate-500" title={user?.email}>
              {user?.email}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={logout}
          className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-600 transition hover:bg-slate-100"
        >
          <LogOut size={14} />
          Cerrar sesión
        </button>
      </div>
    </div>
  )
}

/** Barra lateral fija en pantallas grandes. */
export function AppSidebar() {
  return (
    <aside className="sticky top-0 hidden h-screen w-60 shrink-0 border-r border-slate-200 bg-white lg:block">
      <SidebarContent />
    </aside>
  )
}

/** Menú deslizable para celulares y tablets. */
export function MobileSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true">
      <button type="button" className="absolute inset-0 bg-slate-900/40" onClick={onClose} aria-label="Cerrar menú" />
      <aside className="relative h-full w-72 max-w-[85vw] bg-white shadow-xl">
        <SidebarContent onNavigate={onClose} onClose={onClose} />
      </aside>
    </div>
  )
}
