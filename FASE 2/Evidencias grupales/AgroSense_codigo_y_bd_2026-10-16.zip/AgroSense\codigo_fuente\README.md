# AgroSense – Estación agroambiental IoT

MVP de una estación agroambiental: un ESP32 mide temperatura, humedad ambiental, humedad del suelo y
luminosidad, controla una bomba de riego y envía los datos a Firebase. El backend en C# los guarda en
PostgreSQL, calcula métricas y estimaciones, y el dashboard en React los muestra.

```
Sensores → ESP32 → Firebase Realtime DB → Backend .NET (worker) → PostgreSQL → API REST → Dashboard React
                        ▲                                   │   └──(cada 5 min)──► BigQuery (histórico y ML)
                        └──── config de riego (umbrales) ◄──┘
```

Pensado para lecturas cada 2–3 s: el backend consulta Firebase cada 2 s, guarda resúmenes por minuto
para los gráficos, conserva 30 días de lecturas crudas en PostgreSQL y envía el histórico completo a
BigQuery. Ver [docs/bigquery.md](docs/bigquery.md).

## Estructura

| Carpeta | Contenido |
|---------|-----------|
| `src/` | Frontend React + Vite + Tailwind + React Query |
| `backend/src/AgroSense.Api` | API ASP.NET Core (.NET 10): auth JWT, ingesta, métricas, estimaciones |
| `backend/tools/AgroSense.Simulator` | Simulador del ESP32 (escribe en Firebase o directo a la API) |
| `backend/tests/AgroSense.Api.Tests` | Tests unitarios (xUnit) |
| `firebase/database.rules.json` | Reglas de seguridad de Realtime Database |
| `docs/firebase-contrato-dispositivo.md` | **Contrato de datos para quien programa el ESP32** |
| `docs/bigquery.md` | BigQuery: permisos, tablas, consultas de análisis y pronóstico con BigQuery ML |
| `docker-compose.yml` | PostgreSQL local |

## Requisitos

- .NET SDK 10
- Node.js 20+
- Docker Desktop (para PostgreSQL)

## Puesta en marcha (desarrollo)

```bash
# 1. Base de datos (puerto 5434) + API (http://localhost:5080, documentación en /docs)
docker compose up -d --build

# 2. Frontend → http://localhost:5173
npm install
npm run dev
```

La API corre en Docker porque **Smart App Control** de Windows 11 bloquea las DLL recién compiladas
(error *"Una directiva de Control de aplicaciones bloqueó este archivo"*). Si no tienes ese problema,
también puedes correrla directo con `cd backend && dotnet run --project src/AgroSense.Api`, después de
levantar solo la base con `docker compose up -d postgres`.

Después de cambiar código del backend: `docker compose up -d --build api`. Logs: `docker logs -f agrosense-api`.

Al arrancar en modo Development, el backend aplica las migraciones y crea:

- La estación `agrosense-01` con **14 días de histórico sintético**.
- El usuario demo **demo@agrosense.cl / Demo12345**.

Se configura en `backend/src/AgroSense.Api/appsettings.Development.json` (sección `Seed`).

### Datos en vivo sin el dispositivo

```bash
# Contra la API local (Ctrl+C para detener)
docker compose --profile simulator up simulator

# Contra Firebase, igual que el ESP32 (los datos llegan también a producción)
docker compose run --rm simulator --target firebase --interval 10 \
  --db-url https://<proyecto>-default-rtdb.firebaseio.com \
  --api-key <WEB_API_KEY> --email device-agrosense-01@agrosense.local --password '<clave>'
```

El simulador envía el mismo formato que el firmware real (SHT3x, suelo, AS7262, MQ135, bomba) y aplica
la misma lógica de riego que el ESP32, así que los cambios de umbrales o el riego manual desde el
dashboard se ven reflejados de inmediato. Corre en Docker porque Smart App Control bloquea los
ejecutables recién compilados.

## Conectar Firebase

1. En el proyecto de Firebase: **Realtime Database** → crear base de datos.
2. **Authentication** → habilitar *Correo/contraseña* → crear el usuario del dispositivo
   `device-agrosense-01@agrosense.local`.
3. **Realtime Database → Reglas** → pegar `firebase/database.rules.json`.
4. **Configuración del proyecto → Cuentas de servicio** → *Generar nueva clave privada*. Guardar el JSON
   **fuera del repositorio** (nunca subirlo a GitHub).
5. Copiar `docker-compose.override.example.yml` como `docker-compose.override.yml` (ya está en `.gitignore`),
   poner la URL de la base y la ruta al JSON, y ejecutar `docker compose up -d --build`.
   Si corres la API sin Docker, usa *user-secrets*:

   ```bash
   cd backend/src/AgroSense.Api
   dotnet user-secrets set "Firebase:DatabaseUrl" "https://<proyecto>-default-rtdb.firebaseio.com"
   dotnet user-secrets set "Firebase:ServiceAccountPath" "C:/ruta/segura/agrosense-service-account.json"
   ```

6. A quien programa el ESP32 hay que darle: Web API key, URL de la base de datos, usuario y contraseña del
   dispositivo, y el documento `docs/firebase-contrato-dispositivo.md`.

El worker del backend revisa Firebase cada 10 s, crea automáticamente las estaciones nuevas que encuentre
y publica en `/stations/{id}/config` los umbrales de riego.

## Métricas y estimaciones

- **Estado por variable** (normal / bajo / alto) según rangos agronómicos y los umbrales de la estación.
- **Déficit de presión de vapor (VPD)** y **punto de rocío**, calculados a partir de la temperatura y la humedad.
- **Agregados por período**: 24 h (por hora), 7 días (cada 6 h), 30 días (diario); mínimo, máximo, promedio y tendencia.
- **Próximo riego estimado**: regresión lineal de la humedad del suelo desde el último riego.
- **Pronóstico a 24 h**: perfil horario de los últimos 7 días ajustado al nivel actual (temperatura, humedad, luz).
- **Riego**: ciclos derivados del estado de la bomba, con duración, humedad inicial/final y agua estimada (caudal configurable).
- **Exportación CSV** de las lecturas.

## Ingesta HTTP directa (alternativa a Firebase)

Si en algún momento se prefiere que el ESP32 envíe directo al backend:

```
POST /api/devices/{id}/readings    Header: X-Device-Key: <clave>
POST /api/devices/{id}/status
GET  /api/devices/{id}/config
```

La clave se configura en `DeviceIngest:DeviceKey`.

## Tests

```bash
cd backend
dotnet test
```

## Producción

Guía completa para publicar en un VPS de Hostinger con HTTPS: **[docs/despliegue-hostinger.md](docs/despliegue-hostinger.md)**.
Resumen: `docker compose -f docker-compose.prod.yml --env-file .env.prod up -d --build`, con la configuración
en `.env.prod` (plantilla en `deploy/env.prod.example`). En producción el registro exige un código de
invitación (`REGISTRATION_CODE`) y no se crean datos ni usuarios demo.

El envío de correos para recuperar contraseña está implementado con un remitente de desarrollo que escribe
el enlace en la consola del backend (`LoggingEmailSender`). Para enviarlos de verdad hay que registrar una
implementación SMTP de `IEmailSender`.
