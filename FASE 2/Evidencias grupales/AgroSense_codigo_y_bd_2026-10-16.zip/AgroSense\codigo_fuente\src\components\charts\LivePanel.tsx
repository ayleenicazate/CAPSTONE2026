import { Activity, Radio } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatTime, formatValue } from '@/lib/format'
import { useLiveStream, type LiveStatus } from '@/services/useLiveStream'
import type { LiveReading, StationInfo } from '@/types/api'

const LIVE_MINUTES = 5
const WINDOW_MS = LIVE_MINUTES * 60_000

const VARIABLES: Array<{ key: keyof LiveReading; label: string; unit: string; digits: number }> = [
  { key: 'temperature', label: 'Temperatura', unit: '°C', digits: 1 },
  { key: 'airHumidity', label: 'Humedad ambiental', unit: '%', digits: 1 },
  { key: 'soilMoisture', label: 'Humedad del suelo', unit: '%', digits: 1 },
  { key: 'light', label: 'Luz (AS7262)', unit: 'µW/cm²', digits: 0 },
  { key: 'airQuality', label: 'Calidad del aire', unit: 'V', digits: 2 },
]

const STATUS: Record<LiveStatus, { label: string; tone: 'success' | 'warning' | 'neutral' }> = {
  live: { label: 'Tiempo real', tone: 'success' },
  polling: { label: 'Reconectando…', tone: 'warning' },
  connecting: { label: 'Conectando…', tone: 'neutral' },
}

/** Reloj que avanza cada segundo: hace que los gráficos se desplacen de forma continua. */
function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs)
    return () => clearInterval(id)
  }, [intervalMs])
  return now
}

/**
 * Lecturas de los últimos minutos en tiempo real: el servidor empuja cada lectura apenas llega y la
 * ventana de tiempo se desplaza cada segundo. Un mini-gráfico por variable (cada uno con su escala).
 */
export function LivePanel({ station }: { station: StationInfo }) {
  const { readings, latest, status } = useLiveStream(station, LIVE_MINUTES)
  const now = useNow()
  const from = now - WINDOW_MS
  const visible = readings.filter((r) => new Date(r.timestamp).getTime() >= from)
  const latestMs = latest ? new Date(latest.timestamp).getTime() : null
  const online = latestMs !== null && now - latestMs < Math.max(30_000, station.readingIntervalSeconds * 3000)
  const secondsAgo = latestMs === null ? null : Math.max(0, Math.round((now - latestMs) / 1000))
  const badge = STATUS[status]

  return (
    <Card>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="relative flex h-3 w-3">
            {online ? <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-500 opacity-60" /> : null}
            <span className={`relative inline-flex h-3 w-3 rounded-full ${online ? 'bg-green-600' : 'bg-slate-400'}`} />
          </span>
          <div>
            <h3 className="flex items-center gap-2 text-lg font-semibold text-slate-800">
              En vivo
              <Badge tone={badge.tone}>
                <Radio size={12} className="mr-1" />
                {badge.label}
              </Badge>
            </h3>
            <p className="text-sm text-slate-500">
              Últimos {LIVE_MINUTES} minutos · {visible.length} lecturas · el dispositivo envía cada {station.readingIntervalSeconds} s
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <Activity size={16} className="text-green-700" />
          {latest ? (
            <span className="tabular-nums">
              Última lectura: {formatTime(latest.timestamp)} · hace {secondsAgo} s
            </span>
          ) : (
            'Sin lecturas'
          )}
          {latest?.pumpOn ? <Badge tone="info">Regando</Badge> : null}
        </div>
      </div>

      {visible.length === 0 ? (
        <p className="py-6 text-center text-sm text-slate-400">
          No hay lecturas en los últimos {LIVE_MINUTES} minutos. Cuando el dispositivo envíe datos aparecerán aquí al instante.
        </p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
          {VARIABLES.map((variable) => {
            const series = visible
              .filter((r) => r[variable.key] !== null)
              .map((r) => ({ t: new Date(r.timestamp).getTime(), value: r[variable.key] as number }))
            const current = series.at(-1)?.value ?? null
            const saturated = variable.key === 'airQuality' && latest?.airQualitySaturated

            return (
              <div key={variable.key} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3">
                <p className="text-xs font-medium text-slate-500">{variable.label}</p>
                <p className="mt-1 text-xl font-semibold tabular-nums text-slate-800">
                  {saturated ? 'Saturado' : formatValue(current, variable.unit, variable.digits)}
                </p>
                <div className="mt-2 h-16">
                  {series.length > 1 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={series} margin={{ top: 4, right: 2, left: 2, bottom: 0 }}>
                        {/* Ventana fija [ahora − 5 min, ahora]: avanza cada segundo aunque no lleguen datos. */}
                        <XAxis dataKey="t" type="number" scale="time" domain={[from, now]} allowDataOverflow hide />
                        <YAxis hide domain={['dataMin', 'dataMax']} />
                        <Tooltip
                          {...tooltipStyle}
                          cursor={{ stroke: chart.axis, strokeDasharray: '3 3' }}
                          labelFormatter={(t) =>
                            new Date(Number(t)).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                          }
                          formatter={(value: number) => [formatValue(value, variable.unit, variable.digits), variable.label]}
                        />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke={chart.series}
                          strokeWidth={2}
                          dot={false}
                          isAnimationActive={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <p className="pt-5 text-center text-xs text-slate-400">{saturated ? 'Lecturas no válidas' : 'Esperando datos…'}</p>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
