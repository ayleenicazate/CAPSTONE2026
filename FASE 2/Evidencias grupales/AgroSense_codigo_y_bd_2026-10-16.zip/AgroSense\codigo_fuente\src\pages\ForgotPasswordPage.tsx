import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'

import { AuthCard, BrandMark } from '@/components/auth/AuthShell'
import { api } from '@/services/api'

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      await api.forgotPassword(email.trim())
      setSent(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo enviar la solicitud.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard>
      <div className="mb-6 flex justify-center">
        <BrandMark />
      </div>
      <h2 className="text-[1.65rem] font-bold tracking-tight text-slate-900">Recuperar contraseña</h2>
      <p className="mt-1 text-sm text-slate-500">Te indicamos cómo volver a entrar a tu estación</p>

      {sent ? (
        <p className="mt-6 rounded-lg bg-emerald-50 px-3 py-3 text-sm leading-relaxed text-green-800">
          Si la cuenta existe, enviamos a <span className="font-semibold">{email}</span> un enlace para crear una nueva
          contraseña. El enlace vence en 1 hora.
        </p>
      ) : (
        <form className="mt-6 space-y-4" onSubmit={(event) => void handleSubmit(event)}>
          <label className="block">
            <span className="mb-1.5 block text-sm text-slate-600">Correo electrónico</span>
            <input
              type="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="tu@correo.com"
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#1a7a3a] focus:ring-2 focus:ring-[#1a7a3a]/15"
            />
          </label>
          {error ? <p className="text-sm text-red-600">{error}</p> : null}
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-lg bg-[#1a7a3a] py-2.5 text-sm font-semibold text-white transition hover:bg-[#166834] disabled:opacity-60"
          >
            {busy ? 'Enviando...' : 'Enviar instrucciones'}
          </button>
        </form>
      )}

      <p className="mt-6 text-center text-sm text-slate-500">
        <Link to="/login" className="font-semibold text-[#1a7a3a] hover:underline">
          Volver a iniciar sesión
        </Link>
      </p>
    </AuthCard>
  )
}
