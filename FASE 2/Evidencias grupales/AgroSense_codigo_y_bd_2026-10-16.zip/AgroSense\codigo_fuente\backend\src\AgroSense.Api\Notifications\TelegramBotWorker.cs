using System.Globalization;
using System.Text.Json.Nodes;
using AgroSense.Api.Data;
using AgroSense.Api.Stations;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Notifications;

/// <summary>
/// Escucha los mensajes del bot de Telegram (long polling):
/// <list type="bullet">
/// <item><c>/start CÓDIGO</c> o <c>/vincular CÓDIGO</c>: vincula el chat (personal o grupo) a una estación.</item>
/// <item><c>/estado</c>: responde con las últimas lecturas de la estación vinculada.</item>
/// </list>
/// </summary>
public class TelegramBotWorker(
    IServiceScopeFactory scopes,
    TelegramClient telegram,
    TimeProvider clock,
    ILogger<TelegramBotWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!telegram.Enabled)
        {
            logger.LogInformation("Telegram desactivado (Telegram:BotToken vacío).");
            return;
        }

        long offset = 0;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var updates = await telegram.GetUpdatesAsync(offset, 25, stoppingToken);
                foreach (var update in updates)
                {
                    offset = Math.Max(offset, update!["update_id"]!.GetValue<long>() + 1);
                    if (update["message"] is JsonObject message) await HandleAsync(message, stoppingToken);
                }
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogWarning(ex, "Error leyendo mensajes de Telegram; se reintentará");
                await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
            }
        }
    }

    private async Task HandleAsync(JsonObject message, CancellationToken ct)
    {
        var text = message["text"]?.GetValue<string>()?.Trim();
        var chat = message["chat"] as JsonObject;
        if (string.IsNullOrEmpty(text) || chat is null) return;
        var chatId = chat["id"]!.GetValue<long>();
        var chatTitle = chat["title"]?.GetValue<string>()
            ?? string.Join(' ', new[] { chat["first_name"]?.GetValue<string>(), chat["last_name"]?.GetValue<string>() }.Where(s => !string.IsNullOrEmpty(s)));

        // "/vincular@AgroSenseBot ABC123" en grupos → comando "vincular", argumento "ABC123".
        var parts = text.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var command = parts[0].Split('@')[0].ToLowerInvariant();
        var argument = parts.Length > 1 ? parts[1].ToUpperInvariant() : null;

        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();

        switch (command)
        {
            case "/start" or "/vincular" when argument is not null:
                await LinkAsync(db, scope.ServiceProvider.GetRequiredService<AuditService>(), chatId, chatTitle, argument, ct);
                break;
            case "/estado":
                await StatusAsync(db, scope.ServiceProvider.GetRequiredService<DashboardService>(), chatId, ct);
                break;
            case "/start" or "/ayuda" or "/help":
                await telegram.SendMessageAsync(chatId,
                    "Hola, soy el bot de <b>AgroSense</b>.\n\nPara recibir alertas, entra al panel → Configuración → Notificaciones → "
                    + "<b>Vincular Telegram</b>.\n\n/estado – últimas lecturas de la estación vinculada", ct);
                break;
        }
    }

    private async Task LinkAsync(AgroSenseDbContext db, AuditService audit, long chatId, string chatTitle, string code, CancellationToken ct)
    {
        var now = clock.GetUtcNow();
        var station = await db.Stations.FirstOrDefaultAsync(s => s.TelegramLinkCode == code && s.TelegramLinkExpiresAt > now, ct);
        if (station is null)
        {
            await telegram.SendMessageAsync(chatId, "El código no es válido o ya venció. Genera uno nuevo en el panel.", ct);
            return;
        }

        station.TelegramChatId = chatId;
        station.TelegramChatTitle = string.IsNullOrWhiteSpace(chatTitle) ? $"chat {chatId}" : chatTitle;
        station.TelegramLinkCode = null;
        station.TelegramLinkExpiresAt = null;
        audit.Add(station, null, AuditService.Actions.TelegramLinked, $"Telegram vinculado al chat \"{station.TelegramChatTitle}\"");
        await db.SaveChangesAsync(ct);

        await telegram.SendMessageAsync(chatId,
            $"✅ Este chat quedó vinculado a la estación <b>{station.Name}</b>.\nAquí llegarán las alertas. Escribe /estado para ver las últimas lecturas.", ct);
        logger.LogInformation("Telegram vinculado: estación {Code} → chat {Chat}", station.Code, chatId);
    }

    private async Task StatusAsync(AgroSenseDbContext db, DashboardService dashboard, long chatId, CancellationToken ct)
    {
        var station = await db.Stations.FirstOrDefaultAsync(s => s.TelegramChatId == chatId, ct);
        if (station is null)
        {
            await telegram.SendMessageAsync(chatId, "Este chat no está vinculado a ninguna estación.", ct);
            return;
        }

        var summary = await dashboard.GetSummaryAsync(station, ct);
        var es = CultureInfo.GetCultureInfo("es-CL");
        var lines = summary.Metrics
            .Where(m => m.Value is not null)
            .Select(m => $"• {m.Label}: <b>{m.Value!.Value.ToString(m.Unit is "kPa" or "V" ? "0.00" : "0.#", es)} {m.Unit}</b>"
                + (m.Status is null ? "" : $" ({m.Status.Label})"));
        var pump = summary.Irrigation.PumpOn ? "regando" : "detenida";
        var state = summary.Station.Online ? "🟢 en línea" : "🔴 fuera de línea";
        await telegram.SendMessageAsync(chatId,
            $"<b>{station.Name}</b> · {state}\n{string.Join('\n', lines)}\n• Bomba: <b>{pump}</b>"
            + (summary.Alerts.Count == 0 ? "" : $"\n\n⚠️ {string.Join("\n⚠️ ", summary.Alerts.Select(a => a.Title))}"), ct);
    }
}
