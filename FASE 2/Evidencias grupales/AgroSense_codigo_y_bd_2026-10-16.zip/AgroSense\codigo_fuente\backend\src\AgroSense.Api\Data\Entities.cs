namespace AgroSense.Api.Data;

public class User
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public required string Name { get; set; }
    public required string Email { get; set; }
    public string PasswordHash { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    // Restablecimiento de contraseña: se guarda solo el hash del token.
    public string? PasswordResetTokenHash { get; set; }
    public DateTimeOffset? PasswordResetExpiresAt { get; set; }

    public List<StationMember> Stations { get; set; } = [];
}

/// <summary>
/// Una estación física (un ESP32). <see cref="Code"/> es la clave usada en Firebase: /stations/{Code}.
/// </summary>
public class Station
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public required string Code { get; set; }
    public required string Name { get; set; }
    public string Location { get; set; } = string.Empty;
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;

    // Configuración que se replica hacia el dispositivo (/stations/{Code}/config).
    public int ReadingIntervalSeconds { get; set; } = 300;
    public bool AutoIrrigation { get; set; } = true;
    public double ActivationThreshold { get; set; } = 30;
    public double DeactivationThreshold { get; set; } = 60;
    public int MaxPumpSeconds { get; set; } = 120;
    public bool ManualPump { get; set; }

    // Solo backend: se usa para estimar el agua consumida.
    public double PumpFlowLitersPerMinute { get; set; } = 1.5;

    // Estado informado por el dispositivo (/stations/{Code}/status).
    public string Hardware { get; set; } = "ESP32 (30 pines)";
    public string? MacAddress { get; set; }
    public string? IpAddress { get; set; }
    public int? WifiRssi { get; set; }
    public string? Firmware { get; set; }
    public DateTimeOffset? LastSeenAt { get; set; }

    // Notificaciones
    public bool NotificationsEnabled { get; set; } = true;
    public bool AlertSoilDry { get; set; } = true;
    public bool AlertOffline { get; set; } = true;
    public bool AlertPumpLong { get; set; } = true;
    public long? TelegramChatId { get; set; }
    public string? TelegramChatTitle { get; set; }
    public string? TelegramLinkCode { get; set; }
    public DateTimeOffset? TelegramLinkExpiresAt { get; set; }

    public List<StationMember> Members { get; set; } = [];
}

public static class StationRoles
{
    /// <summary>Puede cambiar umbrales, regar, configurar la estación, notificaciones y miembros.</summary>
    public const string Admin = "admin";
    /// <summary>Solo puede ver.</summary>
    public const string Viewer = "viewer";

    public static bool IsValid(string? role) => role is Admin or Viewer;
}

public class StationMember
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;
    public Guid StationId { get; set; }
    public Station Station { get; set; } = null!;
    public DateTimeOffset JoinedAt { get; set; } = DateTimeOffset.UtcNow;
    public string Role { get; set; } = StationRoles.Viewer;
    /// <summary>El usuario quiere recibir las alertas de esta estación por correo.</summary>
    public bool EmailAlerts { get; set; }
}

public class Reading
{
    public long Id { get; set; }
    public Guid StationId { get; set; }
    public Station Station { get; set; } = null!;

    /// <summary>Momento de la medición (UTC).</summary>
    public DateTimeOffset Timestamp { get; set; }

    /// <summary>Clave de origen (push id de Firebase o id generado). Evita duplicados al reingerir.</summary>
    public required string SourceKey { get; set; }

    public double? Temperature { get; set; }
    public double? AirHumidity { get; set; }
    public double? SoilMoisture { get; set; }
    /// <summary>Luminosidad relativa de un LDR (0–100 %). Opcional: el hardware actual usa el AS7262.</summary>
    public double? Light { get; set; }
    public bool? PumpOn { get; set; }

    /// <summary>Valor crudo del ADC del sensor de suelo (diagnóstico / recalibración).</summary>
    public int? SoilRaw { get; set; }

    // MQ135 (calidad del aire, sin calibrar a ppm)
    public int? AirQualityRaw { get; set; }
    public double? AirQualityVoltage { get; set; }

    // AS7262: espectro visible, µW/cm² por banda
    public double? SpectralViolet { get; set; }
    public double? SpectralBlue { get; set; }
    public double? SpectralGreen { get; set; }
    public double? SpectralYellow { get; set; }
    public double? SpectralOrange { get; set; }
    public double? SpectralRed { get; set; }
    public double? SpectralTotal { get; set; }
    public string? PumpMode { get; set; }

    public DateTimeOffset ReceivedAt { get; set; } = DateTimeOffset.UtcNow;
}

/// <summary>
/// Un ciclo de riego, derivado de las transiciones de <see cref="Reading.PumpOn"/>.
/// </summary>
public class IrrigationEvent
{
    public long Id { get; set; }
    public Guid StationId { get; set; }
    public Station Station { get; set; } = null!;
    public DateTimeOffset StartedAt { get; set; }
    public DateTimeOffset? EndedAt { get; set; }
    public double? StartMoisture { get; set; }
    public double? EndMoisture { get; set; }
    public string Mode { get; set; } = IrrigationModes.Auto;
}

public static class IrrigationModes
{
    public const string Auto = "auto";
    public const string Manual = "manual";
}

/// <summary>Última clave de Firebase procesada por estación, para leer solo lo nuevo.</summary>
public class IngestionCursor
{
    public Guid StationId { get; set; }
    public required string LastKey { get; set; }
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
}

/// <summary>
/// Resumen por minuto de las lecturas de una estación (promedio, mínimo y máximo por variable).
/// Con lecturas cada 2–3 s, los gráficos y estadísticas trabajan sobre estos resúmenes y no sobre las
/// lecturas crudas, que se conservan solo por un tiempo (ver RetentionOptions) y van completas a BigQuery.
/// </summary>
public class ReadingMinute
{
    public Guid StationId { get; set; }
    public DateTimeOffset Minute { get; set; }
    public int Count { get; set; }
    public int PumpOnCount { get; set; }

    public double? TemperatureAvg { get; set; }
    public double? TemperatureMin { get; set; }
    public double? TemperatureMax { get; set; }
    public double? AirHumidityAvg { get; set; }
    public double? AirHumidityMin { get; set; }
    public double? AirHumidityMax { get; set; }
    public double? SoilMoistureAvg { get; set; }
    public double? SoilMoistureMin { get; set; }
    public double? SoilMoistureMax { get; set; }
    public double? LightAvg { get; set; }
    public double? LightMin { get; set; }
    public double? LightMax { get; set; }
    /// <summary>Voltaje del MQ135 excluyendo lecturas saturadas.</summary>
    public double? AirQualityAvg { get; set; }
    public double? AirQualityMin { get; set; }
    public double? AirQualityMax { get; set; }

    public double? SpectralVioletAvg { get; set; }
    public double? SpectralBlueAvg { get; set; }
    public double? SpectralGreenAvg { get; set; }
    public double? SpectralYellowAvg { get; set; }
    public double? SpectralOrangeAvg { get; set; }
    public double? SpectralRedAvg { get; set; }
}

/// <summary>Estado de una exportación incremental (por ejemplo, hacia BigQuery).</summary>
public class ExportState
{
    public required string Key { get; set; }
    public long LastId { get; set; }
    public long TotalExported { get; set; }
    public DateTimeOffset? LastExportAt { get; set; }
    public string? LastError { get; set; }
    public DateTimeOffset? LastErrorAt { get; set; }
}

/// <summary>Punto de pronóstico calculado con BigQuery ML (ARIMA_PLUS), con su intervalo de confianza.</summary>
public class MlForecast
{
    public Guid StationId { get; set; }
    public required string Variable { get; set; }
    public DateTimeOffset Timestamp { get; set; }
    public double Value { get; set; }
    public double? Lower { get; set; }
    public double? Upper { get; set; }
    public DateTimeOffset TrainedAt { get; set; }

    /// <summary>Modelo elegido para la serie de esta estación, por ejemplo "ARIMA(2,1,1) · estacionalidad diaria".</summary>
    public string? Model { get; set; }

    /// <summary>Horas con datos usadas para entrenar la serie de esta estación.</summary>
    public int TrainingHours { get; set; }
}

/// <summary>Último entrenamiento de un modelo de BigQuery ML (uno por variable).</summary>
public class MlModelRun
{
    public required string Variable { get; set; }
    public DateTimeOffset RunAt { get; set; }
    public DateTimeOffset? TrainedAt { get; set; }
    /// <summary>ok, insufficient_data o error.</summary>
    public required string Status { get; set; }
    public int TrainingPoints { get; set; }
    public string? Description { get; set; }
    public string? Message { get; set; }
}

/// <summary>Registro de acciones: quién cambió qué y cuándo.</summary>
public class AuditEntry
{
    public long Id { get; set; }
    public Guid StationId { get; set; }
    public Guid? UserId { get; set; }
    public required string UserName { get; set; }
    /// <summary>Clave estable de la acción (irrigation.config, irrigation.manual, settings, member.role…).</summary>
    public required string Action { get; set; }
    /// <summary>Descripción legible del cambio, por ejemplo "Umbral de activación: 30 % → 25 %".</summary>
    public required string Summary { get; set; }
    public DateTimeOffset At { get; set; }
}

/// <summary>Estado de una alerta por estación, para avisar solo al activarse y al resolverse.</summary>
public class AlertState
{
    public Guid StationId { get; set; }
    public required string Key { get; set; }
    public bool Active { get; set; }
    public DateTimeOffset Since { get; set; }
    public DateTimeOffset? NotifiedAt { get; set; }
}
