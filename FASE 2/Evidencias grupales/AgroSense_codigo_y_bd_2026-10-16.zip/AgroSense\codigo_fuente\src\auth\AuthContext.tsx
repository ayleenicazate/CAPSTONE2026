import { useQueryClient } from '@tanstack/react-query'
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'

import { api, getToken, setToken, setUnauthorizedHandler } from '@/services/api'
import type { User } from '@/types/api'

type AuthContextValue = {
  user: User | null
  /** true mientras se valida un token guardado al abrir la app. */
  loading: boolean
  login: (email: string, password: string, remember: boolean) => Promise<void>
  register: (name: string, email: string, password: string, stationCode?: string, inviteCode?: string) => Promise<void>
  logout: () => void
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(() => getToken() !== null)

  const logout = useCallback(() => {
    setToken(null)
    setUser(null)
    queryClient.clear()
  }, [queryClient])

  useEffect(() => {
    setUnauthorizedHandler(logout)
    return () => setUnauthorizedHandler(null)
  }, [logout])

  // Restaurar la sesión si hay un token guardado.
  useEffect(() => {
    if (!getToken()) return
    api
      .me()
      .then(setUser)
      .catch(() => setToken(null))
      .finally(() => setLoading(false))
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      async login(email, password, remember) {
        const response = await api.login(email.trim(), password, remember)
        setToken(response.token, remember)
        setUser(response.user)
      },
      async register(name, email, password, stationCode, inviteCode) {
        const response = await api.register(name.trim(), email.trim(), password, stationCode?.trim(), inviteCode?.trim())
        setToken(response.token, true)
        setUser(response.user)
      },
      logout,
      async refreshUser() {
        setUser(await api.me())
      },
    }),
    [user, loading, logout],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider')
  }
  return context
}
