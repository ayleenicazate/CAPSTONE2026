﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace AgroSense.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddRolesAuditAndNotifications : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "AlertOffline",
                table: "stations",
                type: "boolean",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "AlertPumpLong",
                table: "stations",
                type: "boolean",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "AlertSoilDry",
                table: "stations",
                type: "boolean",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<bool>(
                name: "NotificationsEnabled",
                table: "stations",
                type: "boolean",
                nullable: false,
                defaultValue: true);

            migrationBuilder.AddColumn<long>(
                name: "TelegramChatId",
                table: "stations",
                type: "bigint",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TelegramChatTitle",
                table: "stations",
                type: "character varying(200)",
                maxLength: 200,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TelegramLinkCode",
                table: "stations",
                type: "character varying(16)",
                maxLength: 16,
                nullable: true);

            migrationBuilder.AddColumn<DateTimeOffset>(
                name: "TelegramLinkExpiresAt",
                table: "stations",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "EmailAlerts",
                table: "station_members",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "station_members",
                type: "character varying(16)",
                maxLength: 16,
                nullable: false,
                defaultValue: "admin");

            migrationBuilder.CreateTable(
                name: "alert_states",
                columns: table => new
                {
                    StationId = table.Column<Guid>(type: "uuid", nullable: false),
                    Key = table.Column<string>(type: "character varying(48)", maxLength: 48, nullable: false),
                    Active = table.Column<bool>(type: "boolean", nullable: false),
                    Since = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    NotifiedAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_alert_states", x => new { x.StationId, x.Key });
                });

            migrationBuilder.CreateTable(
                name: "audit_entries",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    StationId = table.Column<Guid>(type: "uuid", nullable: false),
                    UserId = table.Column<Guid>(type: "uuid", nullable: true),
                    UserName = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: false),
                    Action = table.Column<string>(type: "character varying(48)", maxLength: 48, nullable: false),
                    Summary = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: false),
                    At = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_audit_entries", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_audit_entries_StationId_At",
                table: "audit_entries",
                columns: new[] { "StationId", "At" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "alert_states");

            migrationBuilder.DropTable(
                name: "audit_entries");

            migrationBuilder.DropColumn(
                name: "AlertOffline",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "AlertPumpLong",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "AlertSoilDry",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "NotificationsEnabled",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "TelegramChatId",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "TelegramChatTitle",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "TelegramLinkCode",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "TelegramLinkExpiresAt",
                table: "stations");

            migrationBuilder.DropColumn(
                name: "EmailAlerts",
                table: "station_members");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "station_members");
        }
    }
}
