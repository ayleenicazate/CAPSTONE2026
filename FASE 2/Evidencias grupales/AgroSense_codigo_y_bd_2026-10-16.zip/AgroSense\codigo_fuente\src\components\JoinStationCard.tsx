import { useQueryClient } from '@tanstack/react-query'
import { useState, type FormEvent } from 'react'

import { useAuth } from '@/auth/AuthContext'
import { Card } from '@/components/ui/Card'
import { api } from '@/services/api'
import { queryKeys } from '@/services/queries'
import type { StationInfo } from '@/types/api'

interface JoinStationCardProps {
  title?: string
  onJoined?: (station: StationInfo) => void
}

/** Vincula la cuenta a una estación por su ID (la clave que usa el ESP32 en Firebase). */
export function JoinStationCard({ title = 'Vincular otra estación', onJoined }: JoinStationCardProps) {
  const queryClient = useQueryClient()
  const { refreshUser } = useAuth()
  const [code, setCode] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setBusy(true)
    try {
      const station = await api.joinStation(code)
      await queryClient.invalidateQueries({ queryKey: queryKeys.stations })
      await refreshUser()
      setCode('')
      onJoined?.(station)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo vincular la estación.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card>
      <h2 className="text-xl font-semibold text-slate-900">{title}</h2>
      <p className="mt-2 text-sm text-slate-500">
        Ingresa el ID de la estación configurado en el dispositivo (por ejemplo <code>agrosense-01</code>).
      </p>
      <form className="mt-4 flex flex-col gap-3 sm:flex-row" onSubmit={handleSubmit}>
        <input
          required
          value={code}
          onChange={(event) => setCode(event.target.value)}
          placeholder="agrosense-01"
          className="flex-1 rounded-xl border border-slate-200 px-4 py-3 text-sm"
        />
        <button
          type="submit"
          disabled={busy}
          className="rounded-xl bg-green-700 px-5 py-3 text-sm font-semibold text-white hover:bg-green-800 disabled:opacity-60"
        >
          {busy ? 'Vinculando...' : 'Vincular'}
        </button>
      </form>
      {error ? <p className="mt-3 text-sm text-red-600">{error}</p> : null}
    </Card>
  )
}
