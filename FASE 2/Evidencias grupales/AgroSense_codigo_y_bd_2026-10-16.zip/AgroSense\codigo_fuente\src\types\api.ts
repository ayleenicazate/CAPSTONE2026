// Tipos que reflejan las respuestas del backend AgroSense.Api (backend/src/AgroSense.Api/Stations/StationDtos.cs).

export type StatusTone = 'normal' | 'warning' | 'info' | 'neutral' | 'success'

export type VariableKey = 'temperature' | 'airHumidity' | 'soilMoisture' | 'light' | 'airQuality'

export interface MetricStatus {
  label: string
  tone: StatusTone
}

export interface StationRef {
  id: string
  code: string
  name: string
}

export interface User {
  id: string
  name: string
  email: string
  stations: StationRef[]
}

export interface AuthResponse {
  token: string
  expiresAt: string
  user: User
}

export interface StationInfo {
  id: string
  code: string
  name: string
  location: string
  online: boolean
  lastSeenAt: string | null
  readingIntervalSeconds: number
  /** Rol del usuario en la estación. */
  role?: StationRole | null
}

export type StationRole = 'admin' | 'viewer'

export interface Member {
  userId: string
  name: string
  email: string
  role: StationRole
  joinedAt: string
  isMe: boolean
}

export interface AuditEntry {
  id: number
  at: string
  userName: string
  action: string
  summary: string
}

export interface NotificationSettings {
  enabled: boolean
  alertSoilDry: boolean
  alertOffline: boolean
  alertPumpLong: boolean
  telegramAvailable: boolean
  telegramLinked: boolean
  telegramChat: string | null
  emailAvailable: boolean
  myEmailAlerts: boolean
}

export interface TelegramLink {
  code: string
  url: string | null
  botUsername: string | null
  expiresAt: string
}

export interface Point {
  timestamp: string
  value: number
}

export interface Metric {
  key: string
  label: string
  value: number | null
  unit: string
  status: MetricStatus | null
  hint?: string | null
  sparkline?: Point[] | null
}

export interface Alert {
  key: string
  severity: 'critical' | 'warning' | 'info'
  title: string
  detail: string
}

export interface LiveReading {
  timestamp: string
  temperature: number | null
  airHumidity: number | null
  soilMoisture: number | null
  light: number | null
  airQuality: number | null
  airQualitySaturated: boolean
  pumpOn: boolean | null
}

export interface LiveData {
  online: boolean
  lastSeenAt: string | null
  readingIntervalSeconds: number
  latest: LiveReading | null
  readings: LiveReading[]
}

export interface HeatmapData {
  variable: VariableInfo
  days: Array<{ date: string; hours: Array<number | null> }>
  min: number | null
  max: number | null
}

export interface SystemStatus {
  bigQuery: {
    enabled: boolean
    dataset: string | null
    exportedReadings: number
    lastExportAt: string | null
    lastError: string | null
    lastErrorAt: string | null
  }
  rawRetentionDays: number
  firebaseEnabled: boolean
  firebasePollSeconds: number
  storedReadings: number
  storedMinutes: number
}

export interface Summary {
  station: StationInfo
  latest: {
    timestamp: string
    temperature: number | null
    airHumidity: number | null
    soilMoisture: number | null
    light: number | null
    pumpOn: boolean | null
  } | null
  metrics: Metric[]
  soilMoisture24h: Point[]
  irrigation: {
    autoIrrigation: boolean
    pumpOn: boolean
    manualPump: boolean
    currentMoisture: number | null
    activationThreshold: number
    deactivationThreshold: number
    estimatedNextIrrigationAt: string | null
  }
  today: {
    irrigationCount: number
    pumpMinutes: number
    waterLiters: number
    temperatureMin: number | null
    temperatureMax: number | null
    lightHours: number | null
  }
  alerts: Alert[]
}

export interface SeriesStats {
  average: number
  min: number
  minAt: string
  max: number
  maxAt: string
  count: number
  trendPerDay: number | null
}

export interface Sensor {
  id: string
  name: string
  model: string
  description: string
  variables: VariableKey[]
  reporting: boolean
  reading: string | null
}

export interface VariableSeries {
  key: VariableKey
  label: string
  unit: string
  current: number | null
  stats: SeriesStats | null
  series: Point[]
}

export interface SpectralBand {
  key: string
  label: string
  wavelengthNm: number
  value: number | null
  color: string
}

export interface Spectrum {
  timestamp: string
  bands: SpectralBand[]
  total: number | null
}

export interface SensorsData {
  lastReadingAt: string | null
  hours: number
  sensors: Sensor[]
  variables: VariableSeries[]
  spectrum: Spectrum | null
  spectralSeries: SpectralPoint[]
}

export interface SpectralPoint {
  timestamp: string
  violet: number | null
  blue: number | null
  green: number | null
  yellow: number | null
  orange: number | null
  red: number | null
}

export type HistoryRange = '1h' | '24h' | '7d' | '30d'

export interface VariableInfo {
  key: VariableKey
  label: string
  unit: string
}

export interface HistoryData {
  variable: VariableInfo
  range: HistoryRange
  bucket: string
  variables: VariableInfo[]
  series: Array<{ timestamp: string; average: number; min: number; max: number }>
  forecast: Array<{ timestamp: string; value: number; lower: number | null; upper: number | null }>
  forecastMethod: string | null
  forecastSource: 'bigquery-ml' | 'local' | null
  stats: SeriesStats | null
  records: Array<{ timestamp: string; value: number; status: MetricStatus }>
}

export interface IrrigationConfig {
  autoIrrigation: boolean
  activationThreshold: number
  deactivationThreshold: number
  maxPumpSeconds: number
  manualPump: boolean
}

export interface IrrigationEvent {
  id: number
  startedAt: string
  endedAt: string | null
  durationSeconds: number | null
  mode: 'auto' | 'manual'
  startMoisture: number | null
  endMoisture: number | null
  waterLiters: number | null
}

export interface IrrigationData {
  config: IrrigationConfig
  pumpOn: boolean
  currentMoisture: number | null
  estimatedNextIrrigationAt: string | null
  stats: {
    todayCount: number
    todayMinutes: number
    todayLiters: number
    last7DaysCount: number
    last7DaysLiters: number
    lastIrrigationAt: string | null
  }
  events: IrrigationEvent[]
  deviceSynced: boolean
  daily: Array<{ date: string; count: number; minutes: number; liters: number }>
  soilMoisture48h: Array<{ timestamp: string; average: number; min: number; max: number }>
}

export interface Settings {
  id: string
  code: string
  name: string
  location: string
  readingIntervalSeconds: number
  pumpFlowLitersPerMinute: number
  irrigation: IrrigationConfig
  device: {
    hardware: string
    online: boolean
    lastSeenAt: string | null
    macAddress: string | null
    ipAddress: string | null
    wifiRssi: number | null
    firmware: string | null
  }
}

// ---------- Análisis histórico (BigQuery) ----------

export interface AnalyticsInsight {
  key: string
  title: string
  value: string
  detail: string
  strength: string | null
}

export interface MlModel {
  variable: VariableKey
  label: string
  status: 'ok' | 'insufficient_data' | 'error' | 'pending'
  trainedAt: string | null
  trainingPoints: number
  description: string | null
  message: string | null
}

export interface AnalyticsData {
  enabled: boolean
  message: string | null
  totals: {
    firstReadingAt: string | null
    lastReadingAt: string | null
    readings: number
    daysWithData: number
    irrigations: number
    waterLiters: number
  } | null
  monthly: Array<{
    month: string
    readings: number
    temperatureAvg: number | null
    temperatureMin: number | null
    temperatureMax: number | null
    airHumidityAvg: number | null
    soilMoistureAvg: number | null
    lightAvg: number | null
    irrigations: number
    waterLiters: number
  }>
  daily: Array<{
    day: string
    readings: number
    temperatureAvg: number | null
    temperatureMin: number | null
    temperatureMax: number | null
    airHumidityAvg: number | null
    soilMoistureAvg: number | null
    lightAvg: number | null
    irrigations: number
    waterLiters: number
  }>
  insights: AnalyticsInsight[]
  models: MlModel[]
  looker: { reportUrl: string | null; createUrl: string } | null
  bytesProcessed: number
  generatedAt: string
}
