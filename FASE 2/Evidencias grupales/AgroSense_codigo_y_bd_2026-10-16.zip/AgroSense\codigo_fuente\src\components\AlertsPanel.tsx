import { AlertOctagon, AlertTriangle, CheckCircle2, Info } from 'lucide-react'

import type { Alert } from '@/types/api'

const STYLE = {
  critical: { icon: AlertOctagon, box: 'border-red-200 bg-red-50', icon_: 'text-red-600', label: 'Crítico' },
  warning: { icon: AlertTriangle, box: 'border-amber-200 bg-amber-50', icon_: 'text-amber-600', label: 'Atención' },
  info: { icon: Info, box: 'border-sky-200 bg-sky-50', icon_: 'text-sky-600', label: 'Información' },
} as const

/** Avisos activos de la estación. Cada aviso lleva icono + etiqueta (nunca solo color). */
export function AlertsPanel({ alerts }: { alerts: Alert[] }) {
  if (alerts.length === 0) {
    return (
      <div className="flex items-center gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
        <CheckCircle2 size={18} className="shrink-0" />
        Todo en orden: sin alertas activas.
      </div>
    )
  }

  const order = { critical: 0, warning: 1, info: 2 }
  const sorted = [...alerts].sort((a, b) => order[a.severity] - order[b.severity])

  return (
    <div className="grid gap-3 md:grid-cols-2">
      {sorted.map((alert) => {
        const style = STYLE[alert.severity]
        const Icon = style.icon
        return (
          <div key={alert.key} className={`flex gap-3 rounded-2xl border px-4 py-3 ${style.box}`}>
            <Icon size={20} className={`mt-0.5 shrink-0 ${style.icon_}`} />
            <div>
              <p className="text-sm font-semibold text-slate-800">
                {alert.title} <span className="font-normal text-slate-500">· {style.label}</span>
              </p>
              <p className="text-sm text-slate-600">{alert.detail}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
