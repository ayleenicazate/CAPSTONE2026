import { Lock } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'

import { AuthCard, BrandMark } from '@/components/auth/AuthShell'
import { api } from '@/services/api'

export function ResetPasswordPage() {
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const email = params.get('email') ?? ''
  const token = params.get('token') ?? ''

  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    if (password !== confirm) {
      setError('Las contraseñas no coinciden.')
      return
    }
    setBusy(true)
    try {
      await api.resetPassword(email, token, password)
      navigate('/login', { replace: true, state: { passwordReset: true } })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo restablecer la contraseña.')
    } finally {
      setBusy(false)
    }
  }

  const fieldClass =
    'w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#1a7a3a] focus:ring-2 focus:ring-[#1a7a3a]/15'

  return (
    <AuthCard>
      <div className="mb-6 flex justify-center">
        <BrandMark />
      </div>
      <h2 className="text-[1.65rem] font-bold tracking-tight text-slate-900">Nueva contraseña</h2>

      {!email || !token ? (
        <p className="mt-4 rounded-lg bg-amber-50 px-3 py-3 text-sm text-amber-800">
          El enlace está incompleto. Solicita uno nuevo desde “¿Olvidaste tu contraseña?”.
        </p>
      ) : (
        <>
          <p className="mt-1 text-sm text-slate-500">Para la cuenta {email}</p>
          <form className="mt-6 space-y-4" onSubmit={(event) => void handleSubmit(event)}>
            {[
              { label: 'Nueva contraseña', value: password, set: setPassword },
              { label: 'Repite la contraseña', value: confirm, set: setConfirm },
            ].map((field) => (
              <label key={field.label} className="block">
                <span className="mb-1.5 block text-sm text-slate-600">{field.label}</span>
                <div className="relative">
                  <Lock size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    minLength={8}
                    autoComplete="new-password"
                    value={field.value}
                    onChange={(event) => field.set(event.target.value)}
                    placeholder="Mínimo 8 caracteres"
                    className={fieldClass}
                  />
                </div>
              </label>
            ))}
            {error ? <p className="text-sm text-red-600">{error}</p> : null}
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-lg bg-[#1a7a3a] py-2.5 text-sm font-semibold text-white transition hover:bg-[#166834] disabled:opacity-60"
            >
              {busy ? 'Guardando...' : 'Guardar contraseña'}
            </button>
          </form>
        </>
      )}

      <p className="mt-6 text-center text-sm text-slate-500">
        <Link to="/login" className="font-semibold text-[#1a7a3a] hover:underline">
          Volver a iniciar sesión
        </Link>
      </p>
    </AuthCard>
  )
}
