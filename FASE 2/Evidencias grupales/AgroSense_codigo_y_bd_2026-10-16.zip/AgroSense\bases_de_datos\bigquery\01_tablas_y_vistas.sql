-- AgroSense - Tablas y vistas de BigQuery (dataset agrosense-a1b2c.agrosense), DDL obtenido de INFORMATION_SCHEMA el 2026-10-16

-- ===== BASE TABLE: irrigation_events
CREATE TABLE `agrosense-a1b2c.agrosense.irrigation_events`
(
  event_id INT64 NOT NULL,
  station_code STRING NOT NULL,
  started_at TIMESTAMP NOT NULL,
  ended_at TIMESTAMP,
  duration_seconds FLOAT64,
  mode STRING,
  start_moisture FLOAT64,
  end_moisture FLOAT64,
  water_liters FLOAT64
)
PARTITION BY DATE(started_at)
CLUSTER BY station_code
OPTIONS(
  partition_expiration_days=60.0
);

-- ===== BASE TABLE: readings
CREATE TABLE `agrosense-a1b2c.agrosense.readings`
(
  reading_id INT64 NOT NULL,
  station_code STRING NOT NULL,
  ts TIMESTAMP NOT NULL,
  received_at TIMESTAMP,
  temperature FLOAT64,
  air_humidity FLOAT64,
  soil_moisture FLOAT64,
  soil_raw INT64,
  light_total FLOAT64,
  spectral_violet FLOAT64,
  spectral_blue FLOAT64,
  spectral_green FLOAT64,
  spectral_yellow FLOAT64,
  spectral_orange FLOAT64,
  spectral_red FLOAT64,
  air_quality_raw INT64,
  air_quality_voltage FLOAT64,
  air_quality_saturated BOOL,
  pump_on BOOL,
  pump_mode STRING,
  source_key STRING
)
PARTITION BY DATE(ts)
CLUSTER BY station_code
OPTIONS(
  partition_expiration_days=60.0
);

-- ===== VIEW: daily_summary
CREATE VIEW `agrosense-a1b2c.agrosense.daily_summary`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T22:23:38.432Z"
)
AS WITH r AS (
  SELECT station_code, DATE(ts, 'America/Santiago') AS day, COUNT(*) AS readings,
    AVG(temperature) AS temperature_avg, MIN(temperature) AS temperature_min, MAX(temperature) AS temperature_max,
    AVG(air_humidity) AS air_humidity_avg,
    AVG(soil_moisture) AS soil_moisture_avg, MIN(soil_moisture) AS soil_moisture_min, MAX(soil_moisture) AS soil_moisture_max,
    AVG(light_total) AS light_avg, MAX(light_total) AS light_max,
    AVG(IF(air_quality_saturated, NULL, air_quality_voltage)) AS air_quality_avg
  FROM `agrosense-a1b2c.agrosense.readings`
  GROUP BY station_code, day
),
e AS (
  SELECT station_code, DATE(started_at, 'America/Santiago') AS day, COUNT(*) AS irrigations,
    SUM(duration_seconds) / 60 AS irrigation_minutes, SUM(water_liters) AS water_liters
  FROM `agrosense-a1b2c.agrosense.irrigation_events`
  GROUP BY station_code, day
)
SELECT r.*, IFNULL(e.irrigations, 0) AS irrigations,
  IFNULL(e.irrigation_minutes, 0) AS irrigation_minutes, IFNULL(e.water_liters, 0) AS water_liters
FROM r LEFT JOIN e USING (station_code, day);

-- ===== VIEW: hourly_summary
CREATE VIEW `agrosense-a1b2c.agrosense.hourly_summary`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T22:23:39.890Z"
)
AS SELECT station_code,
  TIMESTAMP_TRUNC(ts, HOUR) AS hour_utc,
  DATETIME(TIMESTAMP_TRUNC(ts, HOUR), 'America/Santiago') AS hour_local,
  EXTRACT(HOUR FROM DATETIME(ts, 'America/Santiago')) AS hour_of_day,
  COUNT(*) AS readings,
  AVG(temperature) AS temperature, AVG(air_humidity) AS air_humidity,
  AVG(soil_moisture) AS soil_moisture, AVG(light_total) AS light,
  AVG(IF(air_quality_saturated, NULL, air_quality_voltage)) AS air_quality,
  LOGICAL_OR(IFNULL(pump_on, FALSE)) AS pump_on
FROM `agrosense-a1b2c.agrosense.readings`
GROUP BY station_code, hour_utc, hour_local, hour_of_day;

-- ===== VIEW: reporte_espectro
CREATE VIEW `agrosense-a1b2c.agrosense.reporte_espectro`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T20:12:29.091Z",
  description="AgroSense: promedio por color del sensor AS7262 (uW/cm2), por estacion y origen. Para Looker Studio."
)
AS SELECT
  station_code AS estacion,
  IF(station_code = 'simulador-01' OR soil_raw IS NULL, 'Simulado', 'Real') AS origen,
  color, longitud_onda_nm, ROUND(AVG(valor), 2) AS intensidad
FROM `agrosense-a1b2c.agrosense.readings`,
UNNEST([
  STRUCT('Violeta' AS color, 450 AS longitud_onda_nm, spectral_violet AS valor),
  ('Azul', 500, spectral_blue), ('Verde', 550, spectral_green),
  ('Amarillo', 570, spectral_yellow), ('Naranjo', 600, spectral_orange), ('Rojo', 650, spectral_red)
])
WHERE valor IS NOT NULL
GROUP BY estacion, origen, color, longitud_onda_nm;

-- ===== VIEW: reporte_lecturas_hora
CREATE VIEW `agrosense-a1b2c.agrosense.reporte_lecturas_hora`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T20:12:25.890Z",
  description="AgroSense: promedios por hora (hora de Chile), separados por origen real/simulado. Para Looker Studio."
)
AS SELECT
  station_code AS estacion,
  IF(station_code = 'simulador-01' OR soil_raw IS NULL, 'Simulado', 'Real') AS origen,
  DATETIME(TIMESTAMP_TRUNC(ts, HOUR), 'America/Santiago') AS hora,
  DATE(ts, 'America/Santiago') AS dia,
  EXTRACT(HOUR FROM DATETIME(ts, 'America/Santiago')) AS hora_del_dia,
  COUNT(*) AS lecturas,
  ROUND(AVG(temperature), 2) AS temperatura_c,
  ROUND(AVG(air_humidity), 2) AS humedad_aire_pct,
  ROUND(AVG(soil_moisture), 2) AS humedad_suelo_pct,
  ROUND(AVG(light_total), 1) AS luz_total,
  ROUND(AVG(IF(air_quality_saturated, NULL, air_quality_voltage)), 3) AS calidad_aire_v,
  COUNTIF(pump_on) AS lecturas_con_bomba
FROM `agrosense-a1b2c.agrosense.readings`
GROUP BY estacion, origen, hora, dia, hora_del_dia;

-- ===== VIEW: reporte_prediccion
CREATE VIEW `agrosense-a1b2c.agrosense.reporte_prediccion`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T20:12:28.418Z",
  description="AgroSense: prediccion BigQuery ML (ARIMA_PLUS) de las proximas 48 h con intervalo del 90%. Para Looker Studio."
)
AS SELECT 'Temperatura (C)' AS variable, station_code AS estacion, DATETIME(forecast_timestamp, 'America/Santiago') AS hora,
  ROUND(forecast_value, 2) AS valor, ROUND(prediction_interval_lower_bound, 2) AS minimo, ROUND(prediction_interval_upper_bound, 2) AS maximo
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_temperature`, STRUCT(48 AS horizon, 0.9 AS confidence_level))
UNION ALL
SELECT 'Humedad del aire (%)', station_code, DATETIME(forecast_timestamp, 'America/Santiago'),
  ROUND(forecast_value, 2), ROUND(prediction_interval_lower_bound, 2), ROUND(prediction_interval_upper_bound, 2)
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_airhumidity`, STRUCT(48 AS horizon, 0.9 AS confidence_level))
UNION ALL
SELECT 'Humedad del suelo (%)', station_code, DATETIME(forecast_timestamp, 'America/Santiago'),
  ROUND(forecast_value, 2), ROUND(prediction_interval_lower_bound, 2), ROUND(prediction_interval_upper_bound, 2)
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_soilmoisture`, STRUCT(48 AS horizon, 0.9 AS confidence_level))
UNION ALL
SELECT 'Luz total', station_code, DATETIME(forecast_timestamp, 'America/Santiago'),
  ROUND(forecast_value, 2), ROUND(prediction_interval_lower_bound, 2), ROUND(prediction_interval_upper_bound, 2)
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_light`, STRUCT(48 AS horizon, 0.9 AS confidence_level))
UNION ALL
SELECT 'Calidad del aire (V)', station_code, DATETIME(forecast_timestamp, 'America/Santiago'),
  ROUND(forecast_value, 3), ROUND(prediction_interval_lower_bound, 3), ROUND(prediction_interval_upper_bound, 3)
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_airquality`, STRUCT(48 AS horizon, 0.9 AS confidence_level));

-- ===== VIEW: reporte_resumen_diario
CREATE VIEW `agrosense-a1b2c.agrosense.reporte_resumen_diario`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T20:12:26.683Z",
  description="AgroSense: resumen diario por estacion y origen, con riegos. Para Looker Studio."
)
AS WITH r AS (
  SELECT
    station_code AS estacion,
    IF(station_code = 'simulador-01' OR soil_raw IS NULL, 'Simulado', 'Real') AS origen,
    DATE(ts, 'America/Santiago') AS dia,
    COUNT(*) AS lecturas,
    ROUND(AVG(temperature), 2) AS temp_prom_c,
    ROUND(MIN(temperature), 2) AS temp_min_c,
    ROUND(MAX(temperature), 2) AS temp_max_c,
    ROUND(AVG(air_humidity), 2) AS humedad_aire_prom,
    ROUND(AVG(soil_moisture), 2) AS humedad_suelo_prom,
    ROUND(MIN(soil_moisture), 2) AS humedad_suelo_min,
    ROUND(MAX(soil_moisture), 2) AS humedad_suelo_max,
    ROUND(AVG(light_total), 1) AS luz_prom,
    ROUND(AVG(IF(air_quality_saturated, NULL, air_quality_voltage)), 3) AS calidad_aire_prom_v
  FROM `agrosense-a1b2c.agrosense.readings`
  GROUP BY estacion, origen, dia
),
e AS (
  SELECT
    station_code AS estacion,
    IF(station_code = 'simulador-01' OR started_at < TIMESTAMP('2026-10-03', 'America/Santiago'), 'Simulado', 'Real') AS origen,
    DATE(started_at, 'America/Santiago') AS dia,
    COUNT(*) AS riegos,
    ROUND(SUM(duration_seconds) / 60, 1) AS minutos_riego
  FROM `agrosense-a1b2c.agrosense.irrigation_events`
  WHERE duration_seconds <= 3600
  GROUP BY estacion, origen, dia
)
SELECT r.*, IFNULL(e.riegos, 0) AS riegos, IFNULL(e.minutos_riego, 0) AS minutos_riego
FROM r LEFT JOIN e USING (estacion, origen, dia);

-- ===== VIEW: reporte_riegos
CREATE VIEW `agrosense-a1b2c.agrosense.reporte_riegos`
OPTIONS(
  expiration_timestamp=TIMESTAMP "2026-12-14T20:12:27.465Z",
  description="AgroSense: cada riego con modo, duracion y efecto en el suelo. Para Looker Studio."
)
AS SELECT
  station_code AS estacion,
  IF(station_code = 'simulador-01' OR started_at < TIMESTAMP('2026-10-03', 'America/Santiago'), 'Simulado', 'Real') AS origen,
  DATETIME(started_at, 'America/Santiago') AS inicio,
  DATETIME(ended_at, 'America/Santiago') AS fin,
  DATE(started_at, 'America/Santiago') AS dia,
  IF(mode = 'manual', 'Manual', 'Automatico') AS modo,
  duration_seconds AS duracion_s,
  ROUND(start_moisture, 1) AS suelo_antes_pct,
  ROUND(end_moisture, 1) AS suelo_despues_pct,
  ROUND(end_moisture - start_moisture, 1) AS aumento_suelo_pct
FROM `agrosense-a1b2c.agrosense.irrigation_events`
WHERE duration_seconds <= 3600;

