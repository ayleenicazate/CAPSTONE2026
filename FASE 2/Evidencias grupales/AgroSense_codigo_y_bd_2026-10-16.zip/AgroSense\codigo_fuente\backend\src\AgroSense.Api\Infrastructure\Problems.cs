namespace AgroSense.Api.Infrastructure;

/// <summary>Errores en formato ProblemDetails; el frontend muestra el campo <c>detail</c>.</summary>
public static class Problems
{
    public static IResult BadRequest(string detail) => Results.Problem(detail, statusCode: StatusCodes.Status400BadRequest);
    public static IResult Unauthorized(string detail) => Results.Problem(detail, statusCode: StatusCodes.Status401Unauthorized);
    public static IResult NotFound(string detail) => Results.Problem(detail, statusCode: StatusCodes.Status404NotFound);
    public static IResult Conflict(string detail) => Results.Problem(detail, statusCode: StatusCodes.Status409Conflict);
}
