namespace AgroSense.Api.Auth;

public interface IEmailSender
{
    Task SendAsync(string to, string subject, string body, CancellationToken ct = default);
}

/// <summary>
/// Implementación de desarrollo: escribe el correo en el log de la consola.
/// Para producción, reemplazar por un envío SMTP (o SendGrid, etc.) registrando otra implementación.
/// </summary>
public class LoggingEmailSender(ILogger<LoggingEmailSender> logger) : IEmailSender
{
    public Task SendAsync(string to, string subject, string body, CancellationToken ct = default)
    {
        logger.LogWarning("Correo (no enviado, modo desarrollo) para {To}: {Subject}\n{Body}", to, subject, body);
        return Task.CompletedTask;
    }
}
