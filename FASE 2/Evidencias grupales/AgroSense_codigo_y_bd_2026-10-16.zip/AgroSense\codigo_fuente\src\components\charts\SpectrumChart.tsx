import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

import { Card } from '@/components/ui/Card'
import { formatDateTime, formatNumber } from '@/lib/format'
import type { Spectrum } from '@/types/api'

/** Lectura actual del AS7262: intensidad por banda del espectro visible. */
export function SpectrumChart({ spectrum }: { spectrum: Spectrum }) {
  const data = spectrum.bands.map((band) => ({ ...band, value: band.value ?? 0 }))

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-1 md:flex-row md:items-start md:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">Espectro de luz actual (AS7262)</h3>
          <p className="text-sm text-slate-500">
            Intensidad por color de la luz que recibe el cultivo · Total: {formatNumber(spectrum.total)} µW/cm²
          </p>
        </div>
        <p className="text-sm text-slate-400">{formatDateTime(spectrum.timestamp)}</p>
      </div>
      <div className="h-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid stroke="#eef2f7" vertical={false} />
            <XAxis
              dataKey="label"
              axisLine={false}
              tickLine={false}
              tick={{ fill: '#475569', fontSize: 12 }}
            />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
            <Tooltip
              formatter={(value: number, _name, item) => [
                `${formatNumber(value, 2)} µW/cm²`,
                `${item.payload.label} (${item.payload.wavelengthNm} nm)`,
              ]}
            />
            <Bar dataKey="value" radius={[8, 8, 0, 0]} isAnimationActive={false}>
              {data.map((band) => (
                <Cell key={band.key} fill={band.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-3 md:grid-cols-6">
        {data.map((band) => (
          <div key={band.key} className="text-center">
            <p className="text-sm font-semibold text-slate-700">{formatNumber(band.value, 1)}</p>
            <p className="text-sm text-slate-700">{band.label}</p>
            <p className="text-xs text-slate-400">{band.wavelengthNm} nm</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
