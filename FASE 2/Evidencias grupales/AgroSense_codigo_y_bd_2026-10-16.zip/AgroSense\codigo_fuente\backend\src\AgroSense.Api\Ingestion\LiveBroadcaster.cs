using System.Collections.Concurrent;
using System.Threading.Channels;
using AgroSense.Api.Data;
using AgroSense.Api.Metrics;
using AgroSense.Api.Stations;

namespace AgroSense.Api.Ingestion;

/// <summary>
/// Reparte en tiempo real las lecturas recién guardadas a los navegadores suscritos
/// (endpoint <c>/api/stations/{id}/stream</c>, Server-Sent Events). Vive en memoria: una sola instancia de la API.
/// </summary>
public class LiveBroadcaster
{
    private readonly ConcurrentDictionary<Guid, ConcurrentDictionary<Guid, Channel<LiveReadingDto>>> _subscribers = new();

    public int SubscriberCount(Guid stationId) =>
        _subscribers.TryGetValue(stationId, out var subs) ? subs.Count : 0;

    /// <summary>Suscribe un cliente. El canal descarta lo más antiguo si el cliente es lento.</summary>
    public (Guid Id, ChannelReader<LiveReadingDto> Reader) Subscribe(Guid stationId)
    {
        var channel = Channel.CreateBounded<LiveReadingDto>(new BoundedChannelOptions(500)
        {
            FullMode = BoundedChannelFullMode.DropOldest,
            SingleReader = true,
        });
        var id = Guid.NewGuid();
        _subscribers.GetOrAdd(stationId, _ => new())[id] = channel;
        return (id, channel.Reader);
    }

    public void Unsubscribe(Guid stationId, Guid subscriptionId)
    {
        if (_subscribers.TryGetValue(stationId, out var subs) && subs.TryRemove(subscriptionId, out var channel))
        {
            channel.Writer.TryComplete();
        }
    }

    public void Publish(Guid stationId, IEnumerable<Reading> readings)
    {
        if (!_subscribers.TryGetValue(stationId, out var subs) || subs.IsEmpty) return;
        foreach (var reading in readings.OrderBy(r => r.Timestamp))
        {
            var dto = ToLive(reading);
            foreach (var channel in subs.Values)
            {
                channel.Writer.TryWrite(dto);
            }
        }
    }

    public static LiveReadingDto ToLive(Reading r) => new(
        r.Timestamp, r.Temperature, r.AirHumidity, r.SoilMoisture, r.SpectralTotal,
        Variables.IsAirQualitySaturated(r) ? null : r.AirQualityVoltage,
        Variables.IsAirQualitySaturated(r),
        r.PumpOn);
}
