import { Circle, Menu } from 'lucide-react'

import { Badge } from '@/components/ui/Badge'
import { formatRelative } from '@/lib/format'
import type { StationInfo } from '@/types/api'

interface TopBarProps {
  title: string
  station?: StationInfo
  stations: StationInfo[]
  onSelectStation: (id: string) => void
  onOpenMenu: () => void
}

export function TopBar({ title, station, stations, onSelectStation, onOpenMenu }: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 flex flex-col gap-3 border-b border-slate-200 bg-white/90 px-4 py-4 backdrop-blur md:flex-row md:items-center md:justify-between md:px-6">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onOpenMenu}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
          aria-label="Abrir menú"
        >
          <Menu size={22} />
        </button>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900 md:text-2xl">{title}</h1>
      </div>
      {station ? (
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone={station.online ? 'success' : 'neutral'}>
            <Circle size={8} className="mr-2 fill-current" />
            {station.online ? 'En línea' : 'Fuera de línea'}
          </Badge>
          <span className="text-sm text-slate-400">Último reporte: {formatRelative(station.lastSeenAt)}</span>
          {station.role === 'viewer' ? <Badge tone="neutral">Solo lectura</Badge> : null}
          {stations.length > 1 ? (
            <select
              value={station.id}
              onChange={(event) => onSelectStation(event.target.value)}
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-700"
              aria-label="Estación"
            >
              {stations.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          ) : (
            <span className="text-sm text-slate-500">Dispositivo: {station.name}</span>
          )}
        </div>
      ) : null}
    </header>
  )
}
