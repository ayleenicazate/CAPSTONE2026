import { useState, type ReactNode } from 'react'

import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/States'
import { sequentialBlue, sequentialColor } from '@/lib/chartTheme'
import { formatValue } from '@/lib/format'
import type { HeatmapData } from '@/types/api'

const HOURS = Array.from({ length: 24 }, (_, h) => h)

/** Mapa de calor día × hora (promedio por hora, hora local). Escala secuencial de un solo tono. */
export function Heatmap({ data, title, actions }: { data: HeatmapData; title: string; actions?: ReactNode }) {
  const [hovered, setHovered] = useState<{ date: string; hour: number; value: number | null } | null>(null)
  const { unit } = data.variable
  const digits = unit === 'V' ? 2 : unit === 'µW/cm²' ? 0 : 1
  const hasData = data.min !== null && data.max !== null
  const min = data.min ?? 0
  const max = data.max ?? 0

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">{title}</h3>
          <p className="text-sm text-slate-500">
            Promedio por hora del día. Permite ver el ciclo diario y comparar días.
          </p>
        </div>
        {actions}
      </div>

      {!hasData ? (
        <EmptyState>Aún no hay datos suficientes para el mapa de calor.</EmptyState>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] table-fixed border-separate" style={{ borderSpacing: 2 }}>
              <thead>
                <tr>
                  <th style={{ width: 84 }} />
                  {HOURS.map((h) => (
                    <th key={h} className="text-[10px] font-normal text-slate-400">
                      {h % 3 === 0 ? `${h}h` : ''}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.days.map((day) => (
                  <tr key={day.date}>
                    <td className="pr-2 text-right text-xs whitespace-nowrap text-slate-500">
                      {new Date(`${day.date}T12:00:00`).toLocaleDateString('es-CL', { weekday: 'short', day: '2-digit', month: '2-digit' })}
                    </td>
                    {day.hours.map((value, hour) => (
                      <td
                        key={hour}
                        onMouseEnter={() => setHovered({ date: day.date, hour, value })}
                        onMouseLeave={() => setHovered(null)}
                        className="h-6 rounded-[4px]"
                        style={{ background: value === null ? '#f1f5f9' : sequentialColor(value, min, max) }}
                        aria-label={`${day.date} ${hour}:00 ${value === null ? 'sin datos' : formatValue(value, unit, digits)}`}
                      />
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span>{formatValue(min, unit, digits)}</span>
              <span
                className="h-2.5 w-40 rounded-full"
                style={{ background: `linear-gradient(to right, ${sequentialBlue.join(',')})` }}
              />
              <span>{formatValue(max, unit, digits)}</span>
              <span className="ml-2 flex items-center gap-1">
                <span className="h-2.5 w-4 rounded-sm bg-slate-100" /> sin datos
              </span>
            </div>
            <p className="min-h-[1rem] font-medium text-slate-700">
              {hovered
                ? `${new Date(`${hovered.date}T12:00:00`).toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' })}, ${hovered.hour}:00–${hovered.hour}:59 → ${
                    hovered.value === null ? 'sin datos' : formatValue(hovered.value, unit, digits)
                  }`
                : 'Pasa el mouse sobre una celda para ver el valor'}
            </p>
          </div>
        </>
      )}
    </Card>
  )
}
