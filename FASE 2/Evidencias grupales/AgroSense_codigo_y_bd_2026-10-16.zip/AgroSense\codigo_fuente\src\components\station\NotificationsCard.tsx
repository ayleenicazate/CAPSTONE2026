import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Bell, ExternalLink, Mail, Send } from 'lucide-react'
import { useState } from 'react'

import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { api } from '@/services/api'
import { queryKeys, useNotificationsQuery } from '@/services/queries'
import { useIsAdmin, useStation } from '@/stations/StationContext'
import type { NotificationSettings, TelegramLink } from '@/types/api'

const ALERTS: Array<{ key: 'alertSoilDry' | 'alertOffline' | 'alertPumpLong'; label: string; detail: string }> = [
  { key: 'alertSoilDry', label: 'Suelo seco sin riego', detail: '10 min bajo el umbral y la bomba no se enciende' },
  { key: 'alertOffline', label: 'Dispositivo fuera de línea', detail: 'No llegan datos en 5 min (o 3 intervalos)' },
  { key: 'alertPumpLong', label: 'Bomba encendida demasiado tiempo', detail: 'Supera el máximo configurado' },
]

export function NotificationsCard() {
  const station = useStation()
  const isAdmin = useIsAdmin()
  const queryClient = useQueryClient()
  const { data } = useNotificationsQuery(station.id)
  const [link, setLink] = useState<TelegramLink | null>(null)
  const [message, setMessage] = useState<{ text: string; tone: 'ok' | 'error' } | null>(null)

  const refresh = (value?: NotificationSettings) =>
    value
      ? queryClient.setQueryData(queryKeys.notifications(station.id), value)
      : queryClient.invalidateQueries({ queryKey: queryKeys.notifications(station.id) })
  const onError = (err: Error) => setMessage({ text: err.message, tone: 'error' })

  const save = useMutation({
    mutationFn: (s: NotificationSettings) =>
      api.updateNotifications(station.id, {
        enabled: s.enabled,
        alertSoilDry: s.alertSoilDry,
        alertOffline: s.alertOffline,
        alertPumpLong: s.alertPumpLong,
      }),
    onSuccess: (value) => void refresh(value),
    onError,
  })
  const myEmail = useMutation({
    mutationFn: (on: boolean) => api.updateMyNotifications(station.id, on),
    onSuccess: () => void refresh(),
    onError,
  })
  const createLink = useMutation({ mutationFn: () => api.linkTelegram(station.id), onSuccess: setLink, onError })
  const unlink = useMutation({ mutationFn: () => api.unlinkTelegram(station.id), onSuccess: () => void refresh(), onError })
  const test = useMutation({
    mutationFn: () => api.testNotification(station.id),
    onSuccess: (r) =>
      setMessage({
        text: `Mensaje de prueba enviado${r.telegram ? ' por Telegram' : ''}${r.emails ? `${r.telegram ? ' y' : ''} a ${r.emails} correo(s)` : ''}.`,
        tone: 'ok',
      }),
    onError,
  })

  if (!data) return null
  const toggle = (patch: Partial<NotificationSettings>) => save.mutate({ ...data, ...patch })

  return (
    <Card>
      <h2 className="flex items-center gap-2 text-xl font-semibold text-slate-900">
        <Bell size={18} className="text-green-700" />
        Notificaciones
      </h2>
      <p className="mt-1 text-sm text-slate-500">Avisos cuando una alerta se activa y cuando se resuelve.</p>

      {/* Telegram */}
      <div className="mt-5 rounded-2xl border border-slate-100 bg-slate-50 p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="flex items-center gap-2 font-semibold text-slate-800">
            <Send size={16} className="text-sky-600" />
            Telegram
          </p>
          {data.telegramLinked ? <Badge tone="success">Vinculado</Badge> : <Badge tone="neutral">Sin vincular</Badge>}
        </div>
        {!data.telegramAvailable ? (
          <p className="mt-2 text-sm text-slate-500">El bot de Telegram no está configurado en el servidor.</p>
        ) : data.telegramLinked ? (
          <div className="mt-2 space-y-2 text-sm text-slate-600">
            <p>
              Las alertas llegan al chat <span className="font-medium">{data.telegramChat}</span>. Escribe <code>/estado</code> en el
              chat para ver las últimas lecturas.
            </p>
            {isAdmin ? (
              <button type="button" onClick={() => unlink.mutate()} className="text-sm font-medium text-red-600 hover:underline">
                Desvincular
              </button>
            ) : null}
          </div>
        ) : isAdmin ? (
          <div className="mt-2 space-y-2 text-sm text-slate-600">
            {link ? (
              <>
                <p>
                  Abre el bot y pulsa <span className="font-medium">Iniciar</span>. Para un grupo: agrega el bot al grupo y escribe{' '}
                  <code>/vincular {link.code}</code>. El código vence en 15 minutos.
                </p>
                {link.url ? (
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-xl bg-sky-600 px-4 py-2 font-semibold text-white hover:bg-sky-700"
                  >
                    <ExternalLink size={14} />
                    Abrir @{link.botUsername}
                  </a>
                ) : null}
                <button type="button" onClick={() => void refresh()} className="ml-3 text-sm font-medium text-green-700 hover:underline">
                  Ya lo vinculé
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => createLink.mutate()}
                className="rounded-xl bg-sky-600 px-4 py-2 font-semibold text-white hover:bg-sky-700"
              >
                Vincular Telegram
              </button>
            )}
          </div>
        ) : (
          <p className="mt-2 text-sm text-slate-500">Un administrador puede vincular un chat de Telegram.</p>
        )}
      </div>

      {/* Correo (cada usuario) */}
      <label className="mt-3 flex items-start justify-between gap-3 rounded-2xl border border-slate-100 bg-slate-50 p-4">
        <span>
          <span className="flex items-center gap-2 font-semibold text-slate-800">
            <Mail size={16} className="text-indigo-600" />
            Recibir alertas en mi correo
          </span>
          <span className="block text-sm text-slate-500">
            {data.emailAvailable ? 'Solo para tu cuenta.' : 'El envío de correos no está configurado en el servidor.'}
          </span>
        </span>
        <input
          type="checkbox"
          className="mt-1 h-5 w-5 accent-green-700"
          checked={data.myEmailAlerts}
          disabled={!data.emailAvailable || myEmail.isPending}
          onChange={(e) => myEmail.mutate(e.target.checked)}
        />
      </label>

      {/* Qué alertas (admin) */}
      <div className="mt-4 space-y-2">
        <label className="flex items-center justify-between gap-3 text-sm">
          <span className="font-medium text-slate-700">Notificaciones activas para esta estación</span>
          <input
            type="checkbox"
            className="h-5 w-5 accent-green-700"
            checked={data.enabled}
            disabled={!isAdmin || save.isPending}
            onChange={(e) => toggle({ enabled: e.target.checked })}
          />
        </label>
        {ALERTS.map((alert) => (
          <label key={alert.key} className="flex items-center justify-between gap-3 pl-3 text-sm">
            <span>
              <span className="text-slate-700">{alert.label}</span>
              <span className="block text-xs text-slate-400">{alert.detail}</span>
            </span>
            <input
              type="checkbox"
              className="h-4 w-4 accent-green-700"
              checked={data[alert.key]}
              disabled={!isAdmin || !data.enabled || save.isPending}
              onChange={(e) => toggle({ [alert.key]: e.target.checked })}
            />
          </label>
        ))}
      </div>

      {isAdmin ? (
        <button
          type="button"
          onClick={() => test.mutate()}
          disabled={test.isPending}
          className="mt-4 rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-50 disabled:opacity-60"
        >
          {test.isPending ? 'Enviando…' : 'Enviar mensaje de prueba'}
        </button>
      ) : null}

      {message ? (
        <p className={`mt-3 rounded-xl px-3 py-2 text-sm ${message.tone === 'ok' ? 'bg-emerald-50 text-green-800' : 'bg-red-50 text-red-700'}`}>
          {message.text}
        </p>
      ) : null}
    </Card>
  )
}
