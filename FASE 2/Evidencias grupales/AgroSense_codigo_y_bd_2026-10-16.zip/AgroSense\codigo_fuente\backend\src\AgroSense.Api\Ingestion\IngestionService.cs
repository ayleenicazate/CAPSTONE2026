using AgroSense.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Ingestion;

/// <summary>
/// Guarda lecturas en PostgreSQL y deriva los eventos de riego a partir de los cambios de estado de la bomba.
/// Lo usan tanto el worker de Firebase como el endpoint HTTP de ingesta directa.
/// </summary>
public class IngestionService(
    AgroSenseDbContext db,
    RollupService rollups,
    LiveBroadcaster live,
    TimeProvider clock,
    ILogger<IngestionService> logger)
{
    public async Task<int> IngestAsync(Station station, IReadOnlyCollection<IncomingReading> incoming, CancellationToken ct = default)
    {
        if (incoming.Count == 0) return 0;

        var keys = incoming.Select(r => r.SourceKey).ToList();
        var existing = await db.Readings
            .Where(r => r.StationId == station.Id && keys.Contains(r.SourceKey))
            .ToDictionaryAsync(r => r.SourceKey, ct);

        // Lecturas ya guardadas: solo se completan campos que antes no se procesaban
        // (permite reingerir desde Firebase sin duplicar cuando el contrato agrega datos).
        var enrichedTimes = new List<DateTimeOffset>();
        foreach (var reading in incoming)
        {
            if (existing.TryGetValue(reading.SourceKey, out var stored) && Enrich(stored, reading)) enrichedTimes.Add(stored.Timestamp);
        }
        var enriched = enrichedTimes.Count;
        if (enriched > 0) logger.LogInformation("Estación {Code}: {Count} lecturas completadas con datos nuevos", station.Code, enriched);

        var seen = existing.Keys.ToHashSet();

        var fresh = incoming
            .Where(r => seen.Add(r.SourceKey))
            .OrderBy(r => r.Timestamp)
            .ToList();
        if (fresh.Count == 0)
        {
            if (enriched > 0)
            {
                await db.SaveChangesAsync(ct);
                await RefreshRollupsAsync(station, enrichedTimes, ct);
            }
            return 0;
        }

        var openEvent = await db.IrrigationEvents
            .Where(e => e.StationId == station.Id && e.EndedAt == null)
            .OrderByDescending(e => e.StartedAt)
            .FirstOrDefaultAsync(ct);

        var added = new List<Reading>(fresh.Count);
        foreach (var reading in fresh)
        {
            var entity = new Reading
            {
                StationId = station.Id,
                SourceKey = reading.SourceKey,
                Timestamp = reading.Timestamp,
                Temperature = reading.Temperature,
                AirHumidity = reading.AirHumidity,
                SoilMoisture = reading.SoilMoisture,
                Light = reading.Light,
                PumpOn = reading.PumpOn,
                PumpMode = reading.PumpMode,
                ReceivedAt = clock.GetUtcNow(),
                SoilRaw = reading.SoilRaw,
                AirQualityRaw = reading.AirQualityRaw,
                AirQualityVoltage = reading.AirQualityVoltage,
                SpectralViolet = reading.Spectrum?.Violet,
                SpectralBlue = reading.Spectrum?.Blue,
                SpectralGreen = reading.Spectrum?.Green,
                SpectralYellow = reading.Spectrum?.Yellow,
                SpectralOrange = reading.Spectrum?.Orange,
                SpectralRed = reading.Spectrum?.Red,
                SpectralTotal = reading.Spectrum?.Total,
            };
            db.Readings.Add(entity);
            added.Add(entity);

            openEvent = ApplyPumpTransition(station, openEvent, reading);
        }

        var latest = fresh[^1].Timestamp;
        // No confiar en relojes del dispositivo que vayan adelantados.
        var now = clock.GetUtcNow();
        var lastSeen = latest > now ? now : latest;
        if (station.LastSeenAt is null || lastSeen > station.LastSeenAt) station.LastSeenAt = lastSeen;

        await db.SaveChangesAsync(ct);
        // En tiempo real a los navegadores conectados, antes de recalcular los resúmenes.
        live.Publish(station.Id, added);
        await RefreshRollupsAsync(station, fresh.Select(r => r.Timestamp).Concat(enrichedTimes).ToList(), ct);
        logger.LogDebug("Estación {Code}: {Count} lecturas nuevas", station.Code, fresh.Count);
        return fresh.Count;
    }

    /// <summary>Recalcula los resúmenes por minuto de los momentos afectados (agrupados en tramos contiguos).</summary>
    private async Task RefreshRollupsAsync(Station station, List<DateTimeOffset> times, CancellationToken ct)
    {
        if (times.Count == 0) return;
        var minutes = times.Select(RollupService.MinuteOf).Distinct().Order().ToList();

        var spanStart = minutes[0];
        var spanEnd = minutes[0];
        foreach (var minute in minutes.Skip(1))
        {
            // Tramos separados por más de 30 min se recalculan por separado (evita cargar días completos).
            if (minute - spanEnd > TimeSpan.FromMinutes(30))
            {
                await rollups.RefreshAsync(station.Id, spanStart, spanEnd, ct);
                spanStart = minute;
            }
            spanEnd = minute;
        }
        await rollups.RefreshAsync(station.Id, spanStart, spanEnd, ct);
        await db.SaveChangesAsync(ct);
    }

    private static bool Enrich(Reading stored, IncomingReading incoming)
    {
        var changed = false;
        void Fill<T>(T? current, T? value, Action<T?> set)
        {
            if (current is null && value is not null) { set(value); changed = true; }
        }

        Fill(stored.SoilRaw, incoming.SoilRaw, v => stored.SoilRaw = v);
        Fill(stored.AirQualityRaw, incoming.AirQualityRaw, v => stored.AirQualityRaw = v);
        Fill(stored.AirQualityVoltage, incoming.AirQualityVoltage, v => stored.AirQualityVoltage = v);
        if (incoming.Spectrum is { } s)
        {
            Fill(stored.SpectralViolet, s.Violet, v => stored.SpectralViolet = v);
            Fill(stored.SpectralBlue, s.Blue, v => stored.SpectralBlue = v);
            Fill(stored.SpectralGreen, s.Green, v => stored.SpectralGreen = v);
            Fill(stored.SpectralYellow, s.Yellow, v => stored.SpectralYellow = v);
            Fill(stored.SpectralOrange, s.Orange, v => stored.SpectralOrange = v);
            Fill(stored.SpectralRed, s.Red, v => stored.SpectralRed = v);
            Fill(stored.SpectralTotal, s.Total, v => stored.SpectralTotal = v);
        }
        return changed;
    }

    private IrrigationEvent? ApplyPumpTransition(Station station, IrrigationEvent? openEvent, IncomingReading reading)
    {
        if (reading.PumpOn is null) return openEvent;

        if (reading.PumpOn.Value && openEvent is null)
        {
            var started = new IrrigationEvent
            {
                StationId = station.Id,
                StartedAt = reading.Timestamp,
                StartMoisture = reading.SoilMoisture,
                Mode = reading.PumpMode ?? (station.AutoIrrigation ? IrrigationModes.Auto : IrrigationModes.Manual),
            };
            db.IrrigationEvents.Add(started);
            return started;
        }

        if (!reading.PumpOn.Value && openEvent is not null && reading.Timestamp >= openEvent.StartedAt)
        {
            openEvent.EndedAt = reading.Timestamp;
            openEvent.EndMoisture = reading.SoilMoisture;
            return null;
        }

        return openEvent;
    }

    public static void ApplyStatus(Station station, IncomingStatus status, DateTimeOffset now)
    {
        if (status.MacAddress is not null) station.MacAddress = status.MacAddress;
        if (status.IpAddress is not null) station.IpAddress = status.IpAddress;
        if (status.WifiRssi is not null) station.WifiRssi = status.WifiRssi;
        if (status.Firmware is not null) station.Firmware = status.Firmware;
        if (status.LastSeen is { } seen)
        {
            if (seen > now) seen = now;
            if (station.LastSeenAt is null || seen > station.LastSeenAt) station.LastSeenAt = seen;
        }
    }
}
