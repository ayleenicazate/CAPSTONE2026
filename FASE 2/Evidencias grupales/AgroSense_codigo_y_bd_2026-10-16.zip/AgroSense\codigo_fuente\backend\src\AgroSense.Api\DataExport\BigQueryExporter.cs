using System.Globalization;
using System.Text;
using System.Text.Json;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Metrics;
using Google.Apis.Bigquery.v2.Data;
using Google.Cloud.BigQuery.V2;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.DataExport;

/// <summary>
/// Copia periódicamente a BigQuery las lecturas crudas y los riegos terminados (exportación incremental por Id).
/// BigQuery queda como almacén analítico del histórico completo; PostgreSQL sigue siendo la base de la aplicación.
/// Usa "load jobs" (gratuitos y disponibles también en el modo sandbox de BigQuery, sin facturación).
/// </summary>
public class BigQueryExporter(
    IServiceScopeFactory scopes,
    BigQueryClientFactory factory,
    IOptions<BigQueryOptions> options,
    TimeProvider clock,
    ILogger<BigQueryExporter> logger) : BackgroundService
{
    public const string ReadingsKey = "bigquery:readings";
    public const string EventsKey = "bigquery:irrigation_events";
    public const string ReadingsTable = "readings";
    public const string EventsTable = "irrigation_events";

    private readonly BigQueryOptions _options = options.Value;

    public static readonly TableSchema ReadingsSchema = new TableSchemaBuilder
    {
        { "reading_id", BigQueryDbType.Int64, BigQueryFieldMode.Required },
        { "station_code", BigQueryDbType.String, BigQueryFieldMode.Required },
        { "ts", BigQueryDbType.Timestamp, BigQueryFieldMode.Required },
        { "received_at", BigQueryDbType.Timestamp },
        { "temperature", BigQueryDbType.Float64 },
        { "air_humidity", BigQueryDbType.Float64 },
        { "soil_moisture", BigQueryDbType.Float64 },
        { "soil_raw", BigQueryDbType.Int64 },
        { "light_total", BigQueryDbType.Float64 },
        { "spectral_violet", BigQueryDbType.Float64 },
        { "spectral_blue", BigQueryDbType.Float64 },
        { "spectral_green", BigQueryDbType.Float64 },
        { "spectral_yellow", BigQueryDbType.Float64 },
        { "spectral_orange", BigQueryDbType.Float64 },
        { "spectral_red", BigQueryDbType.Float64 },
        { "air_quality_raw", BigQueryDbType.Int64 },
        { "air_quality_voltage", BigQueryDbType.Float64 },
        { "air_quality_saturated", BigQueryDbType.Bool },
        { "pump_on", BigQueryDbType.Bool },
        { "pump_mode", BigQueryDbType.String },
        { "source_key", BigQueryDbType.String },
    }.Build();

    public static readonly TableSchema EventsSchema = new TableSchemaBuilder
    {
        { "event_id", BigQueryDbType.Int64, BigQueryFieldMode.Required },
        { "station_code", BigQueryDbType.String, BigQueryFieldMode.Required },
        { "started_at", BigQueryDbType.Timestamp, BigQueryFieldMode.Required },
        { "ended_at", BigQueryDbType.Timestamp },
        { "duration_seconds", BigQueryDbType.Float64 },
        { "mode", BigQueryDbType.String },
        { "start_moisture", BigQueryDbType.Float64 },
        { "end_moisture", BigQueryDbType.Float64 },
        { "water_liters", BigQueryDbType.Float64 },
    }.Build();

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!_options.Enabled)
        {
            logger.LogInformation("BigQuery desactivado (BigQuery:Enabled = false).");
            return;
        }

        BigQueryClient? client = null;
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(Math.Max(1, _options.ExportIntervalMinutes)));
        do
        {
            try
            {
                client ??= await CreateClientAsync(stoppingToken);
                await ExportOnceAsync(client, stoppingToken);
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Error exportando a BigQuery; se reintentará");
                await RecordErrorAsync(ex.Message, stoppingToken);
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    private async Task<BigQueryClient> CreateClientAsync(CancellationToken ct)
    {
        var client = await factory.GetAsync(ct);

        await client.GetOrCreateDatasetAsync(_options.Dataset, new Dataset { Location = _options.Location }, cancellationToken: ct);
        await EnsureTableAsync(client, ReadingsTable, ReadingsSchema, "ts", ct);
        await EnsureTableAsync(client, EventsTable, EventsSchema, "started_at", ct);
        logger.LogInformation("BigQuery listo: {Project}.{Dataset} ({Location})", _options.ProjectId, _options.Dataset, _options.Location);
        return client;
    }

    private async Task EnsureTableAsync(BigQueryClient client, string table, TableSchema schema, string partitionField, CancellationToken ct)
    {
        var resource = new Table
        {
            Schema = schema,
            TimePartitioning = new TimePartitioning { Type = "DAY", Field = partitionField },
            Clustering = new Clustering { Fields = ["station_code"] },
        };
        await client.GetOrCreateTableAsync(_options.Dataset, table, resource, cancellationToken: ct);
    }

    public async Task ExportOnceAsync(BigQueryClient client, CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
        var codes = await db.Stations.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.Code, ct);
        var flows = await db.Stations.AsNoTracking().ToDictionaryAsync(s => s.Id, s => s.PumpFlowLitersPerMinute, ct);

        // ---- Lecturas
        var readingsState = await GetStateAsync(db, ReadingsKey, ct);
        while (true)
        {
            var batch = await db.Readings.AsNoTracking()
                .Where(r => r.Id > readingsState.LastId)
                .OrderBy(r => r.Id)
                .Take(_options.BatchSize)
                .ToListAsync(ct);
            if (batch.Count == 0) break;

            await UploadAsync(client, ReadingsTable, ReadingsSchema, batch.Select(r => ToRow(r, codes)), ct);
            readingsState.LastId = batch[^1].Id;
            readingsState.TotalExported += batch.Count;
            readingsState.LastExportAt = clock.GetUtcNow();
            readingsState.LastError = null;
            await db.SaveChangesAsync(ct);
            logger.LogInformation("BigQuery: {Count} lecturas exportadas (hasta id {Id})", batch.Count, readingsState.LastId);
            if (batch.Count < _options.BatchSize) break;
        }

        // ---- Riegos terminados (en orden, sin saltarse uno que siga en curso)
        var eventsState = await GetStateAsync(db, EventsKey, ct);
        var events = await db.IrrigationEvents.AsNoTracking()
            .Where(e => e.Id > eventsState.LastId)
            .OrderBy(e => e.Id)
            .Take(5000)
            .ToListAsync(ct);
        var finished = events.TakeWhile(e => e.EndedAt is not null).ToList();
        if (finished.Count > 0)
        {
            await UploadAsync(client, EventsTable, EventsSchema, finished.Select(e => ToRow(e, codes, flows)), ct);
            eventsState.LastId = finished[^1].Id;
            eventsState.TotalExported += finished.Count;
            eventsState.LastExportAt = clock.GetUtcNow();
            eventsState.LastError = null;
            await db.SaveChangesAsync(ct);
        }
    }

    private async Task UploadAsync(BigQueryClient client, string table, TableSchema schema, IEnumerable<Dictionary<string, object?>> rows, CancellationToken ct)
    {
        using var stream = new MemoryStream();
        await using (var writer = new StreamWriter(stream, new UTF8Encoding(false), leaveOpen: true))
        {
            foreach (var row in rows)
            {
                await writer.WriteLineAsync(JsonSerializer.Serialize(row));
            }
        }
        stream.Position = 0;

        var job = await client.UploadJsonAsync(_options.Dataset, table, schema, stream,
            new UploadJsonOptions { WriteDisposition = WriteDisposition.WriteAppend }, ct);
        job = await job.PollUntilCompletedAsync(cancellationToken: ct);
        job.ThrowOnAnyError();
    }

    private static Dictionary<string, object?> ToRow(Reading r, IReadOnlyDictionary<Guid, string> codes) => new()
    {
        ["reading_id"] = r.Id,
        ["station_code"] = codes.GetValueOrDefault(r.StationId, "desconocida"),
        ["ts"] = Ts(r.Timestamp),
        ["received_at"] = Ts(r.ReceivedAt),
        ["temperature"] = r.Temperature,
        ["air_humidity"] = r.AirHumidity,
        ["soil_moisture"] = r.SoilMoisture,
        ["soil_raw"] = r.SoilRaw,
        ["light_total"] = r.SpectralTotal,
        ["spectral_violet"] = r.SpectralViolet,
        ["spectral_blue"] = r.SpectralBlue,
        ["spectral_green"] = r.SpectralGreen,
        ["spectral_yellow"] = r.SpectralYellow,
        ["spectral_orange"] = r.SpectralOrange,
        ["spectral_red"] = r.SpectralRed,
        ["air_quality_raw"] = r.AirQualityRaw,
        ["air_quality_voltage"] = r.AirQualityVoltage,
        ["air_quality_saturated"] = r.AirQualityRaw is null ? null : Variables.IsAirQualitySaturated(r),
        ["pump_on"] = r.PumpOn,
        ["pump_mode"] = r.PumpMode,
        ["source_key"] = r.SourceKey,
    };

    private static Dictionary<string, object?> ToRow(
        IrrigationEvent e, IReadOnlyDictionary<Guid, string> codes, IReadOnlyDictionary<Guid, double> flows)
    {
        var seconds = (e.EndedAt!.Value - e.StartedAt).TotalSeconds;
        return new()
        {
            ["event_id"] = e.Id,
            ["station_code"] = codes.GetValueOrDefault(e.StationId, "desconocida"),
            ["started_at"] = Ts(e.StartedAt),
            ["ended_at"] = Ts(e.EndedAt.Value),
            ["duration_seconds"] = Math.Round(seconds, 1),
            ["mode"] = e.Mode,
            ["start_moisture"] = e.StartMoisture,
            ["end_moisture"] = e.EndMoisture,
            ["water_liters"] = Math.Round(seconds / 60 * flows.GetValueOrDefault(e.StationId, 0), 3),
        };
    }

    private static string Ts(DateTimeOffset t) =>
        t.UtcDateTime.ToString("yyyy-MM-dd HH:mm:ss.ffffff", CultureInfo.InvariantCulture) + "+00:00";

    private static async Task<ExportState> GetStateAsync(AgroSenseDbContext db, string key, CancellationToken ct)
    {
        var state = await db.ExportStates.FindAsync([key], ct);
        if (state is not null) return state;
        state = new ExportState { Key = key };
        db.ExportStates.Add(state);
        await db.SaveChangesAsync(ct);
        return state;
    }

    private async Task RecordErrorAsync(string message, CancellationToken ct)
    {
        try
        {
            using var scope = scopes.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
            var state = await GetStateAsync(db, ReadingsKey, ct);
            state.LastError = message.Length > 1900 ? message[..1900] : message;
            state.LastErrorAt = clock.GetUtcNow();
            await db.SaveChangesAsync(ct);
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "No se pudo registrar el error de exportación");
        }
    }
}
