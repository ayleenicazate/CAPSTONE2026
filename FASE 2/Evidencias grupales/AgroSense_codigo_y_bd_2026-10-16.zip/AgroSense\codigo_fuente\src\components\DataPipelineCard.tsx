import { Database, Flame, HardDrive } from 'lucide-react'
import type { ReactNode } from 'react'

import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { formatDateTime, formatNumber, formatRelative } from '@/lib/format'
import { useSystemStatusQuery } from '@/services/queries'

/** Estado del flujo de datos: Firebase → PostgreSQL → BigQuery. */
export function DataPipelineCard() {
  const { data } = useSystemStatusQuery()
  if (!data) return null
  const bq = data.bigQuery

  return (
    <Card>
      <h2 className="text-xl font-semibold text-slate-900">Flujo de datos</h2>
      <p className="mt-1 text-sm text-slate-500">Dónde se guardan las lecturas del dispositivo.</p>

      <dl className="mt-5 space-y-4 text-sm">
        <Row icon={<Flame size={16} className="text-amber-600" />} title="Firebase (entrada)">
          {data.firebaseEnabled ? (
            <>
              <Badge tone="success">Conectado</Badge>
              <span className="text-slate-500">revisa cada {data.firebasePollSeconds} s</span>
            </>
          ) : (
            <Badge tone="neutral">Desactivado</Badge>
          )}
        </Row>

        <Row icon={<HardDrive size={16} className="text-green-700" />} title="PostgreSQL (aplicación)">
          <span className="text-slate-700">
            {formatNumber(data.storedReadings, 0)} lecturas · {formatNumber(data.storedMinutes, 0)} resúmenes por minuto
          </span>
          <span className="text-slate-500">
            {data.rawRetentionDays > 0
              ? `Lecturas crudas: últimos ${data.rawRetentionDays} días`
              : 'Lecturas crudas: se conservan todas'}
          </span>
        </Row>

        <Row icon={<Database size={16} className="text-sky-700" />} title="BigQuery (histórico y análisis)">
          {!bq.enabled ? (
            <Badge tone="neutral">Desactivado</Badge>
          ) : bq.lastError && (!bq.lastExportAt || (bq.lastErrorAt && bq.lastErrorAt > bq.lastExportAt)) ? (
            <>
              <Badge tone="warning">Con errores</Badge>
              <span className="break-words text-xs text-amber-700" title={bq.lastError}>
                {bq.lastError.length > 140 ? `${bq.lastError.slice(0, 140)}…` : bq.lastError}
              </span>
            </>
          ) : (
            <>
              <Badge tone="success">Exportando</Badge>
              <span className="text-slate-700">
                {formatNumber(bq.exportedReadings, 0)} lecturas en <code>{bq.dataset}</code>
              </span>
              <span className="text-slate-500" title={formatDateTime(bq.lastExportAt)}>
                Última exportación: {bq.lastExportAt ? formatRelative(bq.lastExportAt) : 'pendiente'}
              </span>
            </>
          )}
        </Row>
      </dl>
    </Card>
  )
}

function Row({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="flex gap-3">
      <span className="mt-0.5">{icon}</span>
      <div className="min-w-0 space-y-1">
        <dt className="font-medium text-slate-800">{title}</dt>
        <dd className="flex flex-col gap-1">{children}</dd>
      </div>
    </div>
  )
}
