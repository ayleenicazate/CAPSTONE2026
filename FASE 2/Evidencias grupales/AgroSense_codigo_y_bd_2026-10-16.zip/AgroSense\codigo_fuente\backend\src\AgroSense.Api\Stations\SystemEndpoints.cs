using AgroSense.Api.Data;
using AgroSense.Api.DataExport;
using AgroSense.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Stations;

public static class SystemEndpoints
{
    public static void MapSystemEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/api/system/status", async (
            AgroSenseDbContext db,
            IOptions<BigQueryOptions> bigQuery,
            IOptions<RetentionOptions> retention,
            IOptions<FirebaseOptions> firebase,
            CancellationToken ct) =>
        {
            var bq = bigQuery.Value;
            var state = await db.ExportStates.AsNoTracking().FirstOrDefaultAsync(s => s.Key == BigQueryExporter.ReadingsKey, ct);
            return new SystemStatusDto(
                new BigQueryStatusDto(
                    bq.Enabled,
                    bq.Enabled ? $"{bq.ProjectId}.{bq.Dataset}" : null,
                    state?.TotalExported ?? 0,
                    state?.LastExportAt,
                    state?.LastError,
                    state?.LastErrorAt),
                retention.Value.RawReadingDays,
                firebase.Value.Enabled,
                firebase.Value.PollIntervalSeconds,
                await db.Readings.LongCountAsync(ct),
                await db.ReadingMinutes.LongCountAsync(ct));
        }).RequireAuthorization().WithTags("Sistema");
    }
}
