using System.Globalization;
using System.Text;
using AgroSense.Api.Data;
using AgroSense.Api.Metrics;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Stations;

/// <summary>
/// Arma las respuestas del dashboard. Con lecturas cada 2–3 s, los gráficos y estadísticas usan los
/// resúmenes por minuto (<see cref="ReadingMinute"/>); las lecturas crudas solo se usan para el valor
/// actual, la vista "en vivo" y la tabla de registros recientes.
/// </summary>
public class DashboardService(AgroSenseDbContext db, StationService stations, TimeProvider clock)
{
    public static readonly IReadOnlyDictionary<string, (TimeSpan Window, TimeSpan Bucket, string BucketName)> Ranges =
        new Dictionary<string, (TimeSpan, TimeSpan, string)>
        {
            ["1h"] = (TimeSpan.FromHours(1), TimeSpan.FromMinutes(1), "minute"),
            ["24h"] = (TimeSpan.FromHours(24), TimeSpan.FromMinutes(15), "15min"),
            ["7d"] = (TimeSpan.FromDays(7), TimeSpan.FromHours(2), "2h"),
            ["30d"] = (TimeSpan.FromDays(30), TimeSpan.FromHours(6), "6h"),
        };

    /// <summary>Lecturas crudas recientes que se cargan para obtener el valor actual de cada sensor.</summary>
    private const int RecentRawCount = 400;

    public StationInfoDto ToInfo(Station s, string? role = null) =>
        new(s.Id, s.Code, s.Name, s.Location, stations.IsOnline(s), s.LastSeenAt, s.ReadingIntervalSeconds, role);

    // ---------------------------------------------------------------- Resumen

    public async Task<SummaryDto> GetSummaryAsync(Station station, CancellationToken ct)
    {
        var now = clock.GetUtcNow();
        var zone = stations.TimeZone;
        var minutes = await LoadMinutesAsync(station.Id, now.AddHours(-72), ct);
        var last24h = minutes.Where(m => m.Minute >= now.AddHours(-24)).ToList();
        var lastHour = minutes.Where(m => m.Minute >= now.AddHours(-1)).ToList();
        var recent = await LoadRecentRawAsync(station.Id, now.AddHours(-24), ct);

        double? Current(VariableInfo v) => LatestValue(recent, v.Selector) ?? LatestMinuteValue(last24h, v);

        var temperature = Current(Var(Variables.Temperature));
        var airHumidity = Current(Var(Variables.AirHumidity));
        var soil = Current(Var(Variables.SoilMoisture));

        var metrics = new List<MetricDto>();
        foreach (var variable in Variables.All)
        {
            var sparkline = Analytics.FromMinutes(lastHour, variable).Select(p => new PointDto(p.Timestamp, p.Average)).ToList();
            metrics.Add(variable.Key == Variables.AirQuality
                ? AirQualityMetric(recent, station) with { Sparkline = sparkline }
                : Metric(variable, Current(variable), station) with { Sparkline = sparkline });
        }

        if (temperature is not null && airHumidity is not null)
        {
            var vpd = Analytics.VaporPressureDeficit(temperature.Value, airHumidity.Value);
            metrics.Add(new MetricDto("vpd", "Déficit de presión de vapor", vpd, "kPa", Analytics.EvaluateVpd(vpd),
                "Demanda de agua del aire sobre la planta. Óptimo: 0,8–1,2 kPa.",
                VpdSparkline(lastHour)));
            var dew = Analytics.DewPoint(temperature.Value, airHumidity.Value);
            metrics.Add(new MetricDto("dewPoint", "Punto de rocío", dew, "°C",
                temperature.Value - dew < 2 ? Variables.Status("Condensación", Tone.Info) : Variables.Status("Normal", Tone.Normal),
                "Si la temperatura se acerca a este valor se forma condensación en las hojas."));
        }
        else
        {
            metrics.Add(new MetricDto("vpd", "Déficit de presión de vapor", null, "kPa", null));
            metrics.Add(new MetricDto("dewPoint", "Punto de rocío", null, "°C", null));
        }

        var soilSeries = Analytics
            .Rebucket(Analytics.FromMinutes(last24h, Var(Variables.SoilMoisture)), TimeSpan.FromHours(1), zone)
            .Select(b => new PointDto(b.Timestamp, Math.Round(b.Average, 2)))
            .ToList();

        var openEvent = await db.IrrigationEvents.AnyAsync(e => e.StationId == station.Id && e.EndedAt == null, ct);
        var pumpOn = recent.FirstOrDefault(r => r.PumpOn is not null)?.PumpOn ?? openEvent;
        var estimate = await EstimateNextIrrigationAsync(station, minutes, now, ct);
        var today = await GetDaySummaryAsync(station, minutes, now, zone, ct);
        var latestAt = recent.FirstOrDefault()?.Timestamp ?? last24h.LastOrDefault()?.Minute;

        return new SummaryDto(
            ToInfo(station),
            latestAt is null
                ? null
                : new LatestReadingDto(latestAt.Value, temperature, airHumidity, soil, Current(Var(Variables.Light)), pumpOn),
            metrics,
            soilSeries,
            new IrrigationStatusDto(station.AutoIrrigation, pumpOn, station.ManualPump, soil,
                station.ActivationThreshold, station.DeactivationThreshold, estimate),
            today,
            BuildAlerts(station, recent, temperature, airHumidity, soil, pumpOn, now));
    }

    private async Task<DaySummaryDto> GetDaySummaryAsync(
        Station station, List<ReadingMinute> minutes, DateTimeOffset now, TimeZoneInfo zone, CancellationToken ct)
    {
        var midnight = Analytics.BucketStart(now, TimeSpan.FromDays(1), zone);
        var events = await db.IrrigationEvents
            .Where(e => e.StationId == station.Id && (e.EndedAt == null || e.EndedAt >= midnight))
            .ToListAsync(ct);
        var pumpMinutes = events.Sum(e => DurationWithin(e, midnight, now).TotalMinutes);

        var today = minutes.Where(m => m.Minute >= midnight).ToList();
        var temperatures = Analytics.FromMinutes(today, Var(Variables.Temperature));

        // Horas con luz: horas cuyo promedio supera el 40 % del máximo de los últimos 3 días
        // (el AS7262 no entrega un %, así que se usa una referencia relativa).
        var light = Var(Variables.Light);
        var lightPoints = Analytics.FromMinutes(minutes, light);
        var reference = lightPoints.Count > 0 ? lightPoints.Max(p => p.Average) * 0.4 : 0;
        var todayLight = Analytics.FromMinutes(today, light);
        var lightHours = Analytics.Rebucket(todayLight, TimeSpan.FromHours(1), zone)
            .Count(b => reference > 0 && b.Average >= reference);

        return new DaySummaryDto(
            events.Count(e => e.StartedAt >= midnight),
            Math.Round(pumpMinutes, 1),
            Math.Round(pumpMinutes * station.PumpFlowLitersPerMinute, 1),
            temperatures.Count > 0 ? temperatures.Min(p => p.Min) : null,
            temperatures.Count > 0 ? temperatures.Max(p => p.Max) : null,
            todayLight.Count > 0 ? lightHours : null);
    }

    private async Task<DateTimeOffset?> EstimateNextIrrigationAsync(
        Station station, List<ReadingMinute> minutes, DateTimeOffset now, CancellationToken ct)
    {
        var soil = await SoilSinceLastIrrigationAsync(station, minutes, now, ct);
        return Analytics.EstimateThresholdCrossing(soil, station.ActivationThreshold, now);
    }

    private async Task<List<TimedValue>> SoilSinceLastIrrigationAsync(
        Station station, List<ReadingMinute> minutes, DateTimeOffset now, CancellationToken ct)
    {
        var lastEnd = await db.IrrigationEvents
            .Where(e => e.StationId == station.Id && e.EndedAt != null)
            .MaxAsync(e => e.EndedAt, ct);
        var from = lastEnd is { } end && end > now.AddHours(-72) ? end : now.AddHours(-72);
        return Analytics.FromMinutes(minutes.Where(m => m.Minute >= from), Var(Variables.SoilMoisture))
            .Select(p => new TimedValue(p.Timestamp, p.Average))
            .ToList();
    }

    private List<AlertDto> BuildAlerts(
        Station station, List<Reading> recent, double? temperature, double? humidity, double? soil, bool pumpOn, DateTimeOffset now)
    {
        var alerts = new List<AlertDto>();
        if (station.LastSeenAt is null)
        {
            alerts.Add(new("no-data", "info", "Sin datos todavía", "La estación aún no ha enviado lecturas."));
            return alerts;
        }

        if (!stations.IsOnline(station))
        {
            alerts.Add(new("offline", "critical", "Dispositivo fuera de línea",
                $"No se reciben datos desde hace {Ago(now - station.LastSeenAt.Value)}. Revisa la alimentación y el WiFi del ESP32."));
        }

        if (soil is not null && soil < station.ActivationThreshold && !pumpOn)
        {
            alerts.Add(new("soil-dry", station.AutoIrrigation ? "warning" : "critical", "Suelo seco",
                station.AutoIrrigation
                    ? $"Humedad {soil:0.#} % bajo el umbral ({station.ActivationThreshold:0.#} %), pero la bomba no está regando."
                    : $"Humedad {soil:0.#} % bajo el umbral ({station.ActivationThreshold:0.#} %) y el riego automático está desactivado."));
        }

        if (temperature is > 35) alerts.Add(new("temp-high", "warning", "Temperatura alta", $"{temperature:0.#} °C: riesgo de estrés térmico."));
        if (temperature is < 5) alerts.Add(new("temp-low", "warning", "Riesgo de helada", $"{temperature:0.#} °C."));

        if (temperature is not null && humidity is not null && Analytics.VaporPressureDeficit(temperature.Value, humidity.Value) > 1.6)
        {
            alerts.Add(new("vpd-high", "warning", "Estrés hídrico (VPD alto)",
                "El aire está muy seco para la temperatura actual; las plantas pierden agua rápidamente."));
        }

        var lastMq = recent.FirstOrDefault(r => r.AirQualityRaw is not null);
        if (lastMq is not null && Variables.IsAirQualitySaturated(lastMq))
        {
            alerts.Add(new("mq135-saturated", "info", "MQ135 saturado",
                "El sensor de calidad del aire marca el máximo (4095). Está en calentamiento o necesita un divisor de voltaje."));
        }

        if (stations.IsOnline(station) && recent.Count > 0)
        {
            var window = recent.Take(20).ToList();
            if (window.All(r => r.Temperature is null && r.AirHumidity is null))
                alerts.Add(new("sht3x-missing", "warning", "SHT3x sin datos", "Las últimas lecturas no traen temperatura ni humedad."));
            if (window.All(r => r.SoilMoisture is null))
                alerts.Add(new("soil-missing", "warning", "Sensor de suelo sin datos", "Las últimas lecturas no traen humedad del suelo."));
            if (window.All(r => r.SpectralTotal is null))
                alerts.Add(new("as7262-missing", "info", "AS7262 sin datos", "Las últimas lecturas no traen el espectro de luz."));
        }

        return alerts;
    }

    // ---------------------------------------------------------------- En vivo

    public async Task<LiveDto> GetLiveAsync(Station station, int minutes, CancellationToken ct)
    {
        minutes = Math.Clamp(minutes, 1, 30);
        var from = clock.GetUtcNow().AddMinutes(-minutes);
        var readings = await db.Readings.AsNoTracking()
            .Where(r => r.StationId == station.Id && r.Timestamp >= from)
            .OrderByDescending(r => r.Timestamp)
            .Take(1200)
            .ToListAsync(ct);
        readings.Reverse();

        var live = readings.Select(ToLive).ToList();
        LiveReadingDto? latest = live.LastOrDefault();
        if (latest is null)
        {
            var last = await db.Readings.AsNoTracking()
                .Where(r => r.StationId == station.Id)
                .OrderByDescending(r => r.Timestamp)
                .FirstOrDefaultAsync(ct);
            latest = last is null ? null : ToLive(last);
        }

        return new LiveDto(stations.IsOnline(station), station.LastSeenAt, station.ReadingIntervalSeconds, latest, live);
    }

    private static LiveReadingDto ToLive(Reading r) => Ingestion.LiveBroadcaster.ToLive(r);

    // ---------------------------------------------------------------- Sensores

    public async Task<SensorsDto> GetSensorsAsync(Station station, int hours, CancellationToken ct)
    {
        hours = Math.Clamp(hours, 1, 48);
        var now = clock.GetUtcNow();
        var zone = stations.TimeZone;
        var minutes = await LoadMinutesAsync(station.Id, now.AddHours(-hours), ct);
        var recent = await LoadRecentRawAsync(station.Id, now.AddHours(-hours), ct);
        var window = TimeSpan.FromSeconds(Math.Max(120, station.ReadingIntervalSeconds * 3));

        bool Reporting(Func<Reading, double?> selector) =>
            recent.FirstOrDefault(r => selector(r) is not null) is { } r && now - r.Timestamp <= window;

        var temperature = LatestValue(recent, r => r.Temperature);
        var humidity = LatestValue(recent, r => r.AirHumidity);
        var soil = LatestValue(recent, r => r.SoilMoisture);
        var light = LatestValue(recent, r => r.SpectralTotal);
        var soilRaw = recent.FirstOrDefault(r => r.SoilRaw is not null)?.SoilRaw;
        var mq = recent.FirstOrDefault(r => r.AirQualityRaw is not null || r.AirQualityVoltage is not null);
        var pump = recent.FirstOrDefault(r => r.PumpOn is not null);

        var sensors = new List<SensorDto>
        {
            new("sht3x", "Temperatura y humedad", "SHT3x", "Temperatura (°C) y humedad relativa del aire (%)",
                [Variables.Temperature, Variables.AirHumidity], Reporting(r => r.Temperature ?? r.AirHumidity),
                temperature is null && humidity is null ? null : $"{Format(temperature, "°C")} · {Format(humidity, "%")}"),
            new("soil", "Humedad del suelo", "Sensor de humedad de suelo", "Humedad relativa del suelo (%), base del riego automático",
                [Variables.SoilMoisture], Reporting(r => r.SoilMoisture),
                soil is null ? null : soilRaw is null ? Format(soil, "%") : $"{Format(soil, "%")} (RAW {soilRaw})"),
            new("as7262", "Espectro de luz", "AS7262", "Luz visible en 6 bandas (violeta a rojo), µW/cm²",
                [Variables.Light], Reporting(r => r.SpectralTotal), light is null ? null : Format(light, "µW/cm²")),
            new("mq135", "Calidad del aire", "MQ135", "Gases en el aire (CO₂, NH₃, alcohol, humo). Valor relativo, sin calibrar a ppm",
                [Variables.AirQuality], mq is not null && now - mq.Timestamp <= window,
                mq is null ? null
                    : Variables.IsAirQualitySaturated(mq) ? $"Saturado (RAW {mq.AirQualityRaw}): en calentamiento o revisar divisor"
                    : $"{Format(mq.AirQualityVoltage, "V")} (RAW {mq.AirQualityRaw})"),
            new("pump", "Bomba de riego", "Relé 2 canales + bomba", "Actuador del riego automático",
                [], pump is not null && now - pump.Timestamp <= window,
                pump is null ? null : pump.PumpOn == true ? "Encendida" : "Apagada"),
        };

        // ~150 puntos por gráfico, con un mínimo de 1 minuto por punto.
        var bucket = TimeSpan.FromMinutes(Math.Max(1, Math.Ceiling(hours * 60 / 150.0)));
        var variables = Variables.All.Select(v =>
        {
            var points = Analytics.FromMinutes(minutes, v);
            var series = Analytics.Rebucket(points, bucket, zone)
                .Select(b => new PointDto(b.Timestamp, Math.Round(b.Average, v.Digits + 1)))
                .ToList();
            return new VariableSeriesDto(v.Key, v.Label, v.Unit, LatestValue(recent, v.Selector), Analytics.StatsFromBuckets(points), series);
        }).ToList();

        var spectral = recent.FirstOrDefault(r => r.SpectralTotal is not null);
        var spectrum = spectral is null ? null : new SpectrumDto(spectral.Timestamp,
        [
            new("violet", "Violeta", 450, spectral.SpectralViolet, "#8b5cf6"),
            new("blue", "Azul", 500, spectral.SpectralBlue, "#3b82f6"),
            new("green", "Verde", 550, spectral.SpectralGreen, "#22c55e"),
            new("yellow", "Amarillo", 570, spectral.SpectralYellow, "#eab308"),
            new("orange", "Naranja", 600, spectral.SpectralOrange, "#f97316"),
            new("red", "Rojo", 650, spectral.SpectralRed, "#ef4444"),
        ], spectral.SpectralTotal);

        static double? Avg(IEnumerable<double?> values)
        {
            var list = values.Where(v => v is not null).Select(v => v!.Value).ToList();
            return list.Count == 0 ? null : Math.Round(list.Average(), 2);
        }

        var spectralSeries = minutes
            .Where(m => m.SpectralVioletAvg is not null)
            .GroupBy(m => Analytics.BucketStart(m.Minute, bucket, zone))
            .OrderBy(g => g.Key)
            .Select(g => new SpectralPointDto(g.Key,
                Avg(g.Select(m => m.SpectralVioletAvg)), Avg(g.Select(m => m.SpectralBlueAvg)),
                Avg(g.Select(m => m.SpectralGreenAvg)), Avg(g.Select(m => m.SpectralYellowAvg)),
                Avg(g.Select(m => m.SpectralOrangeAvg)), Avg(g.Select(m => m.SpectralRedAvg))))
            .ToList();

        return new SensorsDto(recent.FirstOrDefault()?.Timestamp, hours, sensors, variables, spectrum, spectralSeries);
    }

    // ---------------------------------------------------------------- Historial

    public async Task<HistoryDto?> GetHistoryAsync(Station station, string variableKey, string range, CancellationToken ct)
    {
        var variable = Variables.Find(variableKey);
        if (variable is null || !Ranges.TryGetValue(range, out var spec)) return null;

        var now = clock.GetUtcNow();
        var zone = stations.TimeZone;
        var rangeStart = now - spec.Window;
        // El pronóstico necesita 7 días de perfil horario.
        var loadFrom = spec.Window > TimeSpan.FromDays(7) ? rangeStart : now.AddDays(-7);
        var minutes = await LoadMinutesAsync(station.Id, loadFrom, ct);
        var inRange = Analytics.FromMinutes(minutes.Where(m => m.Minute >= rangeStart), variable);

        var series = Analytics.Rebucket(inRange, spec.Bucket, zone)
            .Select(b => new BucketDto(b.Timestamp, Math.Round(b.Average, variable.Digits + 1), b.Min, b.Max))
            .ToList();

        // En 30 días un pronóstico de 24 h no se aprecia; en 1 h tampoco aporta.
        List<ForecastPointDto> forecast = [];
        string? method = null;
        string? source = null;
        if (range is "24h" or "7d")
        {
            // Preferir el pronóstico de BigQuery ML (con intervalo de confianza) si está disponible y vigente.
            var horizon = now.AddHours(range == "7d" ? 48 : 24);
            var ml = await db.MlForecasts.AsNoTracking()
                .Where(f => f.StationId == station.Id && f.Variable == variable.Key && f.Timestamp > now && f.Timestamp <= horizon)
                .OrderBy(f => f.Timestamp)
                .ToListAsync(ct);
            if (ml.Count >= 6)
            {
                forecast = ml.Select(f => new ForecastPointDto(f.Timestamp, f.Value, f.Lower, f.Upper)).ToList();
                var model = ml[0].Model;
                method = $"BigQuery ML · ARIMA_PLUS{(model is { } d ? $" · {d}" : "")} · entrenado con {ml[0].TrainingHours} h · intervalo de confianza 90 %";
                source = "bigquery-ml";
            }
            else
            {
                var (local, localMethod) = await ForecastAsync(station, variable, minutes, now, zone, ct);
                forecast = local.Select(p => new ForecastPointDto(p.Timestamp, p.Value)).ToList();
                method = localMethod;
                source = local.Count > 0 ? "local" : null;
            }
        }

        var raw = await db.Readings.AsNoTracking()
            .Where(r => r.StationId == station.Id && r.Timestamp >= rangeStart)
            .OrderByDescending(r => r.Timestamp)
            .Take(1000)
            .ToListAsync(ct);
        var records = raw
            .Select(r => (r.Timestamp, Value: variable.Selector(r)))
            .Where(x => x.Value is not null)
            .Take(200)
            .Select(x => new HistoryRecordDto(x.Timestamp, x.Value!.Value, Variables.Evaluate(variable.Key, x.Value.Value, station)))
            .ToList();

        return new HistoryDto(
            ToDto(variable),
            range,
            spec.BucketName,
            Variables.All.Select(ToDto).ToList(),
            series,
            forecast,
            method,
            source,
            Analytics.StatsFromBuckets(inRange),
            records);
    }

    private async Task<(List<TimedValue>, string?)> ForecastAsync(
        Station station, VariableInfo variable, List<ReadingMinute> minutes, DateTimeOffset now, TimeZoneInfo zone, CancellationToken ct)
    {
        const int hours = 24;
        if (variable.Key == Variables.SoilMoisture)
        {
            var recent = await SoilSinceLastIrrigationAsync(station, minutes, now, ct);
            var linear = Analytics.ForecastLinear(recent, now, hours, zone, 0, 100);
            return (linear, linear.Count > 0 ? "Tendencia lineal de secado desde el último riego (sin considerar riegos futuros)" : null);
        }

        var hourly = Analytics.Rebucket(Analytics.FromMinutes(minutes.Where(m => m.Minute >= now.AddDays(-7)), variable), TimeSpan.FromHours(1), zone)
            .Select(b => new TimedValue(b.Timestamp, b.Average))
            .ToList();
        double? min = variable.Unit is "%" or "µW/cm²" or "V" ? 0 : null;
        double? max = variable.Unit == "%" ? 100 : null;
        var profile = Analytics.ForecastDailyProfile(hourly, now, hours, zone, min, max);
        return (profile, profile.Count > 0 ? "Perfil horario promedio de los últimos 7 días, ajustado al nivel actual" : null);
    }

    /// <summary>Promedio por hora del día para los últimos N días (mapa de calor día × hora, en hora local).</summary>
    public async Task<HeatmapDto?> GetHeatmapAsync(Station station, string variableKey, int days, CancellationToken ct)
    {
        var variable = Variables.Find(variableKey);
        if (variable is null) return null;
        days = Math.Clamp(days, 1, 31);

        var zone = stations.TimeZone;
        var now = clock.GetUtcNow();
        var firstDay = Analytics.BucketStart(now, TimeSpan.FromDays(1), zone).AddDays(-(days - 1));
        var points = Analytics.FromMinutes(await LoadMinutesAsync(station.Id, firstDay, ct), variable);

        var byCell = points
            .GroupBy(p =>
            {
                var local = TimeZoneInfo.ConvertTime(p.Timestamp, zone);
                return (Date: DateOnly.FromDateTime(local.DateTime), local.Hour);
            })
            .ToDictionary(g => g.Key, g => Math.Round(g.Average(p => p.Average), variable.Digits));

        var firstLocal = DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(firstDay, zone).DateTime);
        var result = Enumerable.Range(0, days)
            .Select(i => firstLocal.AddDays(i))
            .Select(date => new HeatmapDayDto(date,
                Enumerable.Range(0, 24).Select(h => byCell.TryGetValue((date, h), out var v) ? v : (double?)null).ToList()))
            .ToList();

        var values = byCell.Values.ToList();
        return new HeatmapDto(ToDto(variable), result, values.Count > 0 ? values.Min() : null, values.Count > 0 ? values.Max() : null);
    }

    /// <summary>CSV: lecturas crudas para 1 h / 24 h; promedios por minuto para 7 y 30 días.</summary>
    public async Task<string> ExportCsvAsync(Station station, string range, CancellationToken ct)
    {
        var spec = Ranges.TryGetValue(range, out var s) ? s : Ranges["7d"];
        var from = clock.GetUtcNow() - spec.Window;
        var zone = stations.TimeZone;
        var sb = new StringBuilder();
        string Local(DateTimeOffset t) => TimeZoneInfo.ConvertTime(t, zone).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

        if (spec.Window <= TimeSpan.FromHours(24))
        {
            var readings = await db.Readings.AsNoTracking()
                .Where(r => r.StationId == station.Id && r.Timestamp >= from)
                .OrderBy(r => r.Timestamp)
                .ToListAsync(ct);
            sb.AppendLine("fecha_hora_local,temperatura_c,humedad_ambiental_pct,humedad_suelo_pct,suelo_raw,luz_total_uw_cm2,violeta,azul,verde,amarillo,naranja,rojo,mq135_raw,mq135_voltaje,bomba_encendida");
            foreach (var r in readings)
            {
                sb.Append(Local(r.Timestamp)).Append(',')
                    .Append(Csv(r.Temperature)).Append(',')
                    .Append(Csv(r.AirHumidity)).Append(',')
                    .Append(Csv(r.SoilMoisture)).Append(',')
                    .Append(r.SoilRaw?.ToString(CultureInfo.InvariantCulture) ?? "").Append(',')
                    .Append(Csv(r.SpectralTotal)).Append(',')
                    .Append(Csv(r.SpectralViolet)).Append(',')
                    .Append(Csv(r.SpectralBlue)).Append(',')
                    .Append(Csv(r.SpectralGreen)).Append(',')
                    .Append(Csv(r.SpectralYellow)).Append(',')
                    .Append(Csv(r.SpectralOrange)).Append(',')
                    .Append(Csv(r.SpectralRed)).Append(',')
                    .Append(r.AirQualityRaw?.ToString(CultureInfo.InvariantCulture) ?? "").Append(',')
                    .Append(Csv(r.AirQualityVoltage)).Append(',')
                    .Append(r.PumpOn switch { true => "1", false => "0", null => "" })
                    .AppendLine();
            }
            return sb.ToString();
        }

        var minutes = await LoadMinutesAsync(station.Id, from, ct);
        sb.AppendLine("minuto_local,lecturas,temperatura_prom_c,temperatura_min_c,temperatura_max_c,humedad_ambiental_prom_pct,humedad_suelo_prom_pct,humedad_suelo_min_pct,luz_total_prom_uw_cm2,mq135_voltaje_prom,bomba_encendida_pct");
        foreach (var m in minutes)
        {
            sb.Append(Local(m.Minute)).Append(',')
                .Append(m.Count).Append(',')
                .Append(Csv(m.TemperatureAvg)).Append(',')
                .Append(Csv(m.TemperatureMin)).Append(',')
                .Append(Csv(m.TemperatureMax)).Append(',')
                .Append(Csv(m.AirHumidityAvg)).Append(',')
                .Append(Csv(m.SoilMoistureAvg)).Append(',')
                .Append(Csv(m.SoilMoistureMin)).Append(',')
                .Append(Csv(m.LightAvg)).Append(',')
                .Append(Csv(m.AirQualityAvg)).Append(',')
                .Append(m.Count == 0 ? "" : Csv(Math.Round(100.0 * m.PumpOnCount / m.Count, 1)))
                .AppendLine();
        }
        return sb.ToString();
    }

    // ---------------------------------------------------------------- Riego

    public async Task<IrrigationDto> GetIrrigationAsync(Station station, bool deviceSynced, CancellationToken ct)
    {
        var now = clock.GetUtcNow();
        var zone = stations.TimeZone;
        var midnight = Analytics.BucketStart(now, TimeSpan.FromDays(1), zone);
        var weekAgo = now.AddDays(-7);
        var firstDay = midnight.AddDays(-13);

        var minutes = await LoadMinutesAsync(station.Id, now.AddHours(-72), ct);
        var recent = await LoadRecentRawAsync(station.Id, now.AddHours(-24), ct);
        var periodEvents = await db.IrrigationEvents
            .Where(e => e.StationId == station.Id && (e.EndedAt == null || e.EndedAt >= firstDay))
            .ToListAsync(ct);
        var recentEvents = await db.IrrigationEvents
            .Where(e => e.StationId == station.Id)
            .OrderByDescending(e => e.StartedAt)
            .Take(20)
            .ToListAsync(ct);

        var flow = station.PumpFlowLitersPerMinute;
        var todayMinutes = periodEvents.Sum(e => DurationWithin(e, midnight, now).TotalMinutes);
        var weekMinutes = periodEvents.Sum(e => DurationWithin(e, weekAgo, now).TotalMinutes);
        var pumpOn = recent.FirstOrDefault(r => r.PumpOn is not null)?.PumpOn
            ?? periodEvents.Any(e => e.EndedAt == null);

        var stats = new IrrigationStatsDto(
            periodEvents.Count(e => e.StartedAt >= midnight),
            Math.Round(todayMinutes, 1),
            Math.Round(todayMinutes * flow, 1),
            periodEvents.Count(e => e.StartedAt >= weekAgo),
            Math.Round(weekMinutes * flow, 1),
            recentEvents.FirstOrDefault()?.StartedAt);

        var events = recentEvents.Select(e =>
        {
            var duration = ((e.EndedAt ?? now) - e.StartedAt).TotalSeconds;
            return new IrrigationEventDto(e.Id, e.StartedAt, e.EndedAt, Math.Round(duration),
                e.Mode, e.StartMoisture, e.EndMoisture, Math.Round(duration / 60 * flow, 2));
        }).ToList();

        var daily = Enumerable.Range(0, 14).Select(i =>
        {
            var dayStart = firstDay.AddDays(i);
            var dayEnd = dayStart.AddDays(1) < now ? dayStart.AddDays(1) : now;
            var dayMinutes = periodEvents.Sum(e => DurationWithin(e, dayStart, dayEnd).TotalMinutes);
            return new IrrigationDayDto(
                DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(dayStart, zone).DateTime),
                periodEvents.Count(e => e.StartedAt >= dayStart && e.StartedAt < dayStart.AddDays(1)),
                Math.Round(dayMinutes, 1),
                Math.Round(dayMinutes * flow, 1));
        }).ToList();

        var soil48h = Analytics
            .Rebucket(Analytics.FromMinutes(minutes.Where(m => m.Minute >= now.AddHours(-48)), Var(Variables.SoilMoisture)),
                TimeSpan.FromMinutes(10), zone)
            .Select(b => new BucketDto(b.Timestamp, Math.Round(b.Average, 2), b.Min, b.Max))
            .ToList();

        return new IrrigationDto(
            ToIrrigationConfig(station),
            pumpOn,
            LatestValue(recent, r => r.SoilMoisture) ?? LatestMinuteValue(minutes, Var(Variables.SoilMoisture)),
            await EstimateNextIrrigationAsync(station, minutes, now, ct),
            stats,
            events,
            deviceSynced,
            daily,
            soil48h);
    }

    public static IrrigationConfigDto ToIrrigationConfig(Station s) =>
        new(s.AutoIrrigation, s.ActivationThreshold, s.DeactivationThreshold, s.MaxPumpSeconds, s.ManualPump);

    public SettingsDto ToSettings(Station s) => new(
        s.Id, s.Code, s.Name, s.Location, s.ReadingIntervalSeconds, s.PumpFlowLitersPerMinute,
        ToIrrigationConfig(s),
        new DeviceInfoDto(s.Hardware, stations.IsOnline(s), s.LastSeenAt, s.MacAddress, s.IpAddress, s.WifiRssi, s.Firmware));

    // ---------------------------------------------------------------- helpers

    private Task<List<ReadingMinute>> LoadMinutesAsync(Guid stationId, DateTimeOffset from, CancellationToken ct) =>
        db.ReadingMinutes.AsNoTracking()
            .Where(m => m.StationId == stationId && m.Minute >= from)
            .OrderBy(m => m.Minute)
            .ToListAsync(ct);

    /// <summary>Últimas lecturas crudas, de la más nueva a la más antigua.</summary>
    private Task<List<Reading>> LoadRecentRawAsync(Guid stationId, DateTimeOffset from, CancellationToken ct) =>
        db.Readings.AsNoTracking()
            .Where(r => r.StationId == stationId && r.Timestamp >= from)
            .OrderByDescending(r => r.Timestamp)
            .Take(RecentRawCount)
            .ToListAsync(ct);

    private static VariableInfo Var(string key) => Variables.Find(key)!;

    /// <summary>Primer valor no nulo de una lista ordenada de más nueva a más antigua.</summary>
    private static double? LatestValue(IEnumerable<Reading> newestFirst, Func<Reading, double?> selector) =>
        newestFirst.Select(selector).FirstOrDefault(v => v is not null);

    private static double? LatestMinuteValue(IEnumerable<ReadingMinute> minutes, VariableInfo variable) =>
        minutes.Select(m => variable.Minute(m).Avg).LastOrDefault(v => v is not null);

    private static List<PointDto> VpdSparkline(List<ReadingMinute> minutes) =>
        minutes
            .Where(m => m.TemperatureAvg is not null && m.AirHumidityAvg is not null)
            .Select(m => new PointDto(m.Minute, Analytics.VaporPressureDeficit(m.TemperatureAvg!.Value, m.AirHumidityAvg!.Value)))
            .ToList();

    private static MetricDto Metric(VariableInfo info, double? value, Station station) =>
        new(info.Key, info.Label, value, info.Unit, value is null ? null : Variables.Evaluate(info.Key, value.Value, station));

    private static MetricDto AirQualityMetric(List<Reading> newestFirst, Station station)
    {
        var info = Var(Variables.AirQuality);
        var last = newestFirst.FirstOrDefault(r => r.AirQualityRaw is not null || r.AirQualityVoltage is not null);
        if (last is null) return new MetricDto(info.Key, info.Label, null, info.Unit, null);
        if (Variables.IsAirQualitySaturated(last))
        {
            return new MetricDto(info.Key, info.Label, last.AirQualityVoltage, info.Unit,
                Variables.Status("Saturado", Tone.Warning),
                "El sensor marca el máximo del ADC: está en calentamiento (24–48 h) o necesita un divisor de voltaje.");
        }
        return new MetricDto(info.Key, info.Label, last.AirQualityVoltage, info.Unit,
            last.AirQualityVoltage is { } v ? Variables.Evaluate(Variables.AirQuality, v, station) : null,
            "Índice relativo sin calibrar: importa su evolución en el tiempo más que el valor absoluto.");
    }

    private static VariableDto ToDto(VariableInfo v) => new(v.Key, v.Label, v.Unit);

    private static TimeSpan DurationWithin(IrrigationEvent e, DateTimeOffset from, DateTimeOffset to)
    {
        var start = e.StartedAt > from ? e.StartedAt : from;
        var end = e.EndedAt ?? to;
        if (end > to) end = to;
        return end > start ? end - start : TimeSpan.Zero;
    }

    private static string Ago(TimeSpan span) => span.TotalMinutes < 60
        ? $"{Math.Max(1, (int)span.TotalMinutes)} min"
        : span.TotalHours < 48 ? $"{(int)span.TotalHours} h" : $"{(int)span.TotalDays} días";

    private static string Format(double? value, string unit) =>
        value is null ? "—" : $"{value.Value.ToString("0.#", CultureInfo.GetCultureInfo("es-CL"))} {unit}";

    private static string Csv(double? value) => value?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
}
