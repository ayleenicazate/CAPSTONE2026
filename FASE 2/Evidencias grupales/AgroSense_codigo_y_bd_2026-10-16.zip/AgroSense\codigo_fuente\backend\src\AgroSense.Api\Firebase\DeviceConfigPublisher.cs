using AgroSense.Api.Data;

namespace AgroSense.Api.Firebase;

/// <summary>Configuración que el ESP32 lee desde /stations/{code}/config.</summary>
public record DeviceConfig(
    bool AutoIrrigation,
    double ActivationThreshold,
    double DeactivationThreshold,
    int ReadingIntervalSec,
    int MaxPumpSeconds,
    bool ManualPump)
{
    public static DeviceConfig From(Station station) => new(
        station.AutoIrrigation,
        station.ActivationThreshold,
        station.DeactivationThreshold,
        station.ReadingIntervalSeconds,
        station.MaxPumpSeconds,
        station.ManualPump);
}

public interface IDeviceConfigPublisher
{
    /// <summary>Publica la configuración. Devuelve false si no se pudo (el cambio igual queda guardado en PostgreSQL).</summary>
    Task<bool> PublishAsync(Station station, CancellationToken ct = default);
}

public class FirebaseDeviceConfigPublisher(FirebaseRtdbClient firebase, ILogger<FirebaseDeviceConfigPublisher> logger)
    : IDeviceConfigPublisher
{
    public async Task<bool> PublishAsync(Station station, CancellationToken ct = default)
    {
        if (!firebase.Enabled) return false;

        try
        {
            var config = DeviceConfig.From(station);
            await firebase.PatchAsync($"stations/{station.Code}/config", new Dictionary<string, object>
            {
                ["autoIrrigation"] = config.AutoIrrigation,
                ["activationThreshold"] = config.ActivationThreshold,
                ["deactivationThreshold"] = config.DeactivationThreshold,
                ["readingIntervalSec"] = config.ReadingIntervalSec,
                ["maxPumpSeconds"] = config.MaxPumpSeconds,
                ["manualPump"] = config.ManualPump,
                ["updatedAt"] = new Dictionary<string, string> { [".sv"] = "timestamp" },
            }, ct);
            return true;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            logger.LogWarning(ex, "No se pudo publicar la configuración de {Code} en Firebase", station.Code);
            return false;
        }
    }
}
