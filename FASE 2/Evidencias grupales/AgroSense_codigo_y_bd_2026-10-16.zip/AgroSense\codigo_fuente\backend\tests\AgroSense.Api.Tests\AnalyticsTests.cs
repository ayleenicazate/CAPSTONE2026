using AgroSense.Api.Metrics;

namespace AgroSense.Api.Tests;

public class AnalyticsTests
{
    private static readonly DateTimeOffset T0 = new(2026, 10, 1, 12, 0, 0, TimeSpan.Zero);

    [Theory]
    [InlineData(25, 50, 1.58)]
    [InlineData(20, 100, 0)]
    [InlineData(30, 60, 1.70)]
    public void Vpd_matches_reference_values(double t, double rh, double expected)
    {
        Assert.Equal(expected, Analytics.VaporPressureDeficit(t, rh), 2);
    }

    [Fact]
    public void DewPoint_equals_temperature_at_full_humidity()
    {
        Assert.Equal(20, Analytics.DewPoint(20, 100), 1);
        Assert.InRange(Analytics.DewPoint(25, 50), 13.5, 14.5);
    }

    [Fact]
    public void Fit_recovers_slope_of_a_line()
    {
        var values = Enumerable.Range(0, 10).Select(h => new TimedValue(T0.AddHours(h), 50 - 2 * h)).ToList();
        var fit = Analytics.Fit(values)!;
        Assert.Equal(-2, fit.Slope, 6);
        Assert.Equal(50, fit.Intercept, 6);
        Assert.Equal(1, fit.RSquared, 6);
    }

    [Fact]
    public void Fit_needs_at_least_three_points()
    {
        Assert.Null(Analytics.Fit([new(T0, 1), new(T0.AddHours(1), 2)]));
    }

    [Fact]
    public void Threshold_crossing_extrapolates_drying_trend()
    {
        // Baja 1 %/h desde 50 %: llega a 30 % 20 horas después del inicio.
        var values = Enumerable.Range(0, 6).Select(h => new TimedValue(T0.AddHours(h), 50 - h)).ToList();
        var crossing = Analytics.EstimateThresholdCrossing(values, 30, T0.AddHours(5));
        Assert.NotNull(crossing);
        Assert.Equal(T0.AddHours(20), crossing.Value, TimeSpan.FromMinutes(1));
    }

    [Fact]
    public void Threshold_crossing_is_null_when_soil_is_not_drying()
    {
        var values = Enumerable.Range(0, 6).Select(h => new TimedValue(T0.AddHours(h), 40 + h)).ToList();
        Assert.Null(Analytics.EstimateThresholdCrossing(values, 30, T0.AddHours(5)));
    }

    [Fact]
    public void Threshold_crossing_is_now_when_already_below()
    {
        var values = Enumerable.Range(0, 6).Select(h => new TimedValue(T0.AddHours(h), 35 - h)).ToList();
        var now = T0.AddHours(5);
        Assert.Equal(now, Analytics.EstimateThresholdCrossing(values, 32, now));
    }

    [Fact]
    public void Bucket_groups_by_hour_in_station_time_zone()
    {
        var values = new[]
        {
            new TimedValue(T0.AddMinutes(5), 10),
            new TimedValue(T0.AddMinutes(55), 20),
            new TimedValue(T0.AddMinutes(65), 30),
        };
        var buckets = Analytics.Bucket(values, TimeSpan.FromHours(1), TimeZoneInfo.Utc);
        Assert.Equal(2, buckets.Count);
        Assert.Equal(15, buckets[0].Average);
        Assert.Equal(10, buckets[0].Min);
        Assert.Equal(20, buckets[0].Max);
        Assert.Equal(T0, buckets[0].Timestamp);
    }

    [Fact]
    public void Daily_profile_forecast_repeats_daily_cycle()
    {
        // 3 días con la temperatura = hora del día.
        var history = Enumerable.Range(0, 72).Select(h => new TimedValue(T0.AddHours(h), T0.AddHours(h).Hour)).ToList();
        var now = T0.AddHours(71);
        var forecast = Analytics.ForecastDailyProfile(history, now, 24, TimeZoneInfo.Utc);
        Assert.Equal(24, forecast.Count);
        Assert.All(forecast, p => Assert.Equal(p.Timestamp.Hour, p.Value, 1));
    }

    [Fact]
    public void Stats_reports_extremes_and_trend()
    {
        var values = Enumerable.Range(0, 24).Select(h => new TimedValue(T0.AddHours(h), h)).ToList();
        var stats = Analytics.Stats(values)!;
        Assert.Equal(0, stats.Min);
        Assert.Equal(23, stats.Max);
        Assert.Equal(T0.AddHours(23), stats.MaxAt);
        Assert.Equal(24, stats.TrendPerDay);
    }

    [Fact]
    public void Rebucket_keeps_true_extremes()
    {
        var points = new[]
        {
            new BucketPoint(T0, 20, 18, 23, 24),
            new BucketPoint(T0.AddMinutes(1), 22, 21, 30, 24),
            new BucketPoint(T0.AddMinutes(20), 10, 9, 11, 24),
        };
        var buckets = Analytics.Rebucket(points, TimeSpan.FromMinutes(15), TimeZoneInfo.Utc);
        Assert.Equal(2, buckets.Count);
        Assert.Equal(21, buckets[0].Average);
        Assert.Equal(18, buckets[0].Min);
        Assert.Equal(30, buckets[0].Max);
        Assert.Equal(48, buckets[0].Count);

        var stats = Analytics.StatsFromBuckets(points)!;
        Assert.Equal(9, stats.Min);
        Assert.Equal(30, stats.Max);
        Assert.Equal(T0.AddMinutes(1), stats.MaxAt);
    }

    [Fact]
    public void Push_key_prefix_matches_firebase_encoding()
    {
        // Clave real generada por el ESP32 el 2026-10-04 (ts 1791140183300 ms en la lectura).
        var prefix = AgroSense.Api.Firebase.FirebaseRtdbClient.PushKeyPrefix(DateTimeOffset.FromUnixTimeMilliseconds(1791140183300));
        Assert.Equal(8, prefix.Length);
        Assert.StartsWith("-P37", prefix);
        // Ordena antes que claves posteriores y después que anteriores.
        Assert.True(string.CompareOrdinal(prefix, "-P37HheiZUCREfOv5EFk") < 0);
        Assert.True(string.CompareOrdinal(prefix, "-P37FOt81rTlekwofm9T") > 0);
    }
}
