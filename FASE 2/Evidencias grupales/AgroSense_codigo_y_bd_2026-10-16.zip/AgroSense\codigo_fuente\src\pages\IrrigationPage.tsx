import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Lock, Power } from 'lucide-react'
import { useEffect, useState } from 'react'

import { MetricCard } from '@/components/MetricCard'
import { DailyBarChart } from '@/components/charts/DailyBarChart'
import { TrendChart } from '@/components/charts/TrendChart'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States'
import { formatDateTime, formatDuration, formatNumber, formatRelative, formatValue } from '@/lib/format'
import { api } from '@/services/api'
import { queryKeys, useIrrigationQuery } from '@/services/queries'
import { useIsAdmin, useStation } from '@/stations/StationContext'
import type { IrrigationConfig, IrrigationData } from '@/types/api'

export function IrrigationPage() {
  const station = useStation()
  const isAdmin = useIsAdmin()
  const queryClient = useQueryClient()
  const { data, isLoading, error, refetch } = useIrrigationQuery(station.id)

  const [form, setForm] = useState<IrrigationConfig | null>(null)
  const [message, setMessage] = useState<{ text: string; tone: 'ok' | 'error' } | null>(null)

  // Inicializa el formulario con lo guardado (sin pisar lo que el usuario está editando).
  useEffect(() => {
    if (data && !form) setForm(data.config)
  }, [data, form])

  function onSaved(updated: IrrigationData, text: string) {
    queryClient.setQueryData(queryKeys.irrigation(station.id), updated)
    void queryClient.invalidateQueries({ queryKey: queryKeys.summary(station.id) })
    void queryClient.invalidateQueries({ queryKey: queryKeys.audit(station.id) })
    setForm(updated.config)
    setMessage({
      text: updated.deviceSynced ? text : `${text} (Firebase no está configurado: el dispositivo no recibirá el cambio).`,
      tone: 'ok',
    })
  }

  const save = useMutation({
    mutationFn: (config: IrrigationConfig) =>
      api.updateIrrigation(station.id, {
        autoIrrigation: config.autoIrrigation,
        activationThreshold: config.activationThreshold,
        deactivationThreshold: config.deactivationThreshold,
        maxPumpSeconds: config.maxPumpSeconds,
      }),
    onSuccess: (updated) => onSaved(updated, 'Configuración guardada y enviada al dispositivo.'),
    onError: (err) => setMessage({ text: err.message, tone: 'error' }),
  })

  const manual = useMutation({
    mutationFn: (on: boolean) => api.manualPump(station.id, on),
    onSuccess: (updated, on) => onSaved(updated, on ? 'Orden de encendido enviada.' : 'Orden de apagado enviada.'),
    onError: (err) => setMessage({ text: err.message, tone: 'error' }),
  })

  if (isLoading) return <LoadingState label="Cargando riego..." />
  if (error || !data || !form) return <ErrorState error={error} onRetry={() => void refetch()} />

  const dirty =
    form.autoIrrigation !== data.config.autoIrrigation ||
    form.activationThreshold !== data.config.activationThreshold ||
    form.deactivationThreshold !== data.config.deactivationThreshold ||
    form.maxPumpSeconds !== data.config.maxPumpSeconds

  const { stats } = data

  return (
    <div className="space-y-4">
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        <MetricCard
          label="Estado de la bomba"
          value={data.pumpOn ? 'Regando' : 'Detenida'}
          badge={data.config.autoIrrigation ? 'Automático' : 'Manual'}
          tone={data.config.autoIrrigation ? 'success' : 'warning'}
        />
        <MetricCard label="Humedad del suelo" value={formatValue(data.currentMoisture, '%')} />
        <MetricCard
          label="Riegos hoy"
          value={`${stats.todayCount}`}
          footer={`${formatNumber(stats.todayMinutes)} min · ${formatNumber(stats.todayLiters)} L estimados`}
        />
        <MetricCard
          label="Últimos 7 días"
          value={`${stats.last7DaysCount} riegos`}
          footer={`${formatNumber(stats.last7DaysLiters)} L estimados`}
        />
        <MetricCard
          label="Próximo riego estimado"
          value={data.estimatedNextIrrigationAt ? formatRelative(data.estimatedNextIrrigationAt) : '—'}
          footer={data.estimatedNextIrrigationAt ? formatDateTime(data.estimatedNextIrrigationAt) : 'Sin tendencia de secado'}
        />
      </section>

      {message ? (
        <p
          className={`rounded-xl px-4 py-3 text-sm ${
            message.tone === 'ok' ? 'bg-emerald-50 text-green-800' : 'bg-red-50 text-red-700'
          }`}
        >
          {message.text}
        </p>
      ) : null}

      <section className="grid gap-4 xl:grid-cols-[minmax(0,2fr)_320px]">
        <Card>
          <h2 className="text-xl font-semibold text-slate-900">Configurar riego</h2>
          {!isAdmin ? (
            <p className="mt-3 rounded-xl bg-slate-100 px-3 py-2 text-sm text-slate-600">
              Tienes acceso de <span className="font-medium">solo lectura</span> en esta estación. Pide a un administrador
              permisos para cambiar la configuración.
            </p>
          ) : null}
          <fieldset disabled={!isAdmin} className="disabled:opacity-70">

          <div className="mt-5 flex items-center justify-between gap-4 rounded-2xl bg-slate-50 p-4">
            <div>
              <p className="font-semibold text-slate-800">Modo automático</p>
              <p className="text-sm text-slate-500">
                La bomba se enciende bajo el umbral de activación y se apaga al alcanzar el de desactivación.
              </p>
            </div>

            <button
              type="button"
              role="switch"
              aria-checked={form.autoIrrigation}
              aria-label="Modo automático"
              onClick={() => setForm({ ...form, autoIrrigation: !form.autoIrrigation })}
              className={`relative h-8 w-14 shrink-0 rounded-full transition ${
                form.autoIrrigation ? 'bg-green-700' : 'bg-slate-300'
              }`}
            >
              <span
                className={`absolute top-1 h-6 w-6 rounded-full bg-white transition ${
                  form.autoIrrigation ? 'left-7' : 'left-1'
                }`}
              />
            </button>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-3">
            <NumberField
              label="Umbral activación (%)"
              value={form.activationThreshold}
              onChange={(value) => setForm({ ...form, activationThreshold: value })}
            />
            <NumberField
              label="Umbral desactivación (%)"
              value={form.deactivationThreshold}
              onChange={(value) => setForm({ ...form, deactivationThreshold: value })}
            />
            <NumberField
              label="Máx. bomba encendida (s)"
              value={form.maxPumpSeconds}
              min={5}
              max={1800}
              onChange={(value) => setForm({ ...form, maxPumpSeconds: value })}
            />
          </div>
          <p className="mt-2 text-xs text-slate-400">
            El tiempo máximo es una protección: el ESP32 apaga la bomba aunque no se alcance el umbral.
          </p>

          <div className="mt-5 flex gap-3">
            <button
              type="button"
              disabled={!dirty || save.isPending}
              onClick={() => save.mutate(form)}
              className="rounded-xl bg-green-700 px-5 py-3 text-sm font-semibold text-white hover:bg-green-800 disabled:opacity-50"
            >
              {save.isPending ? 'Guardando...' : 'Guardar cambios'}
            </button>
            <button
              type="button"
              disabled={!dirty}
              onClick={() => setForm(data.config)}
              className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-600 disabled:opacity-50"
            >
              Restaurar
            </button>
          </div>
          </fieldset>
        </Card>

        <Card className="flex flex-col">
          <h2 className="text-xl font-semibold text-slate-900">Acción manual directa</h2>
          {data.config.autoIrrigation ? (
            <>
              <p className="mt-4 text-sm text-slate-500">
                Para encender la bomba manualmente, primero desactiva el modo automático y guarda los cambios.
              </p>
              <button
                type="button"
                disabled
                className="mt-auto flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-400 disabled:cursor-not-allowed"
              >
                <Lock size={16} />
                Activar riego manual
              </button>
            </>
          ) : (
            <>
              <p className="mt-4 text-sm text-slate-500">
                {data.config.manualPump
                  ? 'Orden de riego manual activa. El dispositivo apagará la bomba al llegar al tiempo máximo.'
                  : 'Envía una orden al dispositivo para encender la bomba.'}
              </p>
              <button
                type="button"
                disabled={manual.isPending || !isAdmin}
                title={isAdmin ? undefined : 'Solo los administradores pueden regar'}
                onClick={() => manual.mutate(!data.config.manualPump)}
                className={`mt-auto flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-white disabled:opacity-60 ${
                  data.config.manualPump ? 'bg-red-600 hover:bg-red-700' : 'bg-sky-600 hover:bg-sky-700'
                }`}
              >
                <Power size={16} />
                {data.config.manualPump ? 'Detener riego manual' : 'Activar riego manual'}
              </button>
            </>
          )}
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <TrendChart
          title="Humedad del suelo y riegos – últimas 48 horas"
          subtitle="Promedio cada 10 minutos; las franjas azules son los riegos"
          data={data.soilMoisture48h.map((p) => ({ timestamp: p.timestamp, value: p.average, min: p.min, max: p.max }))}
          unit="%"
          domain={[0, 100]}
          seriesLabel="Humedad del suelo"
          spans={data.events
            .filter((e) => new Date(e.startedAt).getTime() > Date.now() - 48 * 3600_000)
            .map((e) => ({ from: e.startedAt, to: e.endedAt ?? new Date().toISOString() }))}
          spanLabel="Riego"
          references={[
            { y: data.config.activationThreshold, label: 'Activación', color: '#b45309' },
            { y: data.config.deactivationThreshold, label: 'Desactivación', color: '#15803d' },
          ]}
        />
        <DailyBarChart
          title="Agua estimada por día"
          subtitle="Últimos 14 días, según el caudal configurado de la bomba"
          data={data.daily}
        />
      </section>

      <Card>
        <h2 className="mb-4 text-xl font-semibold text-slate-900">Últimos eventos de riego</h2>
        {data.events.length === 0 ? (
          <EmptyState>Todavía no se registran riegos.</EmptyState>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="text-slate-400">
                <tr className="border-b border-slate-200">
                  <th className="pb-3 font-medium">Inicio</th>
                  <th className="pb-3 font-medium">Duración</th>
                  <th className="pb-3 font-medium">Modo</th>
                  <th className="pb-3 font-medium">Humedad inicio</th>
                  <th className="pb-3 font-medium">Humedad fin</th>
                  <th className="pb-3 font-medium">Agua estimada</th>
                </tr>
              </thead>
              <tbody>
                {data.events.map((event) => (
                  <tr key={event.id} className="border-b border-slate-100">
                    <td className="py-4 text-slate-700">{formatDateTime(event.startedAt)}</td>
                    <td className="py-4 text-slate-700">
                      {event.endedAt ? formatDuration(event.durationSeconds) : <Badge tone="info">En curso</Badge>}
                    </td>
                    <td className="py-4 text-slate-700">{event.mode === 'manual' ? 'Manual' : 'Automático'}</td>
                    <td className="py-4 font-medium text-amber-600">{formatValue(event.startMoisture, '%')}</td>
                    <td className="py-4 font-medium text-green-700">{formatValue(event.endMoisture, '%')}</td>
                    <td className="py-4 text-slate-700">{formatValue(event.waterLiters, 'L', 2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  )
}

function NumberField({
  label,
  value,
  onChange,
  min = 0,
  max = 100,
}: {
  label: string
  value: number
  onChange: (value: number) => void
  min?: number
  max?: number
}) {
  return (
    <label className="space-y-2">
      <span className="text-sm font-medium text-slate-600">{label}</span>
      <input
        value={Number.isNaN(value) ? '' : value}
        onChange={(event) => onChange(event.target.valueAsNumber)}
        type="number"
        min={min}
        max={max}
        className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-green-700"
      />
    </label>
  )
}
