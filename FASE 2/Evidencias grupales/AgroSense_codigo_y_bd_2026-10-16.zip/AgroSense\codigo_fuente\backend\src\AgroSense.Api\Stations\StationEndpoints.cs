using System.Text;
using AgroSense.Api.Auth;
using AgroSense.Api.Data;
using AgroSense.Api.Firebase;
using AgroSense.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Stations;

public static class StationEndpoints
{
    private const string StationItem = "agrosense.station";
    private const string RoleItem = "agrosense.role";

    public static RouteGroupBuilder MapStationEndpoints(this IEndpointRouteBuilder app)
    {
        var root = app.MapGroup("/api/stations").WithTags("Estaciones").RequireAuthorization();

        root.MapGet("/", ListAsync);
        root.MapPost("/join", JoinAsync);

        // Todo lo que cuelga de /{stationId} exige que el usuario sea miembro de la estación.
        var station = root.MapGroup("/{stationId:guid}").AddEndpointFilter(async (context, next) =>
        {
            var http = context.HttpContext;
            var id = Guid.Parse((string)http.Request.RouteValues["stationId"]!);
            var stations = http.RequestServices.GetRequiredService<StationService>();
            var found = await stations.FindMembershipAsync(id, http.User.GetUserId(), http.RequestAborted);
            if (found is null) return Problems.NotFound("Estación no encontrada.");
            http.Items[StationItem] = found.Value.Station;
            http.Items[RoleItem] = found.Value.Role;
            return await next(context);
        });

        station.MapGet("/summary", (HttpContext http, DashboardService dashboard, CancellationToken ct) =>
            dashboard.GetSummaryAsync(Current(http), ct));

        station.MapGet("/sensors", (HttpContext http, DashboardService dashboard, int? hours, CancellationToken ct) =>
            dashboard.GetSensorsAsync(Current(http), hours ?? 6, ct));

        // Vista en vivo: lecturas crudas de los últimos minutos (pensada para consultarse cada 2–3 s).
        station.MapGet("/live", (HttpContext http, DashboardService dashboard, int? minutes, CancellationToken ct) =>
            dashboard.GetLiveAsync(Current(http), minutes ?? 5, ct));

        // Análisis del histórico completo en BigQuery (con caché de 10 min).
        station.MapGet("/analytics", (HttpContext http, AnalyticsService analytics, CancellationToken ct) =>
            analytics.GetAsync(Current(http), ct));

        // Tiempo real (Server-Sent Events): cada lectura nueva se envía apenas se guarda.
        station.MapGet("/stream", StreamAsync);

        station.MapGet("/heatmap", async (HttpContext http, DashboardService dashboard, string? variable, int? days, CancellationToken ct) =>
        {
            var result = await dashboard.GetHeatmapAsync(Current(http), variable ?? "temperature", days ?? 14, ct);
            return result is null ? Problems.BadRequest("Variable no válida.") : Results.Ok(result);
        });

        station.MapGet("/history", async (HttpContext http, DashboardService dashboard, string? variable, string? range, CancellationToken ct) =>
        {
            var result = await dashboard.GetHistoryAsync(Current(http), variable ?? "temperature", range ?? "24h", ct);
            return result is null
                ? Problems.BadRequest("Variable o rango no válido. Rangos: 1h, 24h, 7d, 30d.")
                : Results.Ok(result);
        });

        station.MapGet("/history/export", async (HttpContext http, DashboardService dashboard, string? range, CancellationToken ct) =>
        {
            var current = Current(http);
            var csv = await dashboard.ExportCsvAsync(current, range ?? "7d", ct);
            var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(csv)).ToArray();
            return Results.File(bytes, "text/csv", $"{current.Code}-{range ?? "7d"}.csv");
        });

        station.MapGet("/irrigation", (HttpContext http, DashboardService dashboard, FirebaseRtdbClient firebase, CancellationToken ct) =>
            dashboard.GetIrrigationAsync(Current(http), firebase.Enabled, ct));

        // Cambios sobre el riego y la estación: solo administradores.
        station.MapPut("/irrigation", UpdateIrrigationAsync).AddEndpointFilter(AdminOnly);
        station.MapPost("/irrigation/manual", ManualPumpAsync).AddEndpointFilter(AdminOnly);

        station.MapGet("/settings", (HttpContext http, DashboardService dashboard) => dashboard.ToSettings(Current(http)));
        station.MapPut("/settings", UpdateSettingsAsync).AddEndpointFilter(AdminOnly);

        station.MapStationAdminEndpoints();

        return root;
    }

    internal static Station Current(HttpContext http) => (Station)http.Items[StationItem]!;

    internal static string CurrentRole(HttpContext http) => (string)http.Items[RoleItem]!;

    internal static async Task<User> CurrentUserAsync(HttpContext http, AgroSenseDbContext db, CancellationToken ct) =>
        await db.Users.FirstAsync(u => u.Id == http.User.GetUserId(), ct);

    /// <summary>Filtro: la acción exige rol administrador en la estación.</summary>
    internal static async ValueTask<object?> AdminOnly(EndpointFilterInvocationContext context, EndpointFilterDelegate next) =>
        CurrentRole(context.HttpContext) == StationRoles.Admin
            ? await next(context)
            : Results.Problem("Tu cuenta tiene acceso de solo lectura en esta estación. Pide a un administrador que te dé permisos.",
                statusCode: StatusCodes.Status403Forbidden);

    private static async Task StreamAsync(HttpContext http, Ingestion.LiveBroadcaster broadcaster)
    {
        var station = Current(http);
        var ct = http.RequestAborted;
        http.Response.Headers.ContentType = "text/event-stream";
        http.Response.Headers.CacheControl = "no-cache";
        http.Response.Headers["X-Accel-Buffering"] = "no";

        var (id, reader) = broadcaster.Subscribe(station.Id);
        try
        {
            await http.Response.WriteAsync("event: ready\ndata: {}\n\n", ct);
            await http.Response.Body.FlushAsync(ct);

            var json = http.RequestServices.GetRequiredService<Microsoft.Extensions.Options.IOptions<Microsoft.AspNetCore.Http.Json.JsonOptions>>().Value.SerializerOptions;
            while (!ct.IsCancellationRequested)
            {
                // Comentario cada 15 s para que proxies y navegador no cierren la conexión.
                using var heartbeat = CancellationTokenSource.CreateLinkedTokenSource(ct);
                heartbeat.CancelAfter(TimeSpan.FromSeconds(15));
                try
                {
                    var reading = await reader.ReadAsync(heartbeat.Token);
                    await http.Response.WriteAsync($"data: {System.Text.Json.JsonSerializer.Serialize(reading, json)}\n\n", ct);
                }
                catch (OperationCanceledException) when (!ct.IsCancellationRequested)
                {
                    await http.Response.WriteAsync(": ping\n\n", ct);
                }
                await http.Response.Body.FlushAsync(ct);
            }
        }
        catch (OperationCanceledException)
        {
            // El navegador cerró la conexión.
        }
        catch (System.Threading.Channels.ChannelClosedException)
        {
        }
        finally
        {
            broadcaster.Unsubscribe(station.Id, id);
        }
    }

    private static async Task<IResult> ListAsync(HttpContext http, AgroSenseDbContext db, DashboardService dashboard, CancellationToken ct)
    {
        var userId = http.User.GetUserId();
        var memberships = await db.StationMembers
            .Include(m => m.Station)
            .Where(m => m.UserId == userId)
            .OrderBy(m => m.Station.Name)
            .ToListAsync(ct);
        return Results.Ok(memberships.Select(m => dashboard.ToInfo(m.Station, m.Role)));
    }

    private static async Task<IResult> JoinAsync(
        JoinStationRequest request, HttpContext http, AgroSenseDbContext db, StationService stations, DashboardService dashboard,
        AuditService audit, CancellationToken ct)
    {
        var code = StationService.NormalizeCode(request.Code ?? string.Empty);
        if (!StationService.IsValidCode(code))
            return Problems.BadRequest("El ID de estación solo puede tener minúsculas, números y guiones (3 a 40 caracteres).");

        var user = await db.Users.FirstAsync(u => u.Id == http.User.GetUserId(), ct);
        var station = await stations.GetOrCreateAsync(code, ct);
        var member = await stations.AddMemberAsync(user, station, ct);
        if (member is not null)
        {
            audit.Add(station, user, AuditService.Actions.MemberJoined,
                $"{user.Name} se unió a la estación como {(member.Role == StationRoles.Admin ? "administrador" : "solo lectura")}");
            await db.SaveChangesAsync(ct);
        }
        var role = member?.Role ?? (await stations.FindMembershipAsync(station.Id, user.Id, ct))?.Role;
        return Results.Ok(dashboard.ToInfo(station, role));
    }

    private static async Task<IResult> UpdateIrrigationAsync(
        UpdateIrrigationRequest request, HttpContext http, AgroSenseDbContext db,
        IDeviceConfigPublisher publisher, DashboardService dashboard, AuditService audit, CancellationToken ct)
    {
        if (request.ActivationThreshold is < 0 or > 100 || request.DeactivationThreshold is < 0 or > 100)
            return Problems.BadRequest("Los umbrales deben estar entre 0 y 100 %.");
        if (request.DeactivationThreshold <= request.ActivationThreshold + 5)
            return Problems.BadRequest("El umbral de desactivación debe ser al menos 5 puntos mayor que el de activación.");
        if (request.MaxPumpSeconds is < 5 or > 1800)
            return Problems.BadRequest("El tiempo máximo de bomba debe estar entre 5 y 1800 segundos.");

        var station = Current(http);
        var before = (station.AutoIrrigation, station.ActivationThreshold, station.DeactivationThreshold, station.MaxPumpSeconds);
        station.AutoIrrigation = request.AutoIrrigation;
        station.ActivationThreshold = Math.Round(request.ActivationThreshold, 1);
        station.DeactivationThreshold = Math.Round(request.DeactivationThreshold, 1);
        if (request.MaxPumpSeconds is { } max) station.MaxPumpSeconds = max;
        // Al volver a automático se cancela cualquier encendido manual.
        if (station.AutoIrrigation) station.ManualPump = false;

        var changes = AuditService.Diff(
            ("Riego automático", before.AutoIrrigation, station.AutoIrrigation),
            ("Umbral de activación (%)", before.ActivationThreshold, station.ActivationThreshold),
            ("Umbral de desactivación (%)", before.DeactivationThreshold, station.DeactivationThreshold),
            ("Máximo de bomba (s)", before.MaxPumpSeconds, station.MaxPumpSeconds));
        if (changes.Count > 0)
        {
            audit.Add(station, await CurrentUserAsync(http, db, ct), AuditService.Actions.IrrigationConfig, string.Join(" · ", changes));
        }
        await db.SaveChangesAsync(ct);

        var synced = await publisher.PublishAsync(station, ct);
        return Results.Ok(await dashboard.GetIrrigationAsync(station, synced, ct));
    }

    private static async Task<IResult> ManualPumpAsync(
        ManualPumpRequest request, HttpContext http, AgroSenseDbContext db,
        IDeviceConfigPublisher publisher, DashboardService dashboard, AuditService audit, CancellationToken ct)
    {
        var station = Current(http);
        if (request.On && station.AutoIrrigation)
            return Problems.Conflict("Desactiva el modo automático antes de encender la bomba manualmente.");

        station.ManualPump = request.On;
        audit.Add(station, await CurrentUserAsync(http, db, ct), AuditService.Actions.ManualPump,
            request.On ? "Encendió el riego manual" : "Detuvo el riego manual");
        await db.SaveChangesAsync(ct);

        var synced = await publisher.PublishAsync(station, ct);
        return Results.Ok(await dashboard.GetIrrigationAsync(station, synced, ct));
    }

    private static async Task<IResult> UpdateSettingsAsync(
        UpdateSettingsRequest request, HttpContext http, AgroSenseDbContext db,
        IDeviceConfigPublisher publisher, DashboardService dashboard, AuditService audit, CancellationToken ct)
    {
        var name = request.Name?.Trim() ?? string.Empty;
        if (name.Length is < 2 or > 80) return Problems.BadRequest("El nombre debe tener entre 2 y 80 caracteres.");
        if (request.ReadingIntervalSeconds is < 2 or > 86_400)
            return Problems.BadRequest("El intervalo debe estar entre 2 segundos y 24 horas.");
        if (request.PumpFlowLitersPerMinute is <= 0 or > 100)
            return Problems.BadRequest("El caudal de la bomba debe estar entre 0 y 100 L/min.");

        var station = Current(http);
        var intervalChanged = station.ReadingIntervalSeconds != request.ReadingIntervalSeconds;
        var before = (station.Name, station.Location, station.ReadingIntervalSeconds, station.PumpFlowLitersPerMinute);
        station.Name = name;
        station.Location = request.Location?.Trim() ?? string.Empty;
        station.ReadingIntervalSeconds = request.ReadingIntervalSeconds;
        if (request.PumpFlowLitersPerMinute is { } flow) station.PumpFlowLitersPerMinute = Math.Round(flow, 2);
        var changes = AuditService.Diff(
            ("Nombre", before.Name, station.Name),
            ("Ubicación", before.Location, station.Location),
            ("Intervalo de lectura (s)", before.ReadingIntervalSeconds, station.ReadingIntervalSeconds),
            ("Caudal de la bomba (L/min)", before.PumpFlowLitersPerMinute, station.PumpFlowLitersPerMinute));
        if (changes.Count > 0)
        {
            audit.Add(station, await CurrentUserAsync(http, db, ct), AuditService.Actions.Settings, string.Join(" · ", changes));
        }
        await db.SaveChangesAsync(ct);

        if (intervalChanged) await publisher.PublishAsync(station, ct);
        return Results.Ok(dashboard.ToSettings(station));
    }
}
