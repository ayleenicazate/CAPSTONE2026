using AgroSense.Api.Metrics;

namespace AgroSense.Api.Stations;

public record StationInfoDto(
    Guid Id,
    string Code,
    string Name,
    string Location,
    bool Online,
    DateTimeOffset? LastSeenAt,
    int ReadingIntervalSeconds,
    /// <summary>Rol del usuario actual en la estación: admin o viewer (null en respuestas que no lo calculan).</summary>
    string? Role = null);

public record LatestReadingDto(
    DateTimeOffset Timestamp,
    double? Temperature,
    double? AirHumidity,
    double? SoilMoisture,
    double? Light,
    bool? PumpOn);

public record MetricDto(
    string Key,
    string Label,
    double? Value,
    string Unit,
    MetricStatus? Status,
    string? Hint = null,
    IReadOnlyList<PointDto>? Sparkline = null);

/// <summary>Aviso visible en el panel (sensor sin datos, suelo seco, dispositivo desconectado, etc.).</summary>
public record AlertDto(string Key, string Severity, string Title, string Detail);

public record PointDto(DateTimeOffset Timestamp, double Value);

public record BucketDto(DateTimeOffset Timestamp, double Average, double Min, double Max);

// ---------- Resumen ----------

public record IrrigationStatusDto(
    bool AutoIrrigation,
    bool PumpOn,
    bool ManualPump,
    double? CurrentMoisture,
    double ActivationThreshold,
    double DeactivationThreshold,
    DateTimeOffset? EstimatedNextIrrigationAt);

public record DaySummaryDto(
    int IrrigationCount,
    double PumpMinutes,
    double WaterLiters,
    double? TemperatureMin,
    double? TemperatureMax,
    double? LightHours);

public record SummaryDto(
    StationInfoDto Station,
    LatestReadingDto? Latest,
    IReadOnlyList<MetricDto> Metrics,
    IReadOnlyList<PointDto> SoilMoisture24h,
    IrrigationStatusDto Irrigation,
    DaySummaryDto Today,
    IReadOnlyList<AlertDto> Alerts);

// ---------- En vivo ----------

public record LiveReadingDto(
    DateTimeOffset Timestamp,
    double? Temperature,
    double? AirHumidity,
    double? SoilMoisture,
    double? Light,
    double? AirQuality,
    bool AirQualitySaturated,
    bool? PumpOn);

public record LiveDto(
    bool Online,
    DateTimeOffset? LastSeenAt,
    int ReadingIntervalSeconds,
    LiveReadingDto? Latest,
    IReadOnlyList<LiveReadingDto> Readings);

// ---------- Mapa de calor ----------

public record HeatmapDayDto(DateOnly Date, IReadOnlyList<double?> Hours);

public record HeatmapDto(VariableDto Variable, IReadOnlyList<HeatmapDayDto> Days, double? Min, double? Max);

// ---------- Sensores ----------

public record SensorDto(
    string Id,
    string Name,
    string Model,
    string Description,
    IReadOnlyList<string> Variables,
    bool Reporting,
    string? Reading);

public record VariableSeriesDto(
    string Key,
    string Label,
    string Unit,
    double? Current,
    SeriesStats? Stats,
    IReadOnlyList<PointDto> Series);

public record SpectralBandDto(string Key, string Label, int WavelengthNm, double? Value, string Color);

public record SpectrumDto(DateTimeOffset Timestamp, IReadOnlyList<SpectralBandDto> Bands, double? Total);

public record SpectralPointDto(
    DateTimeOffset Timestamp,
    double? Violet,
    double? Blue,
    double? Green,
    double? Yellow,
    double? Orange,
    double? Red);

public record SensorsDto(
    DateTimeOffset? LastReadingAt,
    int Hours,
    IReadOnlyList<SensorDto> Sensors,
    IReadOnlyList<VariableSeriesDto> Variables,
    SpectrumDto? Spectrum,
    IReadOnlyList<SpectralPointDto> SpectralSeries);

// ---------- Historial ----------

public record VariableDto(string Key, string Label, string Unit);

public record HistoryRecordDto(DateTimeOffset Timestamp, double Value, MetricStatus Status);

public record ForecastPointDto(DateTimeOffset Timestamp, double Value, double? Lower = null, double? Upper = null);

public record HistoryDto(
    VariableDto Variable,
    string Range,
    string Bucket,
    IReadOnlyList<VariableDto> Variables,
    IReadOnlyList<BucketDto> Series,
    IReadOnlyList<ForecastPointDto> Forecast,
    string? ForecastMethod,
    /// <summary>"bigquery-ml" (ARIMA_PLUS con intervalo de confianza) o "local" (perfil horario / tendencia).</summary>
    string? ForecastSource,
    SeriesStats? Stats,
    IReadOnlyList<HistoryRecordDto> Records);

// ---------- Riego ----------

public record IrrigationConfigDto(
    bool AutoIrrigation,
    double ActivationThreshold,
    double DeactivationThreshold,
    int MaxPumpSeconds,
    bool ManualPump);

public record IrrigationEventDto(
    long Id,
    DateTimeOffset StartedAt,
    DateTimeOffset? EndedAt,
    double? DurationSeconds,
    string Mode,
    double? StartMoisture,
    double? EndMoisture,
    double? WaterLiters);

public record IrrigationStatsDto(
    int TodayCount,
    double TodayMinutes,
    double TodayLiters,
    int Last7DaysCount,
    double Last7DaysLiters,
    DateTimeOffset? LastIrrigationAt);

public record IrrigationDayDto(DateOnly Date, int Count, double Minutes, double Liters);

public record IrrigationDto(
    IrrigationConfigDto Config,
    bool PumpOn,
    double? CurrentMoisture,
    DateTimeOffset? EstimatedNextIrrigationAt,
    IrrigationStatsDto Stats,
    IReadOnlyList<IrrigationEventDto> Events,
    bool DeviceSynced,
    IReadOnlyList<IrrigationDayDto> Daily,
    IReadOnlyList<BucketDto> SoilMoisture48h);

public record UpdateIrrigationRequest(
    bool AutoIrrigation,
    double ActivationThreshold,
    double DeactivationThreshold,
    int? MaxPumpSeconds);

public record ManualPumpRequest(bool On);

// ---------- Configuración ----------

public record DeviceInfoDto(
    string Hardware,
    bool Online,
    DateTimeOffset? LastSeenAt,
    string? MacAddress,
    string? IpAddress,
    int? WifiRssi,
    string? Firmware);

public record SettingsDto(
    Guid Id,
    string Code,
    string Name,
    string Location,
    int ReadingIntervalSeconds,
    double PumpFlowLitersPerMinute,
    IrrigationConfigDto Irrigation,
    DeviceInfoDto Device);

public record UpdateSettingsRequest(
    string Name,
    string? Location,
    int ReadingIntervalSeconds,
    double? PumpFlowLitersPerMinute);

public record JoinStationRequest(string Code);

// ---------- Sistema ----------

public record BigQueryStatusDto(
    bool Enabled,
    string? Dataset,
    long ExportedReadings,
    DateTimeOffset? LastExportAt,
    string? LastError,
    DateTimeOffset? LastErrorAt);

public record SystemStatusDto(
    BigQueryStatusDto BigQuery,
    int RawRetentionDays,
    bool FirebaseEnabled,
    int FirebasePollSeconds,
    long StoredReadings,
    long StoredMinutes);
