﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AgroSense.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddReadingMinutesAndExportState : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "export_states",
                columns: table => new
                {
                    Key = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                    LastId = table.Column<long>(type: "bigint", nullable: false),
                    TotalExported = table.Column<long>(type: "bigint", nullable: false),
                    LastExportAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true),
                    LastError = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: true),
                    LastErrorAt = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_export_states", x => x.Key);
                });

            migrationBuilder.CreateTable(
                name: "reading_minutes",
                columns: table => new
                {
                    StationId = table.Column<Guid>(type: "uuid", nullable: false),
                    Minute = table.Column<DateTimeOffset>(type: "timestamp with time zone", nullable: false),
                    Count = table.Column<int>(type: "integer", nullable: false),
                    PumpOnCount = table.Column<int>(type: "integer", nullable: false),
                    TemperatureAvg = table.Column<double>(type: "double precision", nullable: true),
                    TemperatureMin = table.Column<double>(type: "double precision", nullable: true),
                    TemperatureMax = table.Column<double>(type: "double precision", nullable: true),
                    AirHumidityAvg = table.Column<double>(type: "double precision", nullable: true),
                    AirHumidityMin = table.Column<double>(type: "double precision", nullable: true),
                    AirHumidityMax = table.Column<double>(type: "double precision", nullable: true),
                    SoilMoistureAvg = table.Column<double>(type: "double precision", nullable: true),
                    SoilMoistureMin = table.Column<double>(type: "double precision", nullable: true),
                    SoilMoistureMax = table.Column<double>(type: "double precision", nullable: true),
                    LightAvg = table.Column<double>(type: "double precision", nullable: true),
                    LightMin = table.Column<double>(type: "double precision", nullable: true),
                    LightMax = table.Column<double>(type: "double precision", nullable: true),
                    AirQualityAvg = table.Column<double>(type: "double precision", nullable: true),
                    AirQualityMin = table.Column<double>(type: "double precision", nullable: true),
                    AirQualityMax = table.Column<double>(type: "double precision", nullable: true),
                    SpectralVioletAvg = table.Column<double>(type: "double precision", nullable: true),
                    SpectralBlueAvg = table.Column<double>(type: "double precision", nullable: true),
                    SpectralGreenAvg = table.Column<double>(type: "double precision", nullable: true),
                    SpectralYellowAvg = table.Column<double>(type: "double precision", nullable: true),
                    SpectralOrangeAvg = table.Column<double>(type: "double precision", nullable: true),
                    SpectralRedAvg = table.Column<double>(type: "double precision", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_reading_minutes", x => new { x.StationId, x.Minute });
                });

            // Calcula los resúmenes por minuto de las lecturas que ya existían.
            migrationBuilder.Sql("""
                INSERT INTO reading_minutes (
                    "StationId", "Minute", "Count", "PumpOnCount",
                    "TemperatureAvg", "TemperatureMin", "TemperatureMax",
                    "AirHumidityAvg", "AirHumidityMin", "AirHumidityMax",
                    "SoilMoistureAvg", "SoilMoistureMin", "SoilMoistureMax",
                    "LightAvg", "LightMin", "LightMax",
                    "AirQualityAvg", "AirQualityMin", "AirQualityMax",
                    "SpectralVioletAvg", "SpectralBlueAvg", "SpectralGreenAvg",
                    "SpectralYellowAvg", "SpectralOrangeAvg", "SpectralRedAvg")
                SELECT
                    "StationId",
                    date_trunc('minute', "Timestamp" AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',
                    count(*), count(*) FILTER (WHERE "PumpOn"),
                    avg("Temperature"), min("Temperature"), max("Temperature"),
                    avg("AirHumidity"), min("AirHumidity"), max("AirHumidity"),
                    avg("SoilMoisture"), min("SoilMoisture"), max("SoilMoisture"),
                    avg("SpectralTotal"), min("SpectralTotal"), max("SpectralTotal"),
                    avg(CASE WHEN "AirQualityRaw" IS NULL OR "AirQualityRaw" < 4090 THEN "AirQualityVoltage" END),
                    min(CASE WHEN "AirQualityRaw" IS NULL OR "AirQualityRaw" < 4090 THEN "AirQualityVoltage" END),
                    max(CASE WHEN "AirQualityRaw" IS NULL OR "AirQualityRaw" < 4090 THEN "AirQualityVoltage" END),
                    avg("SpectralViolet"), avg("SpectralBlue"), avg("SpectralGreen"),
                    avg("SpectralYellow"), avg("SpectralOrange"), avg("SpectralRed")
                FROM readings
                GROUP BY 1, 2;
                """);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "export_states");

            migrationBuilder.DropTable(
                name: "reading_minutes");
        }
    }
}
