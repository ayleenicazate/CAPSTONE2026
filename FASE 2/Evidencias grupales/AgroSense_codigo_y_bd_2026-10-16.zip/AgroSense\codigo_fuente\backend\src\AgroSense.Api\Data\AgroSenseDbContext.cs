using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Data;

public class AgroSenseDbContext(DbContextOptions<AgroSenseDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Station> Stations => Set<Station>();
    public DbSet<StationMember> StationMembers => Set<StationMember>();
    public DbSet<Reading> Readings => Set<Reading>();
    public DbSet<IrrigationEvent> IrrigationEvents => Set<IrrigationEvent>();
    public DbSet<IngestionCursor> IngestionCursors => Set<IngestionCursor>();
    public DbSet<ReadingMinute> ReadingMinutes => Set<ReadingMinute>();
    public DbSet<ExportState> ExportStates => Set<ExportState>();
    public DbSet<MlForecast> MlForecasts => Set<MlForecast>();
    public DbSet<MlModelRun> MlModelRuns => Set<MlModelRun>();
    public DbSet<AuditEntry> AuditEntries => Set<AuditEntry>();
    public DbSet<AlertState> AlertStates => Set<AlertState>();

    protected override void OnModelCreating(ModelBuilder model)
    {
        model.Entity<User>(e =>
        {
            e.ToTable("users");
            e.HasIndex(u => u.Email).IsUnique();
            e.Property(u => u.Email).HasMaxLength(200);
            e.Property(u => u.Name).HasMaxLength(120);
        });

        model.Entity<Station>(e =>
        {
            e.ToTable("stations");
            e.HasIndex(s => s.Code).IsUnique();
            e.Property(s => s.Code).HasMaxLength(40);
            e.Property(s => s.Name).HasMaxLength(80);
            e.Property(s => s.Location).HasMaxLength(160);
            e.Property(s => s.TelegramChatTitle).HasMaxLength(200);
            e.Property(s => s.TelegramLinkCode).HasMaxLength(16);
        });

        model.Entity<StationMember>(e =>
        {
            e.ToTable("station_members");
            e.HasKey(m => new { m.UserId, m.StationId });
            e.HasOne(m => m.User).WithMany(u => u.Stations).HasForeignKey(m => m.UserId);
            e.HasOne(m => m.Station).WithMany(s => s.Members).HasForeignKey(m => m.StationId);
            e.Property(m => m.Role).HasMaxLength(16);
        });

        model.Entity<Reading>(e =>
        {
            e.ToTable("readings");
            e.HasIndex(r => new { r.StationId, r.Timestamp });
            e.HasIndex(r => new { r.StationId, r.SourceKey }).IsUnique();
            e.Property(r => r.SourceKey).HasMaxLength(64);
            e.Property(r => r.PumpMode).HasMaxLength(16);
        });

        model.Entity<IrrigationEvent>(e =>
        {
            e.ToTable("irrigation_events");
            e.HasIndex(i => new { i.StationId, i.StartedAt });
            e.Property(i => i.Mode).HasMaxLength(16);
        });

        model.Entity<ReadingMinute>(e =>
        {
            e.ToTable("reading_minutes");
            e.HasKey(m => new { m.StationId, m.Minute });
        });

        model.Entity<AuditEntry>(e =>
        {
            e.ToTable("audit_entries");
            e.HasIndex(a => new { a.StationId, a.At });
            e.Property(a => a.UserName).HasMaxLength(120);
            e.Property(a => a.Action).HasMaxLength(48);
            e.Property(a => a.Summary).HasMaxLength(1000);
        });

        model.Entity<AlertState>(e =>
        {
            e.ToTable("alert_states");
            e.HasKey(a => new { a.StationId, a.Key });
            e.Property(a => a.Key).HasMaxLength(48);
        });

        model.Entity<MlForecast>(e =>
        {
            e.ToTable("ml_forecasts");
            e.HasKey(f => new { f.StationId, f.Variable, f.Timestamp });
            e.Property(f => f.Variable).HasMaxLength(32);
            e.Property(f => f.Model).HasMaxLength(200);
        });

        model.Entity<MlModelRun>(e =>
        {
            e.ToTable("ml_model_runs");
            e.HasKey(r => r.Variable);
            e.Property(r => r.Variable).HasMaxLength(32);
            e.Property(r => r.Status).HasMaxLength(32);
            e.Property(r => r.Description).HasMaxLength(500);
            e.Property(r => r.Message).HasMaxLength(2000);
        });

        model.Entity<ExportState>(e =>
        {
            e.ToTable("export_states");
            e.HasKey(s => s.Key);
            e.Property(s => s.Key).HasMaxLength(64);
            e.Property(s => s.LastError).HasMaxLength(2000);
        });

        model.Entity<IngestionCursor>(e =>
        {
            e.ToTable("ingestion_cursors");
            e.HasKey(c => c.StationId);
            e.Property(c => c.LastKey).HasMaxLength(64);
        });
    }
}
