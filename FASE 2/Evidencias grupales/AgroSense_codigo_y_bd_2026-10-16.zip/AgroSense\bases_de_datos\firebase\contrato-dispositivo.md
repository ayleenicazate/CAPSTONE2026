# Contrato de datos ESP32 ↔ Firebase ↔ Backend

Este documento es para quien programa el ESP32. Define **qué escribe y qué lee el dispositivo** en
Firebase Realtime Database, para que el backend de AgroSense lo procese sin cambios.

## Flujo

```
ESP32 ──escribe──► /stations/{id}/readings   (lecturas)
      ──escribe──► /stations/{id}/status     (estado de red)
      ◄──lee────── /stations/{id}/config     (umbrales y órdenes que se envían desde el dashboard)

Backend (C#) lee readings/status cada 10 s, los guarda en PostgreSQL y escribe config.
```

`{id}` es el **ID de la estación**: minúsculas, números y guiones (por ejemplo `agrosense-01`).

## 1. Lecturas — `POST /stations/{id}/readings`

Usar **push** (en Firebase ESP Client: `Firebase.RTDB.pushJSON`), que genera claves cronológicas. Nunca
sobrescribir una lectura existente. Formato acordado (firmware `agrosense-sensors-1.0`):

```json
{
  "ts": { ".sv": "timestamp" },
  "temperature": 24.29,
  "airHumidity": 54.9,
  "soilMoisture": 44.0,
  "soilRaw": 2296,
  "mq135": { "raw": 2100, "adcVoltage": 1.127, "sensorVoltage": 1.69 },
  "spectral": {
    "violet": 79.32, "blue": 82.64, "green": 71.61,
    "yellow": 74.73, "orange": 60.76, "red": 63.19, "total": 432.29
  },
  "pumpOn": false,
  "pumpMode": "auto"
}
```

| Campo          | Tipo   | Unidad / rango | Notas |
|----------------|--------|----------------|-------|
| `ts`           | número | epoch ms       | Usar `{".sv":"timestamp"}` (lo pone el servidor de Firebase; no necesita NTP). También se acepta epoch en segundos. |
| `temperature`  | número | °C             | SHT3x. Si la lectura falla (`NaN`), **omitir el campo**. |
| `airHumidity`  | número | % (0–100)      | SHT3x. |
| `soilMoisture` | número | % (0–100)      | Valor calibrado: `map(raw, SECO, MOJADO, 0, 100)`. |
| `soilRaw`      | entero | ADC 0–4095     | Valor crudo del sensor de suelo (diagnóstico y recalibración). |
| `mq135.raw`    | entero | ADC 0–4095     | **4095 = saturado**: el sistema descarta esas lecturas (calentamiento o falta divisor). |
| `mq135.adcVoltage` | número | V          | Voltaje en el pin del ESP32 (máximo 3,3 V). |
| `mq135.sensorVoltage` | número | V       | Voltaje estimado en la salida AO del sensor (antes del divisor). Es el que muestra el panel. |
| `spectral.*`   | número | µW/cm²         | AS7262: `violet` (450 nm), `blue` (500), `green` (550), `yellow` (570), `orange` (600), `red` (650). `total` es la suma (si no se envía, el backend la calcula). |
| `pumpOn`       | bool   | —              | Estado actual del relé de la bomba. **Obligatorio** para registrar los riegos. |
| `pumpMode`     | texto  | `auto` / `manual` | Qué lógica encendió la bomba. |
| `light`        | número | % (0–100)      | Opcional, solo si se usa un LDR. El hardware actual mide la luz con el AS7262. |

**Reglas importantes**

1. Enviar una lectura cada `config.readingIntervalSec` segundos.
2. **Enviar además una lectura inmediata cada vez que la bomba cambie de estado** (encendido y apagado).
   Con eso el backend calcula la duración de cada riego, la humedad inicial/final y el agua usada.
3. Los campos que no se puedan leer se omiten; no enviar `0` como valor de error.
4. **MQ135:** necesita 24–48 h de calentamiento la primera vez. Si la salida AO supera 3,3 V, usar un divisor
   de voltaje antes del pin del ESP32 (por ejemplo 10 kΩ / 20 kΩ) para no dañarlo.

## 2. Estado — `PUT /stations/{id}/status`

En cada ciclo (o cada minuto):

```json
{
  "lastSeen": { ".sv": "timestamp" },
  "mac": "5C:01:3B:BE:CA:68",
  "ip": "192.168.1.50",
  "rssi": -61,
  "firmware": "agrosense-sensors-1.0",
  "sht3xConnected": true,
  "as7262Connected": true
}
```

El dashboard usa `lastSeen` para saber si la estación está **en línea**: debe haber reportado en los últimos
3 intervalos de lectura.

## 3. Configuración — `GET /stations/{id}/config` (solo lectura para el ESP32)

La escribe el backend cuando el usuario cambia algo en el dashboard. El ESP32 debe leerla en cada ciclo
(o escucharla con un *stream*).

```json
{
  "autoIrrigation": true,
  "activationThreshold": 30,
  "deactivationThreshold": 60,
  "readingIntervalSec": 300,
  "maxPumpSeconds": 120,
  "manualPump": false,
  "updatedAt": 1790000000000
}
```

Si al arrancar no existe, usar estos mismos valores por defecto (el backend la crea automáticamente al
detectar la estación).

## 4. Lógica de riego esperada en el ESP32

```
si autoIrrigation:
    si bomba apagada y soilMoisture < activationThreshold   → encender
    si bomba encendida y (soilMoisture >= deactivationThreshold
                          o encendida hace >= maxPumpSeconds) → apagar
si no (modo manual):
    si manualPump pasa a true                → encender (una sola vez)
    si manualPump pasa a false               → apagar
    si encendida hace >= maxPumpSeconds      → apagar y no volver a encender
                                               hasta que manualPump vuelva a false → true
```

`maxPumpSeconds` es una protección: evita inundar si el sensor de suelo falla o se desconecta.

## 5. Autenticación del ESP32

El dispositivo inicia sesión con **correo y contraseña** de Firebase Authentication (lo que usa la
librería *Firebase ESP Client*):

- `API_KEY`: Web API key del proyecto (Configuración del proyecto → General).
- `DATABASE_URL`: `https://<proyecto>-default-rtdb.firebaseio.com`
- Usuario: `device-<id>@agrosense.local` (por ejemplo `device-agrosense-01@agrosense.local`) y su contraseña.

Las reglas de `firebase/database.rules.json` solo permiten que ese usuario escriba en su propia estación,
que no modifique lecturas existentes y que no escriba en `config`.

## 6. Probar sin el dispositivo

El simulador del repositorio hace exactamente lo descrito arriba:

```bash
cd backend
dotnet run --project tools/AgroSense.Simulator -- --target firebase \
  --db-url https://<proyecto>-default-rtdb.firebaseio.com \
  --api-key <WEB_API_KEY> --email device-agrosense-01@agrosense.local --password <clave>
```
