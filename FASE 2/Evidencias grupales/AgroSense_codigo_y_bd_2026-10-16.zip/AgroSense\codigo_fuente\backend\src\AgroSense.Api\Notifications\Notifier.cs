using AgroSense.Api.Auth;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Notifications;

public class TelegramOptions
{
    public const string Section = "Telegram";
    /// <summary>Token del bot creado con @BotFather. Vacío = Telegram desactivado.</summary>
    public string BotToken { get; set; } = string.Empty;
    public bool Enabled => !string.IsNullOrWhiteSpace(BotToken);
}

public class SmtpOptions
{
    public const string Section = "Smtp";
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 587;
    public string? User { get; set; }
    public string? Password { get; set; }
    public string From { get; set; } = string.Empty;
    public string FromName { get; set; } = "AgroSense";
    public bool Enabled => !string.IsNullOrWhiteSpace(Host) && !string.IsNullOrWhiteSpace(From);
}

/// <summary>Envía un aviso de una estación por todos los canales configurados (Telegram y correo).</summary>
public class Notifier(
    AgroSenseDbContext db,
    TelegramClient telegram,
    IEmailSender email,
    IOptions<SmtpOptions> smtp,
    IOptions<AppOptions> app,
    ILogger<Notifier> logger)
{
    public async Task<NotifyResult> SendAsync(Station station, string title, string body, CancellationToken ct)
    {
        var sentTelegram = false;
        var emails = 0;

        if (telegram.Enabled && station.TelegramChatId is { } chatId)
        {
            try
            {
                await telegram.SendMessageAsync(chatId, $"<b>{Html(title)}</b>\n{Html(body)}\n\n<i>{Html(station.Name)}</i> · {app.Value.FrontendUrl}", ct);
                sentTelegram = true;
            }
            catch (Exception ex) when (!ct.IsCancellationRequested)
            {
                logger.LogWarning(ex, "No se pudo enviar el aviso por Telegram a la estación {Code}", station.Code);
            }
        }

        if (smtp.Value.Enabled)
        {
            var recipients = await db.StationMembers.AsNoTracking()
                .Where(m => m.StationId == station.Id && m.EmailAlerts)
                .Select(m => m.User.Email)
                .ToListAsync(ct);
            foreach (var to in recipients)
            {
                try
                {
                    await email.SendAsync(to, $"AgroSense · {station.Name}: {title}",
                        $"{title}\n\n{body}\n\nEstación: {station.Name}\nPanel: {app.Value.FrontendUrl}\n\n"
                        + "Recibes este correo porque activaste las alertas por correo en Configuración → Notificaciones.", ct);
                    emails++;
                }
                catch (Exception ex) when (!ct.IsCancellationRequested)
                {
                    logger.LogWarning(ex, "No se pudo enviar el aviso por correo a {To}", to);
                }
            }
        }

        return new NotifyResult(sentTelegram, emails);
    }

    private static string Html(string text) =>
        text.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
}

public record NotifyResult(bool Telegram, int Emails)
{
    public bool Any => Telegram || Emails > 0;
}
