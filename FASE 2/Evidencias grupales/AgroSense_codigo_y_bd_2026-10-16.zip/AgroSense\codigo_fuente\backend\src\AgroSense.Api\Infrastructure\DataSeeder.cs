using AgroSense.Api.Data;
using AgroSense.Api.Ingestion;
using AgroSense.Api.Stations;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Infrastructure;

/// <summary>
/// Aplica migraciones, asegura la estación por defecto y (solo si Seed:DemoData = true)
/// crea un usuario demo y un histórico sintético para poder mostrar el dashboard sin el dispositivo.
/// </summary>
public class DataSeeder(
    AgroSenseDbContext db,
    StationService stations,
    IngestionService ingestion,
    IPasswordHasher<User> hasher,
    IOptions<SeedOptions> options,
    TimeProvider clock,
    ILogger<DataSeeder> logger)
{
    private readonly SeedOptions _options = options.Value;

    public async Task RunAsync(CancellationToken ct = default)
    {
        await db.Database.MigrateAsync(ct);
        var station = await stations.GetOrCreateDefaultAsync(ct);

        if (!string.IsNullOrWhiteSpace(_options.DemoUserEmail) && !string.IsNullOrWhiteSpace(_options.DemoUserPassword))
        {
            var email = _options.DemoUserEmail.Trim().ToLowerInvariant();
            var user = await db.Users.FirstOrDefaultAsync(u => u.Email == email, ct);
            if (user is null)
            {
                user = new User { Name = _options.DemoUserName, Email = email };
                user.PasswordHash = hasher.HashPassword(user, _options.DemoUserPassword);
                db.Users.Add(user);
                await db.SaveChangesAsync(ct);
                logger.LogInformation("Usuario demo creado: {Email}", email);
            }
            await stations.AddMemberAsync(user, station, ct, StationRoles.Admin);
        }

        if (_options.DemoData && !await db.Readings.AnyAsync(r => r.StationId == station.Id, ct))
        {
            var readings = DemoDataGenerator.Generate(station, clock.GetUtcNow(), _options.DemoDays);
            foreach (var chunk in readings.Chunk(500))
            {
                await ingestion.IngestAsync(station, chunk, ct);
            }
            logger.LogInformation("Histórico demo generado: {Count} lecturas en {Days} días", readings.Count, _options.DemoDays);
        }
    }
}

/// <summary>
/// Genera datos verosímiles: ciclo diario de temperatura/humedad/luz y secado del suelo
/// con riegos automáticos cuando baja del umbral de activación.
/// </summary>
public static class DemoDataGenerator
{
    public static List<IncomingReading> Generate(Station station, DateTimeOffset now, int days, int stepMinutes = 10)
    {
        var random = new Random(42);
        var result = new List<IncomingReading>();
        var soil = station.DeactivationThreshold - 5;
        var start = now.AddDays(-days);
        // Chile continental: UTC-3/-4. Para la forma de la curva basta con UTC-3.
        const int utcOffsetHours = -3;

        for (var t = start; t <= now; t = t.AddMinutes(stepMinutes))
        {
            var hour = (t.UtcDateTime.Hour + utcOffsetHours + 24) % 24 + t.Minute / 60.0;
            var dayFactor = Math.Sin((hour - 9) / 24 * 2 * Math.PI); // máximo ~15:00
            var dayOfRun = (t - start).TotalDays;
            var warmTrend = Math.Sin(dayOfRun / 5 * Math.PI) * 2;

            var temperature = 19 + 7 * dayFactor + warmTrend + Noise(random, 0.4);
            var humidity = Math.Clamp(62 - 18 * dayFactor + Noise(random, 2), 20, 98);
            var light = hour is > 6.5 and < 20.5
                ? Math.Clamp(85 * Math.Sin((hour - 6.5) / 14 * Math.PI) + Noise(random, 4), 0, 100)
                : Math.Max(0, Noise(random, 1));

            // Secado más rápido con calor y luz.
            soil -= stepMinutes / 60.0 * (0.25 + 0.04 * Math.Max(0, temperature - 15) + 0.003 * light);
            soil += Noise(random, 0.15);

            result.Add(Reading(t, temperature, humidity, soil, light, pumpOn: false));

            if (station.AutoIrrigation && soil < station.ActivationThreshold)
            {
                // Ciclo de riego: bomba encendida ~2 minutos hasta superar el umbral de desactivación.
                var on = t.AddSeconds(20);
                result.Add(Reading(on, temperature, humidity, soil, light, pumpOn: true));
                soil = station.DeactivationThreshold + random.NextDouble() * 4;
                var off = on.AddSeconds(Math.Min(station.MaxPumpSeconds, 90 + random.Next(60)));
                result.Add(Reading(off, temperature, humidity, soil, light, pumpOn: false));
            }
        }
        return result;
    }

    private static IncomingReading Reading(DateTimeOffset t, double temp, double hum, double soil, double light, bool pumpOn)
    {
        // light (0–100) se traduce a un espectro AS7262 aproximado en µW/cm².
        var lux = light * 6 + 20;
        var spectrum = new Spectrum(
            Math.Round(lux * 0.17, 2), Math.Round(lux * 0.19, 2), Math.Round(lux * 0.17, 2),
            Math.Round(lux * 0.18, 2), Math.Round(lux * 0.14, 2), Math.Round(lux * 0.15, 2),
            Math.Round(lux, 2));
        var hour = t.UtcDateTime.Hour;
        var mqVoltage = Math.Round(1.1 + 0.3 * Math.Sin(hour / 24.0 * 2 * Math.PI), 3);
        return new($"demo-{t.ToUnixTimeMilliseconds()}", t,
            Math.Round(temp, 1), Math.Round(hum), Math.Round(Math.Clamp(soil, 0, 100), 1), null, pumpOn, "auto",
            SoilRaw: (int)Math.Round(3400 - soil * 25),
            AirQualityRaw: (int)Math.Round(mqVoltage / 1.5 / 3.3 * 4095),
            AirQualityVoltage: mqVoltage,
            Spectrum: spectrum);
    }

    private static double Noise(Random random, double scale) => (random.NextDouble() * 2 - 1) * scale;
}
