import { Sprout } from 'lucide-react'
import type { ReactNode } from 'react'

export function BrandMark({ tone = 'dark' }: { tone?: 'dark' | 'light' }) {
  const light = tone === 'light'

  return (
    <div className="flex items-center gap-3">
      <div
        className={`flex h-10 w-10 items-center justify-center rounded-xl ${
          light ? 'bg-white text-[#1a7a3a]' : 'bg-[#1a7a3a] text-white'
        }`}
      >
        <Sprout size={20} strokeWidth={2.25} />
      </div>
      <span className={`text-[17px] font-semibold tracking-tight ${light ? 'text-white' : 'text-slate-900'}`}>
        AgroSense
      </span>
    </div>
  )
}

export function AuthCard({ children, wide = false }: { children: ReactNode; wide?: boolean }) {
  return (
    <div
      className={`w-full rounded-2xl bg-white px-8 shadow-[0_18px_50px_rgba(15,23,42,0.08)] ${
        wide ? 'max-w-[440px] py-8' : 'max-w-[420px] py-9'
      }`}
    >
      {children}
    </div>
  )
}

export function AuthShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[#f3f4f6] lg:grid lg:grid-cols-2">
      <aside className="relative min-h-[320px] overflow-hidden text-white lg:min-h-screen">
        <img src="/greenhouse.jpg" alt="" className="absolute inset-0 h-full w-full object-cover object-center" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#1e8a46]/78 via-[#18753b]/72 to-[#145e32]/84" />
        <div className="relative z-10 flex h-full min-h-[320px] flex-col px-8 py-8 sm:px-12 sm:py-10 lg:min-h-screen">
          <BrandMark tone="light" />

          <div className="mt-auto max-w-[460px] pb-10 pt-16 lg:pb-16">
            <h1 className="text-[2rem] font-bold leading-[1.15] tracking-tight sm:text-[2.55rem]">
              Agricultura de precisión al alcance de tu mano.
            </h1>
            <p className="mt-5 max-w-[420px] text-[15px] leading-relaxed text-white/90">
              Monitorea variables agroambientales clave, optimiza el uso de recursos y automatiza sistemas de riego
              inteligente en tiempo real.
            </p>
          </div>

          <div className="flex items-center justify-between border-t border-white/35 pt-4 text-sm text-white/85">
            <span>Proyecto Estación Agroambiental</span>
            <span className="rounded-md border border-white/50 px-2 py-0.5 text-xs tracking-wide">MVP v1.0</span>
          </div>
        </div>
      </aside>

      <main className="flex items-center justify-center px-5 py-10 sm:px-8">{children}</main>
    </div>
  )
}
