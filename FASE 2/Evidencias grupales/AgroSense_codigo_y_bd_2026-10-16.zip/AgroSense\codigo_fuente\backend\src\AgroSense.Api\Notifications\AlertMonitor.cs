using AgroSense.Api.Data;
using AgroSense.Api.Stations;
using Microsoft.EntityFrameworkCore;

namespace AgroSense.Api.Notifications;

/// <summary>
/// Revisa cada minuto las condiciones de alerta de cada estación y avisa por Telegram/correo solo cuando una alerta
/// se activa y cuando se resuelve (no repite el aviso mientras siga activa).
/// </summary>
public class AlertMonitor(
    IServiceScopeFactory scopes,
    TimeProvider clock,
    ILogger<AlertMonitor> logger) : BackgroundService
{
    public const string Offline = "offline";
    public const string SoilDry = "soil-dry";
    public const string PumpLong = "pump-long";

    /// <summary>Minutos que el suelo debe seguir seco antes de avisar (evita avisos por una lectura aislada).</summary>
    public const int SoilDryMinutes = 10;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Da tiempo a que la ingesta se ponga al día después de un reinicio.
        await Task.Delay(TimeSpan.FromMinutes(1), clock, stoppingToken);
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(1));
        do
        {
            try
            {
                await CheckAllAsync(stoppingToken);
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Error revisando alertas");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    public async Task CheckAllAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
        var notifier = scope.ServiceProvider.GetRequiredService<Notifier>();
        var now = clock.GetUtcNow();

        foreach (var station in await db.Stations.Where(s => s.LastSeenAt != null).ToListAsync(ct))
        {
            var states = await db.AlertStates.Where(a => a.StationId == station.Id).ToDictionaryAsync(a => a.Key, ct);
            foreach (var (key, active, title, detail) in await EvaluateAsync(db, station, now, ct))
            {
                if (!states.TryGetValue(key, out var state))
                {
                    state = new AlertState { StationId = station.Id, Key = key, Since = now };
                    db.AlertStates.Add(state);
                    states[key] = state;
                }
                if (state.Active == active) continue;

                state.Active = active;
                state.Since = now;
                if (station.NotificationsEnabled && Enabled(station, key))
                {
                    var result = await notifier.SendAsync(station, active ? $"⚠️ {title}" : $"✅ {title}", detail, ct);
                    if (result.Any) state.NotifiedAt = now;
                }
            }
            await db.SaveChangesAsync(ct);
        }
    }

    private static bool Enabled(Station s, string key) => key switch
    {
        Offline => s.AlertOffline,
        SoilDry => s.AlertSoilDry,
        PumpLong => s.AlertPumpLong,
        _ => false,
    };

    /// <summary>Cada condición con su estado actual y el texto a enviar si cambia.</summary>
    private static async Task<List<(string Key, bool Active, string Title, string Detail)>> EvaluateAsync(
        AgroSenseDbContext db, Station station, DateTimeOffset now, CancellationToken ct)
    {
        var result = new List<(string, bool, string, string)>();

        // 1. Dispositivo sin reportar (5 min o 3 intervalos de lectura, lo que sea mayor).
        var window = TimeSpan.FromSeconds(Math.Max(300, station.ReadingIntervalSeconds * 3));
        var silent = now - station.LastSeenAt!.Value;
        var offline = silent > window;
        result.Add((Offline, offline,
            offline ? "Dispositivo fuera de línea" : "Dispositivo nuevamente en línea",
            offline
                ? $"No llegan datos desde hace {Minutes(silent)}. Revisa la alimentación y el WiFi del ESP32."
                : "El dispositivo volvió a enviar lecturas."));

        // 2. Suelo seco sostenido sin riego.
        var since = now.AddMinutes(-SoilDryMinutes);
        var recent = await db.ReadingMinutes.AsNoTracking()
            .Where(m => m.StationId == station.Id && m.Minute >= since)
            .ToListAsync(ct);
        var soil = recent.Where(m => m.SoilMoistureAvg is not null).ToList();
        var dry = !offline && soil.Count >= SoilDryMinutes - 2
            && soil.All(m => m.SoilMoistureMax < station.ActivationThreshold)
            && recent.All(m => m.PumpOnCount == 0);
        var lastSoil = soil.LastOrDefault()?.SoilMoistureAvg;
        result.Add((SoilDry, dry,
            dry ? "Suelo seco sin riego" : "Humedad del suelo normalizada",
            dry
                ? $"La humedad del suelo lleva {SoilDryMinutes} min bajo el umbral ({lastSoil:0.#} % < {station.ActivationThreshold:0.#} %) y la bomba no se ha encendido."
                    + (station.AutoIrrigation ? " Revisa la bomba y el relé." : " El riego automático está desactivado.")
                : "La humedad del suelo volvió sobre el umbral o comenzó el riego."));

        // 3. Bomba encendida más de lo permitido (el ESP32 debería cortarla en MaxPumpSeconds).
        var open = await db.IrrigationEvents.AsNoTracking()
            .Where(e => e.StationId == station.Id && e.EndedAt == null)
            .OrderByDescending(e => e.StartedAt)
            .FirstOrDefaultAsync(ct);
        var limit = TimeSpan.FromSeconds(station.MaxPumpSeconds + 60);
        var running = open is not null ? now - open.StartedAt : TimeSpan.Zero;
        var tooLong = open is not null && running > limit && !offline;
        result.Add((PumpLong, tooLong,
            tooLong ? "Bomba encendida demasiado tiempo" : "Bomba apagada",
            tooLong
                ? $"La bomba lleva {Minutes(running)} encendida; el máximo configurado es {station.MaxPumpSeconds} s. Revisa el relé y el sensor de suelo."
                : "La bomba se apagó."));

        return result;
    }

    private static string Minutes(TimeSpan span) => span.TotalMinutes < 90
        ? $"{Math.Max(1, (int)span.TotalMinutes)} min"
        : span.TotalHours < 48 ? $"{(int)span.TotalHours} h" : $"{(int)span.TotalDays} días";
}
