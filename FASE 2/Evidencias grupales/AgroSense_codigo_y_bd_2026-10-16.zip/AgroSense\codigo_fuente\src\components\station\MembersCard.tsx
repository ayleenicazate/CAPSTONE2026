import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Users } from 'lucide-react'
import { useState } from 'react'

import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import { formatDateTime } from '@/lib/format'
import { api } from '@/services/api'
import { queryKeys, useMembersQuery } from '@/services/queries'
import { useIsAdmin, useStation } from '@/stations/StationContext'
import type { StationRole } from '@/types/api'

/** Miembros de la estación y su rol. Solo visible para administradores. */
export function MembersCard() {
  const station = useStation()
  const isAdmin = useIsAdmin()
  const queryClient = useQueryClient()
  const { data } = useMembersQuery(station.id, isAdmin)
  const [error, setError] = useState('')

  const refresh = () => {
    setError('')
    void queryClient.invalidateQueries({ queryKey: queryKeys.members(station.id) })
    void queryClient.invalidateQueries({ queryKey: queryKeys.audit(station.id) })
  }
  const changeRole = useMutation({
    mutationFn: ({ userId, role }: { userId: string; role: StationRole }) => api.updateMember(station.id, userId, role),
    onSuccess: refresh,
    onError: (e: Error) => setError(e.message),
  })
  const remove = useMutation({
    mutationFn: (userId: string) => api.removeMember(station.id, userId),
    onSuccess: refresh,
    onError: (e: Error) => setError(e.message),
  })

  if (!isAdmin || !data) return null

  return (
    <Card>
      <h2 className="flex items-center gap-2 text-xl font-semibold text-slate-900">
        <Users size={18} className="text-green-700" />
        Miembros y permisos
      </h2>
      <p className="mt-1 text-sm text-slate-500">
        Los administradores pueden regar y cambiar la configuración; solo lectura puede ver todo pero no modificar.
      </p>
      <ul className="mt-4 divide-y divide-slate-100">
        {data.map((member) => (
          <li key={member.userId} className="flex flex-wrap items-center justify-between gap-3 py-3">
            <div className="min-w-0">
              <p className="truncate font-medium text-slate-800">
                {member.name} {member.isMe ? <Badge tone="neutral">Tú</Badge> : null}
              </p>
              <p className="truncate text-xs text-slate-500">
                {member.email} · desde {formatDateTime(member.joinedAt)}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={member.role}
                disabled={changeRole.isPending}
                onChange={(e) => changeRole.mutate({ userId: member.userId, role: e.target.value as StationRole })}
                className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-sm"
                aria-label={`Rol de ${member.name}`}
              >
                <option value="admin">Administrador</option>
                <option value="viewer">Solo lectura</option>
              </select>
              {!member.isMe ? (
                <button
                  type="button"
                  onClick={() => remove.mutate(member.userId)}
                  disabled={remove.isPending}
                  className="rounded-lg px-2 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50"
                >
                  Quitar
                </button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
      {error ? <p className="mt-2 text-sm text-red-600">{error}</p> : null}
    </Card>
  )
}
