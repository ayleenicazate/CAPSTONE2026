-- AgroSense - Modelos BigQuery ML (ARIMA_PLUS), uno por variable.
-- El backend los reentrena cada 12 h (BigQueryMlService.cs); solo entrena estaciones con suficientes horas de datos.
-- Columnas por modelo:
--   forecast_temperature  -> temperature
--   forecast_airhumidity  -> air_humidity
--   forecast_soilmoisture -> soil_moisture
--   forecast_light        -> light_total
--   forecast_airquality   -> IF(air_quality_saturated, NULL, air_quality_voltage)

CREATE OR REPLACE MODEL `agrosense-a1b2c.agrosense.forecast_temperature`
OPTIONS (
  model_type = 'ARIMA_PLUS',
  time_series_timestamp_col = 'hour',
  time_series_data_col = 'value',
  time_series_id_col = 'station_code',
  data_frequency = 'HOURLY',
  clean_spikes_and_dips = TRUE
) AS
SELECT station_code, TIMESTAMP_TRUNC(ts, HOUR) AS hour, AVG(temperature) AS value
FROM `agrosense-a1b2c.agrosense.readings`
WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 30 DAY) AND temperature IS NOT NULL
GROUP BY station_code, hour;

-- Los otros 4 modelos son iguales cambiando el nombre y la columna (ver tabla de arriba).

-- Prediccion de las proximas 48 h con intervalo del 90 %:
SELECT station_code, forecast_timestamp, forecast_value,
  prediction_interval_lower_bound, prediction_interval_upper_bound
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.forecast_temperature`, STRUCT(48 AS horizon, 0.9 AS confidence_level));
