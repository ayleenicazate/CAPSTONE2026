using AgroSense.Api.Data;
using AgroSense.Api.DataExport;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Metrics;
using Google.Cloud.BigQuery.V2;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Stations;

public record AnalyticsTotalsDto(
    DateTimeOffset? FirstReadingAt,
    DateTimeOffset? LastReadingAt,
    long Readings,
    int DaysWithData,
    int Irrigations,
    double WaterLiters);

public record MonthlyDto(
    string Month,
    long Readings,
    double? TemperatureAvg,
    double? TemperatureMin,
    double? TemperatureMax,
    double? AirHumidityAvg,
    double? SoilMoistureAvg,
    double? LightAvg,
    int Irrigations,
    double WaterLiters);

public record DailyDto(
    DateOnly Day,
    long Readings,
    double? TemperatureAvg,
    double? TemperatureMin,
    double? TemperatureMax,
    double? AirHumidityAvg,
    double? SoilMoistureAvg,
    double? LightAvg,
    int Irrigations,
    double WaterLiters);

public record InsightDto(string Key, string Title, string Value, string Detail, string? Strength = null);

public record MlModelDto(
    string Variable,
    string Label,
    string Status,
    DateTimeOffset? TrainedAt,
    int TrainingPoints,
    string? Description,
    string? Message);

public record LookerDto(string? ReportUrl, string CreateUrl);

public record AnalyticsDto(
    bool Enabled,
    string? Message,
    AnalyticsTotalsDto? Totals,
    IReadOnlyList<MonthlyDto> Monthly,
    IReadOnlyList<DailyDto> Daily,
    IReadOnlyList<InsightDto> Insights,
    IReadOnlyList<MlModelDto> Models,
    LookerDto? Looker,
    long BytesProcessed,
    DateTimeOffset GeneratedAt);

/// <summary>
/// Análisis sobre el histórico completo en BigQuery (PostgreSQL solo guarda 30 días de lecturas crudas).
/// Los resultados se guardan 10 minutos en memoria: BigQuery tarda ~1 s por consulta.
/// </summary>
public class AnalyticsService(
    BigQueryClientFactory bigQuery,
    AgroSenseDbContext db,
    IMemoryCache cache,
    IOptions<AppOptions> app,
    TimeProvider clock,
    ILogger<AnalyticsService> logger)
{
    private const string Zone = BigQueryMlService.Zone;

    public async Task<AnalyticsDto> GetAsync(Station station, CancellationToken ct)
    {
        var models = await GetModelsAsync(station, ct);
        if (!bigQuery.Enabled)
        {
            return new AnalyticsDto(false, "BigQuery no está habilitado en este servidor.", null, [], [], [], models, null, 0, clock.GetUtcNow());
        }

        var key = $"analytics:{station.Id}";
        if (cache.TryGetValue(key, out AnalyticsDto? cached) && cached is not null)
        {
            return cached with { Models = models };
        }

        try
        {
            var result = await QueryAsync(station, ct) with { Models = models };
            cache.Set(key, result, TimeSpan.FromMinutes(10));
            return result;
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            logger.LogWarning(ex, "No se pudo consultar BigQuery para el análisis");
            return new AnalyticsDto(true, $"No se pudo consultar BigQuery: {ex.Message}", null, [], [], [], models, Looker(), 0, clock.GetUtcNow());
        }
    }

    /// <summary>Estado de los modelos de pronóstico para esta estación (cada estación es una serie propia).</summary>
    private async Task<List<MlModelDto>> GetModelsAsync(Station station, CancellationToken ct)
    {
        var runs = await db.MlModelRuns.AsNoTracking().ToDictionaryAsync(r => r.Variable, ct);
        var trained = await db.MlForecasts.AsNoTracking()
            .Where(f => f.StationId == station.Id)
            .GroupBy(f => f.Variable)
            .Select(g => g.OrderBy(f => f.Timestamp).First())
            .ToDictionaryAsync(f => f.Variable, ct);

        List<ReadingMinute>? minutes = null;
        var result = new List<MlModelDto>();
        foreach (var v in BigQueryMlService.Columns.Keys)
        {
            var info = Variables.Find(v)!;
            if (trained.TryGetValue(v, out var f))
            {
                result.Add(new MlModelDto(v, info.Label, "ok", f.TrainedAt, f.TrainingHours, f.Model, null));
                continue;
            }
            if (runs.TryGetValue(v, out var run) && run.Status == "error")
            {
                result.Add(new MlModelDto(v, info.Label, "error", run.TrainedAt, 0, null, run.Message));
                continue;
            }

            // Horas con datos de esta estación en los últimos 30 días (desde los resúmenes por minuto).
            minutes ??= await db.ReadingMinutes.AsNoTracking()
                .Where(m => m.StationId == station.Id && m.Minute >= clock.GetUtcNow().AddDays(-30))
                .ToListAsync(ct);
            var hours = minutes.Where(m => info.Minute(m).Avg is not null)
                .Select(m => m.Minute.UtcTicks / TimeSpan.TicksPerHour).Distinct().Count();
            result.Add(runs.ContainsKey(v)
                ? new MlModelDto(v, info.Label, "insufficient_data", null, hours, null,
                    $"Se necesitan al menos {BigQueryMlService.MinTrainingHours} horas con datos; esta estación tiene {hours}.")
                : new MlModelDto(v, info.Label, "pending", null, hours, null, "Todavía no se ha entrenado."));
        }
        return result;
    }

    private async Task<AnalyticsDto> QueryAsync(Station station, CancellationToken ct)
    {
        var parameters = new[] { new BigQueryParameter("station", BigQueryDbType.String, station.Code) };
        var readings = bigQuery.Table(BigQueryExporter.ReadingsTable);
        var events = bigQuery.Table(BigQueryExporter.EventsTable);
        var daily = bigQuery.Table("daily_summary");

        var totalsTask = bigQuery.QueryAsync($"""
            SELECT MIN(ts) AS first_ts, MAX(ts) AS last_ts, COUNT(*) AS readings,
              COUNT(DISTINCT DATE(ts, '{Zone}')) AS days,
              (SELECT COUNT(*) FROM {events} WHERE station_code = @station) AS irrigations,
              (SELECT IFNULL(SUM(water_liters), 0) FROM {events} WHERE station_code = @station) AS water,
              (SELECT AVG(water_liters) FROM {events} WHERE station_code = @station) AS water_per_irrigation,
              (SELECT AVG(end_moisture - start_moisture) FROM {events} WHERE station_code = @station) AS moisture_gain
            FROM {readings} WHERE station_code = @station
            """, parameters, ct);

        var monthlyTask = bigQuery.QueryAsync($"""
            SELECT FORMAT_DATE('%Y-%m', day) AS month, SUM(readings) AS readings,
              AVG(temperature_avg) AS t_avg, MIN(temperature_min) AS t_min, MAX(temperature_max) AS t_max,
              AVG(air_humidity_avg) AS h_avg, AVG(soil_moisture_avg) AS s_avg, AVG(light_avg) AS l_avg,
              SUM(irrigations) AS irrigations, SUM(water_liters) AS water
            FROM {daily} WHERE station_code = @station
            GROUP BY month ORDER BY month
            """, parameters, ct);

        var dailyTask = bigQuery.QueryAsync($"""
            SELECT day, readings, temperature_avg, temperature_min, temperature_max, air_humidity_avg,
              soil_moisture_avg, light_avg, irrigations, water_liters
            FROM {daily}
            WHERE station_code = @station AND day >= DATE_SUB(CURRENT_DATE('{Zone}'), INTERVAL 90 DAY)
            ORDER BY day
            """, parameters, ct);

        // Secado del suelo por hora (solo horas consecutivas sin riego) y su relación con temperatura y luz.
        var dryingTask = bigQuery.QueryAsync($"""
            WITH h AS (
              SELECT TIMESTAMP_TRUNC(ts, HOUR) AS hour, AVG(soil_moisture) AS soil, AVG(temperature) AS temp,
                AVG(light_total) AS light, LOGICAL_OR(IFNULL(pump_on, FALSE)) AS pump
              FROM {readings} WHERE station_code = @station GROUP BY hour
            ),
            d AS (
              SELECT temp, light, pump,
                LAG(soil) OVER (ORDER BY hour) - soil AS drying,
                LAG(pump) OVER (ORDER BY hour) AS prev_pump,
                TIMESTAMP_DIFF(hour, LAG(hour) OVER (ORDER BY hour), HOUR) AS gap
              FROM h
            )
            SELECT COUNT(*) AS n, AVG(drying) AS avg_drying,
              CORR(temp, drying) AS corr_temp,
              SAFE_DIVIDE(COVAR_SAMP(temp, drying), VAR_SAMP(temp)) AS slope_temp,
              CORR(light, drying) AS corr_light
            FROM d
            WHERE gap = 1 AND NOT pump AND NOT IFNULL(prev_pump, FALSE) AND drying IS NOT NULL AND temp IS NOT NULL
            """, parameters, ct);

        var profileTask = bigQuery.QueryAsync($"""
            WITH x AS (
              SELECT EXTRACT(HOUR FROM DATETIME(ts, '{Zone}')) AS hour_of_day, temperature, light_total
              FROM {readings} WHERE station_code = @station AND temperature IS NOT NULL
            )
            SELECT hour_of_day, AVG(temperature) AS temp, AVG(light_total) AS light,
              (SELECT CORR(light_total, temperature) FROM x) AS corr_light_temp
            FROM x GROUP BY hour_of_day ORDER BY hour_of_day
            """, parameters, ct);

        await Task.WhenAll(totalsTask, monthlyTask, dailyTask, dryingTask, profileTask);

        var (totalsResult, b1) = totalsTask.Result;
        var (monthlyResult, b2) = monthlyTask.Result;
        var (dailyResult, b3) = dailyTask.Result;
        var (dryingResult, b4) = dryingTask.Result;
        var (profileResult, b5) = profileTask.Result;

        var t = totalsResult.First();
        var totals = new AnalyticsTotalsDto(
            Ts(t["first_ts"]), Ts(t["last_ts"]), Long(t["readings"]), (int)Long(t["days"]),
            (int)Long(t["irrigations"]), Math.Round(Dbl(t["water"]) ?? 0, 1));

        var monthly = monthlyResult.Select(r => new MonthlyDto(
            (string)r["month"], Long(r["readings"]), Round(Dbl(r["t_avg"])), Dbl(r["t_min"]), Dbl(r["t_max"]),
            Round(Dbl(r["h_avg"])), Round(Dbl(r["s_avg"])), Round(Dbl(r["l_avg"]), 0),
            (int)Long(r["irrigations"]), Math.Round(Dbl(r["water"]) ?? 0, 1))).ToList();

        var dailyRows = dailyResult.Select(r => new DailyDto(
            DateOnly.FromDateTime((DateTime)r["day"]), Long(r["readings"]),
            Round(Dbl(r["temperature_avg"])), Dbl(r["temperature_min"]), Dbl(r["temperature_max"]),
            Round(Dbl(r["air_humidity_avg"])), Round(Dbl(r["soil_moisture_avg"])), Round(Dbl(r["light_avg"]), 0),
            (int)Long(r["irrigations"]), Math.Round(Dbl(r["water_liters"]) ?? 0, 1))).ToList();

        var insights = BuildInsights(t, dryingResult.First(), profileResult.ToList());

        return new AnalyticsDto(true, null, totals, monthly, dailyRows, insights, [], Looker(),
            b1 + b2 + b3 + b4 + b5, clock.GetUtcNow());
    }

    private static List<InsightDto> BuildInsights(BigQueryRow totals, BigQueryRow drying, List<BigQueryRow> profile)
    {
        var insights = new List<InsightDto>();

        var n = Long(drying["n"]);
        var avgDrying = Dbl(drying["avg_drying"]);
        if (n >= 6 && avgDrying is not null)
        {
            insights.Add(new("drying-rate", "Velocidad de secado del suelo",
                $"{avgDrying.Value:0.##} pts/h",
                $"Entre riegos, la humedad del suelo baja en promedio {avgDrying.Value:0.##} puntos por hora (calculado sobre {n} horas)."));

            var r = Dbl(drying["corr_temp"]);
            var slope = Dbl(drying["slope_temp"]);
            if (r is not null && slope is not null)
            {
                insights.Add(Math.Abs(r.Value) >= 0.2
                    ? new("drying-temperature", "Efecto de la temperatura en el secado",
                        $"{slope.Value:+0.###;-0.###} pts/h por °C",
                        $"Por cada grado adicional, el suelo se seca {Math.Abs(slope.Value):0.###} puntos por hora {(slope.Value >= 0 ? "más rápido" : "más lento")}. Correlación r = {r.Value:0.00}.",
                        Strength(r.Value))
                    : new("drying-temperature", "Efecto de la temperatura en el secado", $"r = {r.Value:0.00}",
                        "Por ahora no se observa una relación clara entre la temperatura y la velocidad de secado.", Strength(r.Value)));
            }
        }
        else
        {
            insights.Add(new("drying-rate", "Velocidad de secado del suelo", "—",
                "Se necesitan más horas continuas de datos entre riegos para estimarla."));
        }

        var withTemp = profile.Where(p => Dbl(p["temp"]) is not null).ToList();
        if (withTemp.Count >= 12)
        {
            var hottest = withTemp.MaxBy(p => Dbl(p["temp"]))!;
            var coldest = withTemp.MinBy(p => Dbl(p["temp"]))!;
            insights.Add(new("daily-cycle", "Ciclo diario de temperatura",
                $"{Long(hottest["hour_of_day"])}:00 / {Long(coldest["hour_of_day"])}:00",
                $"La hora más cálida en promedio es las {Long(hottest["hour_of_day"])}:00 ({Dbl(hottest["temp"]):0.0} °C) y la más fría las {Long(coldest["hour_of_day"])}:00 ({Dbl(coldest["temp"]):0.0} °C)."));

            var corrLightTemp = Dbl(withTemp[0]["corr_light_temp"]);
            if (corrLightTemp is not null)
            {
                insights.Add(new("light-temperature", "Luz y temperatura", $"r = {corrLightTemp.Value:0.00}",
                    Math.Abs(corrLightTemp.Value) >= 0.5
                        ? "La temperatura sube y baja junto con la luz: el sol es el principal factor de calentamiento."
                        : "La temperatura no sigue de cerca a la luz; puede influir la ventilación o el clima exterior.",
                    Strength(corrLightTemp.Value)));
            }
        }

        var waterPerIrrigation = Dbl(totals["water_per_irrigation"]);
        var gain = Dbl(totals["moisture_gain"]);
        if (waterPerIrrigation is not null)
        {
            insights.Add(new("irrigation-efficiency", "Riego promedio",
                $"{waterPerIrrigation.Value:0.##} L",
                gain is null
                    ? "Agua estimada por cada riego."
                    : $"Cada riego usa en promedio {waterPerIrrigation.Value:0.##} L y sube la humedad del suelo {gain.Value:0.#} puntos."));
        }

        return insights;
    }

    private LookerDto Looker()
    {
        // Reporte en blanco: la conexión a BigQuery se agrega a mano (ver pasos en el panel y en docs/bigquery.md).
        // La "Linking API" de Looker Studio exige una plantilla existente, por eso no se usa.
        var report = app.Value.LookerStudioUrl;
        return new LookerDto(string.IsNullOrWhiteSpace(report) ? null : report, "https://lookerstudio.google.com/reporting/create");
    }

    private static string Strength(double r) => Math.Abs(r) switch
    {
        < 0.2 => "débil",
        < 0.5 => "moderada",
        _ => "fuerte",
    };

    private static double? Dbl(object? value) => value switch
    {
        null => null,
        double d when double.IsNaN(d) => null,
        double d => d,
        long l => l,
        _ => Convert.ToDouble(value),
    };

    private static long Long(object? value) => value is null ? 0 : Convert.ToInt64(value);

    private static double? Round(double? value, int digits = 1) => value is null ? null : Math.Round(value.Value, digits);

    private static DateTimeOffset? Ts(object? value) =>
        value is DateTime dt ? new DateTimeOffset(DateTime.SpecifyKind(dt, DateTimeKind.Utc)) : null;
}
