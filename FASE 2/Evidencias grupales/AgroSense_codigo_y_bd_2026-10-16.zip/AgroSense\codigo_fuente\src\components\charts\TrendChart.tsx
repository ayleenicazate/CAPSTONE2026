import type { ReactNode } from 'react'
import {
  Area,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceArea,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/States'
import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatDateTime, formatShortDate, formatTime, formatValue } from '@/lib/format'

export interface TrendPoint {
  timestamp: string
  value?: number
  min?: number
  max?: number
  forecast?: number
  forecastLow?: number
  forecastHigh?: number
}

interface ReferenceMark {
  y: number
  label: string
  color: string
}

interface ShadedSpan {
  from: string
  to: string
  label?: string
}

interface TrendChartProps {
  title: string
  subtitle?: string
  data: TrendPoint[]
  unit: string
  height?: number
  /** Formato del eje X: hora (≤ 24 h) o fecha (varios días). */
  axis?: 'time' | 'date'
  domain?: [number | 'auto', number | 'auto']
  references?: ReferenceMark[]
  /** Intervalos sombreados (por ejemplo, riegos). */
  spans?: ShadedSpan[]
  spanLabel?: string
  seriesLabel?: string
  digits?: number
  actions?: ReactNode
  /** Separación máxima (ms) entre puntos antes de cortar la línea. Si no se indica, se infiere de los datos. */
  maxGapMs?: number
  /** Marcar cada punto (útil en series cortas, como datos diarios). */
  showDots?: boolean
}

export function TrendChart({
  title,
  subtitle,
  data,
  unit,
  height = 260,
  axis = 'time',
  domain = ['auto', 'auto'],
  references = [],
  spans = [],
  spanLabel,
  seriesLabel = 'Valor',
  digits = 1,
  actions,
  maxGapMs,
  showDots = false,
}: TrendChartProps) {
  const points = withGaps(
    data.map((point) => ({
      ...point,
      t: new Date(point.timestamp).getTime(),
      range: point.min !== undefined && point.max !== undefined ? [point.min, point.max] : undefined,
      forecastRange:
        point.forecastLow !== undefined && point.forecastHigh !== undefined ? [point.forecastLow, point.forecastHigh] : undefined,
    })),
    maxGapMs,
  )
  const hasForecast = points.some((point) => point.forecast !== undefined)
  const hasBand = points.some((point) => point.range !== undefined)
  const hasForecastBand = points.some((point) => point.forecastRange !== undefined)
  const showLegend = hasForecast || hasBand || spans.length > 0

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">{title}</h3>
          {subtitle ? <p className="text-sm text-slate-500">{subtitle}</p> : null}
        </div>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500">
          {showLegend ? (
            <>
              <LegendItem swatch={<span className="h-0.5 w-5 rounded" style={{ background: chart.series }} />}>
                {seriesLabel}
              </LegendItem>
              {hasBand ? (
                <LegendItem swatch={<span className="h-3 w-5 rounded-sm" style={{ background: chart.band, opacity: 0.15 }} />}>
                  Rango mín–máx
                </LegendItem>
              ) : null}
              {hasForecast ? (
                <LegendItem swatch={<span className="w-5 border-t-2 border-dashed" style={{ borderColor: chart.forecast }} />}>
                  Estimado
                </LegendItem>
              ) : null}
              {hasForecastBand ? (
                <LegendItem swatch={<span className="h-3 w-5 rounded-sm" style={{ background: chart.forecast, opacity: 0.18 }} />}>
                  Intervalo 90 %
                </LegendItem>
              ) : null}
              {spans.length > 0 ? (
                <LegendItem swatch={<span className="h-3 w-5 rounded-sm" style={{ background: chart.water, opacity: 0.2 }} />}>
                  {spanLabel ?? 'Intervalos'}
                </LegendItem>
              ) : null}
            </>
          ) : null}
          {actions}
        </div>
      </div>
      {points.length === 0 ? (
        <EmptyState>Aún no hay datos en este período.</EmptyState>
      ) : (
        <div style={{ height }}>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={points} margin={{ top: 8, right: 12, left: -4, bottom: 0 }}>
              <CartesianGrid stroke={chart.grid} strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="t"
                type="number"
                scale="time"
                domain={['dataMin', 'dataMax']}
                axisLine={false}
                tickLine={false}
                minTickGap={36}
                tick={{ fill: chart.axis, fontSize: 12 }}
                tickFormatter={(t: number) => {
                  const iso = new Date(t).toISOString()
                  return axis === 'time' ? formatTime(iso) : formatShortDate(iso)
                }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                width={64}
                domain={domain}
                tick={{ fill: chart.axis, fontSize: 12 }}
                tickFormatter={(value: number) => formatValue(value, unit, digits)}
              />
              <Tooltip
                {...tooltipStyle}
                cursor={{ stroke: chart.axis, strokeDasharray: '3 3' }}
                labelFormatter={(t) => formatDateTime(new Date(Number(t)).toISOString())}
                formatter={(value: number | number[], name) => {
                  if (Array.isArray(value)) {
                    return [
                      `${formatValue(value[0], unit, digits)} – ${formatValue(value[1], unit, digits)}`,
                      name === 'forecastRange' ? 'Intervalo 90 %' : 'Mín–máx',
                    ]
                  }
                  return [formatValue(value, unit, digits), name === 'forecast' ? 'Estimado' : seriesLabel]
                }}
              />
              {spans.map((span) => (
                <ReferenceArea
                  key={span.from}
                  x1={new Date(span.from).getTime()}
                  x2={new Date(span.to).getTime()}
                  fill={chart.water}
                  fillOpacity={0.15}
                  strokeOpacity={0}
                  ifOverflow="extendDomain"
                />
              ))}
              {references.map((ref) => (
                <ReferenceLine
                  key={ref.label}
                  y={ref.y}
                  stroke={ref.color}
                  strokeDasharray="4 4"
                  label={{ value: ref.label, position: 'insideTopRight', fill: ref.color, fontSize: 11 }}
                />
              ))}
              {hasBand ? (
                <Area
                  type="monotone"
                  dataKey="range"
                  stroke="none"
                  fill={chart.band}
                  fillOpacity={0.12}
                  isAnimationActive={false}
                />
              ) : null}
              {hasForecastBand ? (
                <Area
                  type="monotone"
                  dataKey="forecastRange"
                  stroke="none"
                  fill={chart.forecast}
                  fillOpacity={0.15}
                  isAnimationActive={false}
                />
              ) : null}
              <Line
                type="monotone"
                dataKey="value"
                stroke={chart.series}
                strokeWidth={2}
                dot={showDots ? { r: 3, fill: chart.series, stroke: '#fff', strokeWidth: 1 } : false}
                activeDot={{ r: 5, fill: chart.series, stroke: '#fff', strokeWidth: 2 }}
                isAnimationActive={false}
              />
              {hasForecast ? (
                <Line
                  type="monotone"
                  dataKey="forecast"
                  stroke={chart.forecast}
                  strokeWidth={2}
                  strokeDasharray="6 4"
                  dot={false}
                  connectNulls
                  isAnimationActive={false}
                />
              ) : null}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}
    </Card>
  )
}

type PlotPoint = TrendPoint & { t: number; range?: number[]; forecastRange?: number[] }

/**
 * Inserta un punto vacío donde faltan datos (más de 3 veces el espaciado típico), para que la
 * línea se corte en vez de unir con una recta períodos sin mediciones.
 */
function withGaps(points: PlotPoint[], maxGapMs?: number): PlotPoint[] {
  const measured = points.filter((p) => p.value !== undefined)
  let typical: number
  let limit: number
  if (maxGapMs) {
    typical = maxGapMs / 3
    limit = maxGapMs
  } else {
    if (measured.length < 3) return points
    const steps = measured.slice(1).map((p, i) => p.t - measured[i].t).sort((a, b) => a - b)
    typical = steps[Math.floor(steps.length / 2)]
    if (!typical) return points
    limit = typical * 3
  }

  const result: PlotPoint[] = []
  for (let i = 0; i < points.length; i++) {
    const previous = points[i - 1]
    const current = points[i]
    if (previous && previous.value !== undefined && current.value !== undefined && current.t - previous.t > limit) {
      result.push({ timestamp: new Date(previous.t + typical).toISOString(), t: previous.t + typical })
    }
    result.push(current)
  }
  return result
}

function LegendItem({ swatch, children }: { swatch: ReactNode; children: ReactNode }) {
  return (
    <span className="flex items-center gap-1.5">
      {swatch}
      {children}
    </span>
  )
}
