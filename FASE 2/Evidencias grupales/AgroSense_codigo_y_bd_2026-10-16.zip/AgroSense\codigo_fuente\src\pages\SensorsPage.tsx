import { useState } from 'react'
import { Link } from 'react-router-dom'

import { MetricCard } from '@/components/MetricCard'
import { SpectralSeriesChart } from '@/components/charts/SpectralSeriesChart'
import { SpectrumChart } from '@/components/charts/SpectrumChart'
import { TrendChart } from '@/components/charts/TrendChart'
import { Card } from '@/components/ui/Card'
import { ErrorState, LoadingState } from '@/components/ui/States'
import { formatDateTime, formatValue } from '@/lib/format'
import { useSensorsQuery } from '@/services/queries'
import { useStation } from '@/stations/StationContext'
import type { VariableSeries } from '@/types/api'

const HOUR_OPTIONS = [6, 12, 24, 48]

export function SensorsPage() {
  const station = useStation()
  const [hours, setHours] = useState(6)
  const [selectedId, setSelectedId] = useState('sht3x')
  const { data, isLoading, error, refetch } = useSensorsQuery(station.id, hours)

  if (isLoading && !data) return <LoadingState label="Cargando sensores..." />
  if (error || !data) return <ErrorState error={error} onRetry={() => void refetch()} />

  const selected = data.sensors.find((sensor) => sensor.id === selectedId) ?? data.sensors[0]
  const variables = data.variables.filter((variable) => selected.variables.includes(variable.key))

  return (
    <section className="grid gap-4 xl:grid-cols-[320px_minmax(0,1fr)]">
      <Card>
        <h2 className="mb-4 text-xl font-semibold text-slate-900">Sensores conectados</h2>
        <div className="space-y-3">
          {data.sensors.map((sensor) => (
            <button
              key={sensor.id}
              type="button"
              onClick={() => setSelectedId(sensor.id)}
              className={`w-full rounded-2xl border p-4 text-left transition ${
                sensor.id === selected.id
                  ? 'border-green-700 bg-emerald-50'
                  : 'border-transparent bg-slate-50 hover:border-slate-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <span
                  className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${sensor.reporting ? 'bg-green-600' : 'bg-slate-300'}`}
                  title={sensor.reporting ? 'Reportando' : 'Sin datos recientes'}
                />
                <div>
                  <p className="font-semibold text-slate-800">{sensor.name}</p>
                  <p className="text-sm text-slate-500">{sensor.model}</p>
                  <p className="mt-1 text-sm text-slate-400">Lectura: {sensor.reading ?? 'sin datos'}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </Card>

      <div className="space-y-4">
        <Card>
          <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
            <div>
              <h2 className="text-xl font-semibold text-slate-900">
                {selected.name} <span className="font-normal text-slate-400">({selected.model})</span>
              </h2>
              <p className="mt-1 text-sm text-slate-500">{selected.description}</p>
              <p className="mt-1 text-sm text-slate-400">Última lectura: {formatDateTime(data.lastReadingAt)}</p>
            </div>
            <div className="flex gap-2">
              {HOUR_OPTIONS.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setHours(option)}
                  className={`rounded-lg px-3 py-1.5 text-sm font-medium ${
                    hours === option
                      ? 'border border-green-700 bg-emerald-50 text-green-800'
                      : 'border border-slate-200 text-slate-500'
                  }`}
                >
                  {option} h
                </button>
              ))}
            </div>
          </div>
        </Card>

        {selected.id === 'pump' ? (
          <Card className="text-sm text-slate-600">
            La bomba está <span className="font-semibold">{selected.reading?.toLowerCase() ?? 'sin datos'}</span>. Los
            ciclos de riego, su duración y el agua utilizada se revisan en{' '}
            <Link to="/riego" className="font-semibold text-green-700 underline">
              Riego
            </Link>
            .
          </Card>
        ) : (
          <>
            {selected.id === 'mq135' && selected.reading?.startsWith('Saturado') ? (
              <Card className="border-amber-200 bg-amber-50 text-sm text-amber-800">
                El MQ135 está entregando el valor máximo del ADC (4095), así que sus lecturas no son válidas todavía.
                Necesita 24–48 h de calentamiento la primera vez; si sigue saturado, la salida AO necesita un divisor de
                voltaje (el ESP32 admite máximo 3,3 V). Mientras tanto, estas lecturas no se grafican.
              </Card>
            ) : null}
            {selected.id === 'as7262' && data.spectrum ? <SpectrumChart spectrum={data.spectrum} /> : null}
            {selected.id === 'as7262' ? <SpectralSeriesChart data={data.spectralSeries} hours={hours} /> : null}
            {variables.map((variable) => (
              <VariableDetail key={variable.key} variable={variable} hours={hours} />
            ))}
          </>
        )}
      </div>
    </section>
  )
}

function VariableDetail({ variable, hours }: { variable: VariableSeries; hours: number }) {
  const { stats, unit } = variable
  const digits = unit === 'V' ? 2 : unit === 'µW/cm²' ? 0 : 1
  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label={`${variable.label} actual`} value={formatValue(variable.current, unit, digits)} />
        <MetricCard label="Promedio" value={formatValue(stats?.average, unit, digits)} />
        <MetricCard
          label="Mínimo"
          value={formatValue(stats?.min, unit, digits)}
          footer={stats ? formatDateTime(stats.minAt) : null}
        />
        <MetricCard
          label="Máximo"
          value={formatValue(stats?.max, unit, digits)}
          footer={stats ? formatDateTime(stats.maxAt) : null}
        />
      </div>
      <TrendChart
        title={`${variable.label} – últimas ${hours} horas`}
        data={variable.series}
        unit={unit}
        height={230}
        domain={unit === '%' ? [0, 100] : ['auto', 'auto']}
        seriesLabel={variable.label}
        digits={digits}
        axis={hours > 24 ? 'date' : 'time'}
      />
    </div>
  )
}
