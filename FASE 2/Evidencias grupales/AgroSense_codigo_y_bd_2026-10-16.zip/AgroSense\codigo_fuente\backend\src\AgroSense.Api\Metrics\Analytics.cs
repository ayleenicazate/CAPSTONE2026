using AgroSense.Api.Data;

namespace AgroSense.Api.Metrics;

public record TimedValue(DateTimeOffset Timestamp, double Value);

public record BucketPoint(DateTimeOffset Timestamp, double Average, double Min, double Max, int Count);

public record SeriesStats(double Average, double Min, DateTimeOffset MinAt, double Max, DateTimeOffset MaxAt, int Count, double? TrendPerDay);

public record LinearFit(double Slope, double Intercept, double RSquared);

/// <summary>Cálculos agronómicos y estadísticos usados por el dashboard.</summary>
public static class Analytics
{
    /// <summary>Presión de vapor de saturación (kPa), ecuación de Tetens.</summary>
    public static double SaturationVaporPressure(double temperatureC) =>
        0.6108 * Math.Exp(17.27 * temperatureC / (temperatureC + 237.3));

    /// <summary>
    /// Déficit de presión de vapor (VPD, kPa). Indica la "demanda de agua" del aire sobre la planta:
    /// ~0.4–0.8 baja, 0.8–1.2 óptima para la mayoría de cultivos, &gt;1.6 estrés hídrico.
    /// </summary>
    public static double VaporPressureDeficit(double temperatureC, double relativeHumidity) =>
        Math.Round(SaturationVaporPressure(temperatureC) * (1 - relativeHumidity / 100.0), 2);

    /// <summary>Punto de rocío (°C), aproximación de Magnus.</summary>
    public static double DewPoint(double temperatureC, double relativeHumidity)
    {
        const double a = 17.27, b = 237.7;
        var rh = Math.Clamp(relativeHumidity, 1, 100);
        var gamma = a * temperatureC / (b + temperatureC) + Math.Log(rh / 100.0);
        return Math.Round(b * gamma / (a - gamma), 1);
    }

    public static MetricStatus EvaluateVpd(double vpd) => vpd switch
    {
        < 0.4 => Variables.Status("Riesgo hongos", Tone.Info),
        < 0.8 => Variables.Status("Baja", Tone.Normal),
        <= 1.2 => Variables.Status("Óptima", Tone.Success),
        <= 1.6 => Variables.Status("Alta", Tone.Warning),
        _ => Variables.Status("Estrés hídrico", Tone.Warning),
    };

    /// <summary>Agrupa valores en intervalos de tamaño fijo alineados a la zona horaria indicada.</summary>
    public static List<BucketPoint> Bucket(IEnumerable<TimedValue> values, TimeSpan size, TimeZoneInfo zone)
    {
        return values
            .GroupBy(v => BucketStart(v.Timestamp, size, zone))
            .OrderBy(g => g.Key)
            .Select(g => new BucketPoint(
                g.Key,
                Math.Round(g.Average(v => v.Value), 2),
                g.Min(v => v.Value),
                g.Max(v => v.Value),
                g.Count()))
            .ToList();
    }

    /// <summary>Convierte resúmenes por minuto de una variable en puntos (solo minutos con dato).</summary>
    public static List<BucketPoint> FromMinutes(IEnumerable<ReadingMinute> minutes, VariableInfo variable) =>
        minutes
            .Select(m => (m.Minute, Stat: variable.Minute(m), m.Count))
            .Where(x => x.Stat.Avg is not null)
            .Select(x => new BucketPoint(x.Minute, x.Stat.Avg!.Value, x.Stat.Min ?? x.Stat.Avg.Value, x.Stat.Max ?? x.Stat.Avg.Value, x.Count))
            .ToList();

    /// <summary>Agrupa puntos ya resumidos en intervalos mayores (promedio de promedios, mínimo de mínimos, máximo de máximos).</summary>
    public static List<BucketPoint> Rebucket(IEnumerable<BucketPoint> points, TimeSpan size, TimeZoneInfo zone) =>
        points
            .GroupBy(p => BucketStart(p.Timestamp, size, zone))
            .OrderBy(g => g.Key)
            .Select(g => new BucketPoint(
                g.Key,
                Math.Round(g.Average(p => p.Average), 3),
                g.Min(p => p.Min),
                g.Max(p => p.Max),
                g.Sum(p => p.Count)))
            .ToList();

    /// <summary>Estadísticas sobre puntos resumidos: extremos reales (mín/máx de cada minuto) y tendencia sobre los promedios.</summary>
    public static SeriesStats? StatsFromBuckets(IReadOnlyList<BucketPoint> points)
    {
        if (points.Count == 0) return null;
        var min = points.MinBy(p => p.Min)!;
        var max = points.MaxBy(p => p.Max)!;
        var fit = Fit(points.Select(p => new TimedValue(p.Timestamp, p.Average)).ToList());
        return new SeriesStats(
            Math.Round(points.Average(p => p.Average), 2),
            min.Min, min.Timestamp,
            max.Max, max.Timestamp,
            points.Sum(p => p.Count),
            fit is null ? null : Math.Round(fit.Slope * 24, 2));
    }

    public static DateTimeOffset BucketStart(DateTimeOffset timestamp, TimeSpan size, TimeZoneInfo zone)
    {
        var local = TimeZoneInfo.ConvertTime(timestamp, zone);
        var midnight = new DateTimeOffset(local.Date, local.Offset);
        var sinceMidnight = local - midnight;
        var start = midnight + TimeSpan.FromTicks(sinceMidnight.Ticks / size.Ticks * size.Ticks);
        return start.ToUniversalTime();
    }

    public static SeriesStats? Stats(IReadOnlyList<TimedValue> values)
    {
        if (values.Count == 0) return null;
        var min = values.MinBy(v => v.Value)!;
        var max = values.MaxBy(v => v.Value)!;
        var fit = Fit(values);
        return new SeriesStats(
            Math.Round(values.Average(v => v.Value), 2),
            min.Value, min.Timestamp,
            max.Value, max.Timestamp,
            values.Count,
            fit is null ? null : Math.Round(fit.Slope * 24, 2));
    }

    /// <summary>Regresión lineal por mínimos cuadrados; x en horas desde el primer punto.</summary>
    public static LinearFit? Fit(IReadOnlyList<TimedValue> values)
    {
        if (values.Count < 3) return null;
        var origin = values[0].Timestamp;
        var xs = values.Select(v => (v.Timestamp - origin).TotalHours).ToArray();
        var ys = values.Select(v => v.Value).ToArray();
        var meanX = xs.Average();
        var meanY = ys.Average();

        double sxx = 0, sxy = 0, syy = 0;
        for (var i = 0; i < xs.Length; i++)
        {
            sxx += (xs[i] - meanX) * (xs[i] - meanX);
            sxy += (xs[i] - meanX) * (ys[i] - meanY);
            syy += (ys[i] - meanY) * (ys[i] - meanY);
        }
        if (sxx < 1e-9) return null;

        var slope = sxy / sxx;
        var intercept = meanY - slope * meanX;
        var r2 = syy < 1e-9 ? 1 : sxy * sxy / (sxx * syy);
        return new LinearFit(slope, intercept, r2);
    }

    /// <summary>
    /// Estima cuándo la humedad del suelo bajará del umbral, usando la tendencia de secado
    /// desde el último riego (regresión lineal). Devuelve null si no está secándose o faltan datos.
    /// </summary>
    public static DateTimeOffset? EstimateThresholdCrossing(IReadOnlyList<TimedValue> soilSinceLastIrrigation, double threshold, DateTimeOffset now)
    {
        var fit = Fit(soilSinceLastIrrigation);
        if (fit is null || fit.Slope >= -0.01) return null;

        var current = soilSinceLastIrrigation[^1].Value;
        if (current <= threshold) return now;

        var origin = soilSinceLastIrrigation[0].Timestamp;
        var hoursFromOrigin = (threshold - fit.Intercept) / fit.Slope;
        var crossing = origin.AddHours(hoursFromOrigin);
        if (crossing < now) return now;
        // Más allá de 14 días la extrapolación no es confiable.
        return crossing > now.AddDays(14) ? null : crossing;
    }

    /// <summary>
    /// Pronóstico de las próximas horas para variables con ciclo diario (temperatura, humedad, luz):
    /// perfil horario promedio de los últimos días, ajustado por la diferencia entre el nivel reciente
    /// y lo que el perfil esperaba para esas mismas horas.
    /// </summary>
    public static List<TimedValue> ForecastDailyProfile(
        IReadOnlyList<TimedValue> history, DateTimeOffset now, int hours, TimeZoneInfo zone, double? min = null, double? max = null)
    {
        if (history.Count < 24) return [];

        var profile = history
            .GroupBy(v => TimeZoneInfo.ConvertTime(v.Timestamp, zone).Hour)
            .ToDictionary(g => g.Key, g => g.Average(v => v.Value));
        if (profile.Count < 12) return [];

        double ProfileAt(int hour)
        {
            for (var offset = 0; offset < 12; offset++)
            {
                if (profile.TryGetValue((hour + offset) % 24, out var v)) return v;
                if (profile.TryGetValue((hour - offset + 24) % 24, out v)) return v;
            }
            return profile.Values.Average();
        }

        var recent = history.Where(v => v.Timestamp >= now.AddHours(-3)).ToList();
        var bias = recent.Count == 0
            ? 0
            : recent.Average(v => v.Value - ProfileAt(TimeZoneInfo.ConvertTime(v.Timestamp, zone).Hour));

        var start = BucketStart(now, TimeSpan.FromHours(1), zone).AddHours(1);
        var result = new List<TimedValue>(hours);
        for (var h = 0; h < hours; h++)
        {
            var at = start.AddHours(h);
            // El sesgo reciente se desvanece a lo largo de 12 horas.
            var decay = Math.Max(0, 1 - h / 12.0);
            var value = ProfileAt(TimeZoneInfo.ConvertTime(at, zone).Hour) + bias * decay;
            if (min is not null) value = Math.Max(min.Value, value);
            if (max is not null) value = Math.Min(max.Value, value);
            result.Add(new TimedValue(at, Math.Round(value, 2)));
        }
        return result;
    }

    /// <summary>Pronóstico lineal (para humedad del suelo, que no tiene ciclo diario sino tendencia de secado).</summary>
    public static List<TimedValue> ForecastLinear(IReadOnlyList<TimedValue> recent, DateTimeOffset now, int hours, TimeZoneInfo zone, double min, double max)
    {
        var fit = Fit(recent);
        if (fit is null) return [];
        var origin = recent[0].Timestamp;
        var start = BucketStart(now, TimeSpan.FromHours(1), zone).AddHours(1);
        return Enumerable.Range(0, hours)
            .Select(h =>
            {
                var at = start.AddHours(h);
                var value = fit.Intercept + fit.Slope * (at - origin).TotalHours;
                return new TimedValue(at, Math.Round(Math.Clamp(value, min, max), 2));
            })
            .ToList();
    }
}
