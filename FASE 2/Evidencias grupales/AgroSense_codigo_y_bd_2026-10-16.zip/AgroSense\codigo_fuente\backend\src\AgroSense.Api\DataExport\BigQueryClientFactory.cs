using AgroSense.Api.Infrastructure;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.BigQuery.V2;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.DataExport;

/// <summary>Crea (una sola vez) el cliente de BigQuery compartido por la exportación, BigQuery ML y el análisis.</summary>
public class BigQueryClientFactory(IOptions<BigQueryOptions> options)
{
    private readonly BigQueryOptions _options = options.Value;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private BigQueryClient? _client;

    public bool Enabled => _options.Enabled;
    public BigQueryOptions Options => _options;

    /// <summary>Nombre completo de una tabla o vista: `proyecto.dataset.nombre`.</summary>
    public string Table(string name) => $"`{_options.ProjectId}.{_options.Dataset}.{name}`";

    public async Task<BigQueryClient> GetAsync(CancellationToken ct = default)
    {
        if (_client is not null) return _client;
        if (!_options.Enabled) throw new InvalidOperationException("BigQuery no está habilitado (BigQuery:Enabled).");
        if (string.IsNullOrWhiteSpace(_options.ProjectId)) throw new InvalidOperationException("Falta BigQuery:ProjectId.");

        await _lock.WaitAsync(ct);
        try
        {
            if (_client is not null) return _client;
            var credential = string.IsNullOrWhiteSpace(_options.ServiceAccountPath)
                ? await GoogleCredential.GetApplicationDefaultAsync(ct)
                : CredentialFactory.FromFile<ServiceAccountCredential>(_options.ServiceAccountPath).ToGoogleCredential();
            _client = await BigQueryClient.CreateAsync(_options.ProjectId, credential);
            return _client;
        }
        finally
        {
            _lock.Release();
        }
    }

    /// <summary>Ejecuta una consulta y espera a que termine (sin límite de tiempo: entrenar un modelo puede tardar minutos).</summary>
    public async Task<(BigQueryResults Results, long BytesProcessed)> QueryAsync(
        string sql, IEnumerable<BigQueryParameter>? parameters = null, CancellationToken ct = default)
    {
        var client = await GetAsync(ct);
        var job = await client.CreateQueryJobAsync(sql, parameters?.ToList() ?? [],
            new QueryOptions { DefaultDataset = client.GetDatasetReference(_options.Dataset) }, ct);
        job = await job.PollUntilCompletedAsync(cancellationToken: ct);
        job.ThrowOnAnyError();
        var results = await job.GetQueryResultsAsync(cancellationToken: ct);
        var bytes = job.Statistics?.TotalBytesProcessed ?? 0;
        return (results, bytes);
    }
}
