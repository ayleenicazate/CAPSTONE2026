import { Sparkline } from '@/components/charts/Sparkline'
import { Badge } from '@/components/ui/Badge'
import { Card } from '@/components/ui/Card'
import type { Point, StatusTone } from '@/types/api'

interface MetricCardProps {
  label: string
  value: string
  badge?: string | null
  tone?: StatusTone
  hint?: string | null
  footer?: string | null
  sparkline?: Point[] | null
  unit?: string
  digits?: number
}

export function MetricCard({ label, value, badge, tone, hint, footer, sparkline, unit = '', digits = 1 }: MetricCardProps) {
  return (
    <Card className="flex min-h-[132px] flex-col justify-between" title={hint ?? undefined}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm text-slate-500">{label}</p>
        {badge ? <Badge tone={tone}>{badge}</Badge> : null}
      </div>
      <p className="mt-2 text-3xl font-semibold tracking-tight tabular-nums text-slate-800">{value}</p>
      {sparkline && sparkline.length > 1 ? (
        <div className="mt-2">
          <Sparkline data={sparkline} unit={unit} digits={digits} />
          <p className="text-[11px] text-slate-400">Última hora</p>
        </div>
      ) : null}
      {footer ? <p className="mt-2 text-xs text-slate-400">{footer}</p> : null}
    </Card>
  )
}
