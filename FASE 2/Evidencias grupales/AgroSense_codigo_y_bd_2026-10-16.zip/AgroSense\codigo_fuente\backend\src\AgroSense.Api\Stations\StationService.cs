using System.Text.RegularExpressions;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Stations;

public partial class StationService(AgroSenseDbContext db, IOptions<StationOptions> options, TimeProvider clock)
{
    private readonly StationOptions _options = options.Value;

    [GeneratedRegex("^[a-z0-9_-]{3,40}$")]
    private static partial Regex CodePattern();

    /// <summary>Código válido como clave de Firebase: minúsculas, números, guion y guion bajo.</summary>
    public static bool IsValidCode(string code) => CodePattern().IsMatch(code);

    public static string NormalizeCode(string code) => code.Trim().ToLowerInvariant().Replace(' ', '-');

    public async Task<Station> GetOrCreateAsync(string code, CancellationToken ct = default)
    {
        code = NormalizeCode(code);
        var station = await db.Stations.FirstOrDefaultAsync(s => s.Code == code, ct);
        if (station is not null) return station;

        station = new Station
        {
            Code = code,
            Name = code == _options.DefaultCode ? _options.DefaultName : DefaultNameFor(code),
        };
        db.Stations.Add(station);
        await db.SaveChangesAsync(ct);
        return station;
    }

    public Task<Station> GetOrCreateDefaultAsync(CancellationToken ct = default) => GetOrCreateAsync(_options.DefaultCode, ct);

    /// <summary>
    /// Agrega al usuario a la estación. Si la estación no tiene administradores, entra como administrador;
    /// si no, como solo lectura (un administrador puede cambiarlo después).
    /// </summary>
    public async Task<StationMember?> AddMemberAsync(User user, Station station, CancellationToken ct = default, string? role = null)
    {
        var exists = await db.StationMembers.AnyAsync(m => m.UserId == user.Id && m.StationId == station.Id, ct);
        if (exists) return null;
        var hasAdmin = await db.StationMembers.AnyAsync(m => m.StationId == station.Id && m.Role == StationRoles.Admin, ct);
        var member = new StationMember
        {
            UserId = user.Id,
            StationId = station.Id,
            Role = role ?? (hasAdmin ? StationRoles.Viewer : StationRoles.Admin),
        };
        db.StationMembers.Add(member);
        await db.SaveChangesAsync(ct);
        return member;
    }

    /// <summary>Devuelve la estación y el rol del usuario, solo si es miembro.</summary>
    public async Task<(Station Station, string Role)?> FindMembershipAsync(Guid stationId, Guid userId, CancellationToken ct = default)
    {
        var member = await db.StationMembers
            .Include(m => m.Station)
            .FirstOrDefaultAsync(m => m.StationId == stationId && m.UserId == userId, ct);
        return member is null ? null : (member.Station, member.Role);
    }

    /// <summary>
    /// En línea si el dispositivo se reportó dentro de 3 intervalos de lectura (mínimo 2 minutos).
    /// </summary>
    public bool IsOnline(Station station)
    {
        if (station.LastSeenAt is null) return false;
        var window = TimeSpan.FromSeconds(Math.Max(120, station.ReadingIntervalSeconds * 3));
        return clock.GetUtcNow() - station.LastSeenAt.Value <= window;
    }

    public TimeZoneInfo TimeZone
    {
        get
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(_options.TimeZone);
            }
            catch (TimeZoneNotFoundException)
            {
                return TimeZoneInfo.Utc;
            }
        }
    }

    private static string DefaultNameFor(string code) =>
        string.Join(' ', code.Split('-', '_', StringSplitOptions.RemoveEmptyEntries)
            .Select(part => char.ToUpperInvariant(part[0]) + part[1..]));
}
