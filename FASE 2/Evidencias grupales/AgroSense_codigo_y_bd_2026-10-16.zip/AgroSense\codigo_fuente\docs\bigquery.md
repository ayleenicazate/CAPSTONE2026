# BigQuery: histórico y análisis

AgroSense usa dos bases de datos con responsabilidades distintas:

| | PostgreSQL | BigQuery |
|---|---|---|
| Tipo | Transaccional (OLTP) | Analítica (OLAP) |
| Uso | La aplicación: usuarios, configuración, riego, dashboard | Histórico completo, análisis SQL, machine learning |
| Lecturas crudas | Últimos 30 días (`Retention:RawReadingDays`) | Todas |
| Resúmenes por minuto | Siempre | — (se calculan con SQL cuando se necesitan) |

```
ESP32 → Firebase → API .NET → PostgreSQL ──(cada 5 min)──► BigQuery
```

El backend exporta cada 5 minutos las lecturas y los riegos terminados (`DataExport/BigQueryExporter.cs`).
Usa *load jobs*, que son gratuitos y funcionan también en el modo sandbox (sin facturación).
Las lecturas crudas solo se borran de PostgreSQL **después** de haberse exportado.

## 1. Dar permisos a la cuenta de servicio (una sola vez)

El backend usa la misma cuenta de servicio de Firebase:
`firebase-adminsdk-fbsvc@agrosense-a1b2c.iam.gserviceaccount.com`

1. Abre https://console.cloud.google.com/iam-admin/iam?project=agrosense-a1b2c
   (es el mismo proyecto de Firebase; entra con la misma cuenta de Google).
2. Busca la fila de `firebase-adminsdk-fbsvc@...` → ícono de lápiz (**Editar principal**).
3. **Agregar otro rol** → `BigQuery Data Editor` (Editor de datos de BigQuery).
4. **Agregar otro rol** → `BigQuery Job User` (Usuario de trabajos de BigQuery).
5. **Guardar**. El backend lo detecta solo en el siguiente ciclo (máximo 5 minutos) y crea el dataset
   `agrosense` con las tablas `readings` e `irrigation_events`.

Si aparece un aviso de que la **API de BigQuery** no está habilitada:
https://console.cloud.google.com/apis/library/bigquery.googleapis.com?project=agrosense-a1b2c → **Habilitar**.

> **Sandbox:** sin cuenta de facturación, BigQuery funciona en modo sandbox: 10 GB de almacenamiento y
> 1 TB de consultas gratis al mes, pero **las particiones vencen a los 60 días**. Para conservar el
> histórico indefinidamente hay que vincular una cuenta de facturación (con este volumen el costo es ~0).

El estado de la exportación se ve en el panel: **Configuración → Flujo de datos**.

## 2. Tablas

**`agrosense.readings`** (particionada por día en `ts`, agrupada por `station_code`)
`reading_id, station_code, ts, received_at, temperature, air_humidity, soil_moisture, soil_raw,
light_total, spectral_violet … spectral_red, air_quality_raw, air_quality_voltage,
air_quality_saturated, pump_on, pump_mode, source_key`

**`agrosense.irrigation_events`** (particionada por día en `started_at`)
`event_id, station_code, started_at, ended_at, duration_seconds, mode, start_moisture, end_moisture, water_liters`

## 3. Consultas de ejemplo

Abre la consola: https://console.cloud.google.com/bigquery?project=agrosense-a1b2c

### Resumen diario
```sql
SELECT
  DATE(ts, 'America/Santiago') AS dia,
  COUNT(*) AS lecturas,
  ROUND(AVG(temperature), 1) AS temp_prom,
  ROUND(MIN(temperature), 1) AS temp_min,
  ROUND(MAX(temperature), 1) AS temp_max,
  ROUND(AVG(air_humidity), 1) AS humedad_aire_prom,
  ROUND(AVG(soil_moisture), 1) AS humedad_suelo_prom,
  ROUND(AVG(light_total), 0) AS luz_prom
FROM `agrosense-a1b2c.agrosense.readings`
WHERE station_code = 'agrosense-01'
GROUP BY dia
ORDER BY dia DESC;
```

### Perfil horario (ciclo diario promedio)
```sql
SELECT
  EXTRACT(HOUR FROM ts AT TIME ZONE 'America/Santiago') AS hora,
  ROUND(AVG(temperature), 2) AS temperatura,
  ROUND(AVG(air_humidity), 2) AS humedad_aire,
  ROUND(AVG(light_total), 0) AS luz
FROM `agrosense-a1b2c.agrosense.readings`
WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 14 DAY)
GROUP BY hora
ORDER BY hora;
```

### Riegos y agua por semana
```sql
SELECT
  DATE_TRUNC(DATE(started_at, 'America/Santiago'), WEEK(MONDAY)) AS semana,
  COUNT(*) AS riegos,
  ROUND(SUM(duration_seconds) / 60, 1) AS minutos,
  ROUND(SUM(water_liters), 1) AS litros,
  ROUND(AVG(end_moisture - start_moisture), 1) AS aumento_humedad_prom
FROM `agrosense-a1b2c.agrosense.irrigation_events`
GROUP BY semana
ORDER BY semana DESC;
```

### Velocidad de secado del suelo (puntos de % por hora, entre riegos)
```sql
WITH horas AS (
  SELECT TIMESTAMP_TRUNC(ts, HOUR) AS hora, AVG(soil_moisture) AS suelo, LOGICAL_OR(pump_on) AS hubo_riego
  FROM `agrosense-a1b2c.agrosense.readings`
  WHERE ts > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  GROUP BY hora
)
SELECT hora, suelo, suelo - LAG(suelo) OVER (ORDER BY hora) AS cambio_por_hora
FROM horas
WHERE NOT hubo_riego
ORDER BY hora DESC;
```

## 4. Pronóstico con BigQuery ML (ARIMA_PLUS)

**Automático:** `DataExport/BigQueryMlService.cs` entrena cada 12 horas (`BigQuery:MlRetrainHours`) un modelo
`forecast_<variable>` por variable (temperatura, humedad ambiental, humedad del suelo, luz y calidad del aire),
con el histórico por hora de los últimos 30 días y cada estación como serie separada. Guarda el pronóstico
de 48 h con intervalo de confianza del 90 % en PostgreSQL (`ml_forecasts`), y el panel lo muestra en
**Historial** (24 h y 7 días). Si una variable tiene menos de 48 horas con datos, queda en "Faltan datos" y
el Historial usa el pronóstico simple. El estado de cada modelo se ve en **Análisis → Modelos de pronóstico**.

Las consultas siguientes sirven para explorar o mostrar el modelo a mano en la consola:

Requiere al menos 2–3 días de datos continuos (idealmente una semana o más).

### Entrenar el modelo de temperatura
```sql
CREATE OR REPLACE MODEL `agrosense-a1b2c.agrosense.temperatura_arima`
OPTIONS (
  model_type = 'ARIMA_PLUS',
  time_series_timestamp_col = 'hora',
  time_series_data_col = 'temperatura',
  data_frequency = 'HOURLY',
  holiday_region = 'CL'
) AS
SELECT TIMESTAMP_TRUNC(ts, HOUR) AS hora, AVG(temperature) AS temperatura
FROM `agrosense-a1b2c.agrosense.readings`
WHERE station_code = 'agrosense-01' AND temperature IS NOT NULL
GROUP BY hora;
```

### Pronóstico de las próximas 24 horas (con intervalo de confianza del 90 %)
```sql
SELECT
  DATETIME(forecast_timestamp, 'America/Santiago') AS hora_local,
  ROUND(forecast_value, 1) AS temperatura_estimada,
  ROUND(prediction_interval_lower_bound, 1) AS minimo_probable,
  ROUND(prediction_interval_upper_bound, 1) AS maximo_probable
FROM ML.FORECAST(MODEL `agrosense-a1b2c.agrosense.temperatura_arima`,
                 STRUCT(24 AS horizon, 0.9 AS confidence_level));
```

### Evaluar el modelo
```sql
SELECT * FROM ML.ARIMA_EVALUATE(MODEL `agrosense-a1b2c.agrosense.temperatura_arima`);
```

El mismo patrón sirve para `soil_moisture`, `air_humidity` o `light_total` (cambiando la columna y el
nombre del modelo). Para la humedad del suelo conviene excluir las horas con riego, porque el riego es
una intervención externa que el modelo no puede anticipar.

## 5. Análisis histórico en el portal

La página **Análisis** del panel consulta BigQuery (con 10 minutos de caché) y muestra totales, resumen
mensual, tendencia diaria de 90 días y hallazgos calculados automáticamente: velocidad de secado del suelo,
efecto de la temperatura en el secado (regresión y correlación), ciclo diario, relación luz-temperatura y riego
promedio. Usa las vistas `daily_summary` y `hourly_summary`, que el backend crea en el dataset.

## 6. Reporte en Looker Studio

1. En el panel: **Análisis → Reporte en Looker Studio → Crear reporte** (abre un reporte en blanco; entra con
   la cuenta de Google del proyecto). En "Agregar datos al informe" elige **BigQuery → Mis proyectos →
   agrosense-a1b2c → agrosense → daily_summary → Agregar**. Luego **Recurso → Administrar fuentes de datos →
   Agregar** y repite con `hourly_summary`.
2. Agrega los gráficos. Algunas ideas:
   - **Serie temporal** con `day` y `temperature_avg`, `temperature_min`, `temperature_max`.
   - **Gráfico de barras** con `day` y `water_liters`.
   - **Tabla dinámica** de `hourly_summary` con `hour_of_day` × `day`, coloreada por `temperature` (mapa de calor).
   - **Tarjetas** con la suma de `readings`, `irrigations` y `water_liters`.
3. **Guardar** y luego **Compartir → Cualquier persona con el enlace puede ver**. Copia el enlace.
4. En el servidor, agrega a `/opt/agrosense/.env.prod` la línea `LOOKER_STUDIO_URL=<enlace>` y vuelve a
   levantar con `docker compose -f docker-compose.prod.yml --env-file .env.prod up -d`. Desde ese momento el botón
   del panel dice **Abrir reporte**.
