import { useEffect, useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'

import { AppSidebar, MobileSidebar } from '@/components/AppSidebar'
import { JoinStationCard } from '@/components/JoinStationCard'
import { TopBar } from '@/components/TopBar'
import { ErrorState, LoadingState } from '@/components/ui/States'
import { useStationsQuery } from '@/services/queries'
import { SELECTED_STATION_KEY, type StationOutletContext } from '@/stations/StationContext'

const titles: Record<string, string> = {
  '/': 'Resumen de la estación',
  '/sensores': 'Sensores agroambientales',
  '/riego': 'Control del sistema de riego',
  '/historial': 'Historial',
  '/analisis': 'Análisis histórico (BigQuery)',
  '/configuracion': 'Configuración de la estación',
}

function readSelected(): string | null {
  try {
    return localStorage.getItem(SELECTED_STATION_KEY)
  } catch {
    return null
  }
}

export function AppLayout() {
  const location = useLocation()
  const { data: stations, isLoading, error, refetch } = useStationsQuery()
  const [selectedId, setSelectedId] = useState<string | null>(readSelected)
  const [menuOpen, setMenuOpen] = useState(false)

  const station = stations?.find((item) => item.id === selectedId) ?? stations?.[0]

  useEffect(() => {
    if (!station) return
    try {
      localStorage.setItem(SELECTED_STATION_KEY, station.id)
    } catch {
      // almacenamiento no disponible: no es crítico
    }
  }, [station])

  let content
  if (isLoading) {
    content = <LoadingState label="Cargando estaciones..." />
  } else if (error) {
    content = <ErrorState error={error} onRetry={() => void refetch()} />
  } else if (!station) {
    content = (
      <div className="mx-auto max-w-lg">
        <JoinStationCard
          title="Aún no tienes una estación vinculada"
          onJoined={(joined) => setSelectedId(joined.id)}
        />
      </div>
    )
  } else {
    const context: StationOutletContext = { station }
    content = (
      <div key={station.id}>
        <Outlet context={context} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <MobileSidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <div className="flex">
        <AppSidebar />
        <div className="min-w-0 flex-1">
          <TopBar
            title={titles[location.pathname] ?? 'AgroSense'}
            station={station}
            stations={stations ?? []}
            onSelectStation={setSelectedId}
            onOpenMenu={() => setMenuOpen(true)}
          />
          <main className="p-4 md:p-6">{content}</main>
        </div>
      </div>
    </div>
  )
}
