using System.Text.Json;
using System.Text.Json.Nodes;

namespace AgroSense.Api.Ingestion;

/// <summary>Una lectura tal como llega del dispositivo, ya normalizada.</summary>
public record IncomingReading(
    string SourceKey,
    DateTimeOffset Timestamp,
    double? Temperature,
    double? AirHumidity,
    double? SoilMoisture,
    double? Light,
    bool? PumpOn,
    string? PumpMode,
    int? SoilRaw = null,
    int? AirQualityRaw = null,
    double? AirQualityVoltage = null,
    Spectrum? Spectrum = null);

/// <summary>Lectura del AS7262 (µW/cm² por banda del espectro visible).</summary>
public record Spectrum(double? Violet, double? Blue, double? Green, double? Yellow, double? Orange, double? Red, double? Total);

/// <summary>Estado de red/hardware que reporta el dispositivo.</summary>
public record IncomingStatus(
    DateTimeOffset? LastSeen,
    string? MacAddress,
    string? IpAddress,
    int? WifiRssi,
    string? Firmware);

/// <summary>
/// Convierte el JSON del dispositivo en <see cref="IncomingReading"/>.
/// Es tolerante: acepta números como texto, 0/1 para booleanos, ts en segundos o milisegundos
/// y algunos nombres alternativos de campos, porque el firmware lo escribe otra persona.
/// </summary>
public static class ReadingParser
{
    private static readonly string[] TemperatureKeys = ["temperature", "temp", "temperatura"];
    private static readonly string[] AirHumidityKeys = ["airHumidity", "humidity", "humedad", "humedadAmbiente"];
    private static readonly string[] SoilKeys = ["soilMoisture", "soil", "humedadSuelo"];
    private static readonly string[] LightKeys = ["light", "luz", "luminosidad", "ldr"];
    private static readonly string[] PumpKeys = ["pumpOn", "pump", "bomba"];
    private static readonly string[] TimestampKeys = ["ts", "timestamp"];

    public static IncomingReading? Parse(string sourceKey, JsonNode? node, DateTimeOffset receivedAt)
    {
        if (node is not JsonObject obj) return null;

        var reading = new IncomingReading(
            sourceKey,
            ParseTimestamp(GetNumber(obj, TimestampKeys)) ?? receivedAt,
            Clamp(GetNumber(obj, TemperatureKeys), -40, 85),
            Clamp(GetNumber(obj, AirHumidityKeys), 0, 100),
            Clamp(GetNumber(obj, SoilKeys), 0, 100),
            Clamp(GetNumber(obj, LightKeys), 0, 100),
            GetBool(obj, PumpKeys),
            NormalizeMode(GetString(obj, "pumpMode")),
            ToInt(Clamp(GetNumber(obj, ["soilRaw"]), 0, 65535)),
            ParseAirQualityRaw(obj),
            ParseAirQualityVoltage(obj),
            ParseSpectrum(obj));

        // Una lectura sin ninguna variable no aporta nada.
        return reading is
        {
            Temperature: null, AirHumidity: null, SoilMoisture: null, Light: null, PumpOn: null,
            AirQualityRaw: null, AirQualityVoltage: null, Spectrum: null,
        }
            ? null
            : reading;
    }

    /// <summary>MQ135: objeto <c>mq135 {raw, adcVoltage, sensorVoltage}</c> o campos planos <c>airQualityRaw</c>.</summary>
    private static int? ParseAirQualityRaw(JsonObject obj)
    {
        var raw = Find(obj, ["mq135"]) is JsonObject mq
            ? GetNumber(mq, ["raw"])
            : GetNumber(obj, ["airQualityRaw", "mq135Raw"]);
        return ToInt(Clamp(raw, 0, 65535));
    }

    /// <summary>Voltaje en la salida del sensor (antes del divisor). Si solo viene el del ADC, se usa ese.</summary>
    private static double? ParseAirQualityVoltage(JsonObject obj)
    {
        var voltage = Find(obj, ["mq135"]) is JsonObject mq
            ? GetNumber(mq, ["sensorVoltage", "voltage"]) ?? GetNumber(mq, ["adcVoltage"])
            : GetNumber(obj, ["airQualityVoltage", "mq135Voltage"]);
        return Clamp(voltage, 0, 12, digits: 3);
    }

    private static Spectrum? ParseSpectrum(JsonObject obj)
    {
        if (Find(obj, ["spectral", "as7262"]) is not JsonObject s) return null;
        double? Band(string name) => Clamp(GetNumber(s, [name]), 0, 1_000_000);

        var bands = new[] { Band("violet"), Band("blue"), Band("green"), Band("yellow"), Band("orange"), Band("red") };
        if (bands.All(b => b is null)) return null;
        // Si el dispositivo no envía el total, se calcula.
        var total = Band("total") ?? Math.Round(bands.Sum(b => b ?? 0), 2);
        return new Spectrum(bands[0], bands[1], bands[2], bands[3], bands[4], bands[5], total);
    }

    private static int? ToInt(double? value) => value is null ? null : (int)Math.Round(value.Value);

    public static IncomingStatus ParseStatus(JsonNode? node)
    {
        if (node is not JsonObject obj) return new IncomingStatus(null, null, null, null, null);
        var rssi = GetNumber(obj, ["rssi", "wifiRssi"]);
        return new IncomingStatus(
            ParseTimestamp(GetNumber(obj, ["lastSeen", "ts"])),
            GetString(obj, "mac"),
            GetString(obj, "ip"),
            rssi is null ? null : (int)rssi,
            GetString(obj, "firmware"));
    }

    /// <summary>Epoch en segundos o milisegundos (Firebase ServerValue.TIMESTAMP usa ms).</summary>
    public static DateTimeOffset? ParseTimestamp(double? value)
    {
        if (value is null or <= 0) return null;
        var ms = value.Value > 100_000_000_000 ? value.Value : value.Value * 1000;
        try
        {
            return DateTimeOffset.FromUnixTimeMilliseconds((long)ms);
        }
        catch (ArgumentOutOfRangeException)
        {
            return null;
        }
    }

    private static double? Clamp(double? value, double min, double max, int digits = 2) =>
        value is null || double.IsNaN(value.Value) || value < min || value > max ? null : Math.Round(value.Value, digits);

    private static string? NormalizeMode(string? mode) => mode?.Trim().ToLowerInvariant() switch
    {
        "manual" => "manual",
        "auto" or "automatic" or "automatico" or "automático" => "auto",
        _ => null,
    };

    private static JsonNode? Find(JsonObject obj, IEnumerable<string> keys)
    {
        foreach (var key in keys)
        {
            foreach (var (name, value) in obj)
            {
                if (string.Equals(name, key, StringComparison.OrdinalIgnoreCase)) return value;
            }
        }
        return null;
    }

    private static double? GetNumber(JsonObject obj, IEnumerable<string> keys)
    {
        if (Find(obj, keys) is not JsonValue value) return null;
        return value.GetValueKind() switch
        {
            JsonValueKind.Number => value.GetValue<double>(),
            JsonValueKind.String when double.TryParse(value.GetValue<string>(),
                System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var d) => d,
            _ => null,
        };
    }

    private static bool? GetBool(JsonObject obj, IEnumerable<string> keys)
    {
        if (Find(obj, keys) is not JsonValue value) return null;
        return value.GetValueKind() switch
        {
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.Number => value.GetValue<double>() != 0,
            JsonValueKind.String => value.GetValue<string>().Trim().ToLowerInvariant() is "true" or "1" or "on",
            _ => null,
        };
    }

    private static string? GetString(JsonObject obj, string key) =>
        Find(obj, [key]) is JsonValue value && value.GetValueKind() == JsonValueKind.String
            ? value.GetValue<string>()
            : null;
}
