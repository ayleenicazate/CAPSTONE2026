\pset pager off
SET TIME ZONE 'America/Santiago';
-- 1
SELECT "Code" AS estacion, "Name" AS nombre, "LastSeenAt" AS ultima_lectura,
       "ReadingIntervalSeconds" AS intervalo_s, "AutoIrrigation" AS riego_auto,
       "ActivationThreshold" AS umbral_on, "DeactivationThreshold" AS umbral_off,
       "MaxPumpSeconds" AS max_bomba_s, "Firmware", "WifiRssi" AS senal_wifi
FROM stations ORDER BY "Code";
-- 2
SELECT r."Timestamp" AS hora, r."Temperature" AS temp_c, r."AirHumidity" AS hum_aire,
       r."SoilMoisture" AS hum_suelo, r."SoilRaw" AS suelo_crudo,
       r."AirQualityVoltage" AS mq135_v, r."SpectralTotal" AS luz_total,
       r."PumpOn" AS bomba, r."PumpMode" AS modo
FROM readings r JOIN stations s ON s."Id" = r."StationId"
WHERE s."Code" = 'agrosense-01'
ORDER BY r."Timestamp" DESC LIMIT 20;
-- 3
SELECT s."Code" AS estacion, r."Timestamp"::date AS dia, count(*) AS lecturas,
       round(avg(r."Temperature")::numeric, 1) AS temp_prom,
       round(avg(r."SoilMoisture")::numeric, 1) AS suelo_prom
FROM readings r JOIN stations s ON s."Id" = r."StationId"
GROUP BY 1, 2 ORDER BY 1, 2 DESC;
-- 4
SELECT s."Code" AS estacion, e."StartedAt" AS inicio, e."EndedAt" AS fin, e."Mode" AS modo,
       extract(epoch FROM e."EndedAt" - e."StartedAt")::int AS segundos,
       e."StartMoisture" AS suelo_antes, e."EndMoisture" AS suelo_despues
FROM irrigation_events e JOIN stations s ON s."Id" = e."StationId"
ORDER BY e."StartedAt" DESC LIMIT 20;
-- 5
SELECT s."Code" AS estacion, a."At" AS fecha, a."UserName" AS persona, a."Action" AS accion, a."Summary" AS cambio
FROM audit_entries a JOIN stations s ON s."Id" = a."StationId"
ORDER BY a."At" DESC LIMIT 30;
-- 6
SELECT u."Name" AS nombre, u."Email" AS correo, s."Code" AS estacion, m."Role" AS rol, m."JoinedAt" AS desde
FROM station_members m
JOIN users u ON u."Id" = m."UserId"
JOIN stations s ON s."Id" = m."StationId"
ORDER BY s."Code", m."JoinedAt";
-- 7
SELECT s."Code" AS estacion, a."Key" AS alerta, a."Active" AS activa, a."Since" AS desde, a."NotifiedAt" AS avisada
FROM alert_states a JOIN stations s ON s."Id" = a."StationId"
ORDER BY 1, 2;
-- 8
SELECT m."Minute" AS minuto, m."Count" AS lecturas,
       round(m."TemperatureAvg"::numeric, 1) AS temp_prom,
       round(m."SoilMoistureAvg"::numeric, 1) AS suelo_prom,
       m."PumpOnCount" AS lecturas_con_bomba
FROM reading_minutes m JOIN stations s ON s."Id" = m."StationId"
WHERE s."Code" = 'agrosense-01'
ORDER BY m."Minute" DESC LIMIT 30;
-- 9
SELECT s."Code" AS estacion, f."Variable" AS variable, f."Timestamp" AS hora,
       round(f."Value"::numeric, 1) AS valor, round(f."Lower"::numeric, 1) AS minimo,
       round(f."Upper"::numeric, 1) AS maximo, f."TrainedAt" AS entrenado
FROM ml_forecasts f JOIN stations s ON s."Id" = f."StationId"
WHERE f."Variable" = 'temperature'
ORDER BY f."Timestamp" LIMIT 24;
-- 10
SELECT "Variable" AS variable, "Status" AS estado, "RunAt" AS ejecutado, "TrainingPoints" AS puntos, "Message" AS mensaje
FROM ml_model_runs ORDER BY "Variable";
