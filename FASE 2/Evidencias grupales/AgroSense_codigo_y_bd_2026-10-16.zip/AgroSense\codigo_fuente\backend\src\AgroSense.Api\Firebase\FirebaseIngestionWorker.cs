using System.Text.Json.Nodes;
using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Ingestion;
using AgroSense.Api.Stations;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Firebase;

/// <summary>
/// Cada N segundos lee de Firebase las lecturas nuevas de cada estación (/stations/{code}/readings)
/// y su estado (/stations/{code}/status), y las persiste en PostgreSQL.
/// Las estaciones que aparecen en Firebase y no existen en la base se crean automáticamente.
/// </summary>
public class FirebaseIngestionWorker(
    IServiceScopeFactory scopes,
    FirebaseRtdbClient firebase,
    IOptions<FirebaseOptions> options,
    TimeProvider clock,
    ILogger<FirebaseIngestionWorker> logger) : BackgroundService
{
    private readonly FirebaseOptions _options = options.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (!firebase.Enabled)
        {
            logger.LogInformation("Firebase no configurado: la ingesta desde Realtime Database está desactivada.");
            return;
        }

        logger.LogInformation("Ingesta desde Firebase activa ({Url}), cada {Seconds}s", _options.DatabaseUrl, _options.PollIntervalSeconds);
        var configSynced = new HashSet<Guid>();
        var lastPrune = DateTimeOffset.MinValue;
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(Math.Max(2, _options.PollIntervalSeconds)));

        do
        {
            try
            {
                await SyncOnceAsync(configSynced, stoppingToken);
                if (_options.PruneAfterHours > 0 && clock.GetUtcNow() - lastPrune > TimeSpan.FromMinutes(10))
                {
                    lastPrune = clock.GetUtcNow();
                    await PruneAsync(stoppingToken);
                }
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Error sincronizando con Firebase; se reintentará");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    public async Task SyncOnceAsync(HashSet<Guid> configSynced, CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
        var stations = scope.ServiceProvider.GetRequiredService<StationService>();
        var ingestion = scope.ServiceProvider.GetRequiredService<IngestionService>();
        var publisher = scope.ServiceProvider.GetRequiredService<IDeviceConfigPublisher>();

        // Descubrir estaciones nuevas en Firebase (shallow = solo las claves).
        var remote = await firebase.GetAsync("stations", new Dictionary<string, string> { ["shallow"] = "true" }, ct);
        if (remote is JsonObject remoteStations)
        {
            foreach (var (code, _) in remoteStations)
            {
                if (StationService.IsValidCode(code)) await stations.GetOrCreateAsync(code, ct);
            }
        }

        foreach (var station in await db.Stations.ToListAsync(ct))
        {
            // La primera vez que vemos una estación, nos aseguramos de que el dispositivo tenga su configuración.
            if (!configSynced.Contains(station.Id))
            {
                var existingConfig = await firebase.GetAsync($"stations/{station.Code}/config", ct: ct);
                if (existingConfig is null && !await publisher.PublishAsync(station, ct)) continue;
                configSynced.Add(station.Id);
            }

            var status = await firebase.GetAsync($"stations/{station.Code}/status", ct: ct);
            if (status is not null)
            {
                IngestionService.ApplyStatus(station, ReadingParser.ParseStatus(status), clock.GetUtcNow());
                await db.SaveChangesAsync(ct);
            }

            await IngestReadingsAsync(db, ingestion, station, ct);
        }
    }

    /// <summary>
    /// Borra de Firebase las lecturas ya importadas y más antiguas que PruneAfterHours
    /// (siguen en PostgreSQL y BigQuery). Mantiene Realtime Database dentro del plan gratuito.
    /// </summary>
    private async Task PruneAsync(CancellationToken ct)
    {
        using var scope = scopes.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
        var thresholdKey = FirebaseRtdbClient.PushKeyPrefix(clock.GetUtcNow().AddHours(-_options.PruneAfterHours));

        foreach (var station in await db.Stations.AsNoTracking().ToListAsync(ct))
        {
            var cursor = await db.IngestionCursors.AsNoTracking().FirstOrDefaultAsync(c => c.StationId == station.Id, ct);
            if (cursor is null) continue;

            // Nunca borrar algo que todavía no se importó.
            var endKey = string.CompareOrdinal(thresholdKey, cursor.LastKey) < 0 ? thresholdKey : cursor.LastKey;
            var deleted = 0;
            while (true)
            {
                var query = new Dictionary<string, string>
                {
                    ["orderBy"] = FirebaseRtdbClient.QueryString("$key"),
                    ["endAt"] = FirebaseRtdbClient.QueryString(endKey),
                    ["limitToFirst"] = "1000",
                };
                if (await firebase.GetAsync($"stations/{station.Code}/readings", query, ct) is not JsonObject batch || batch.Count == 0) break;

                var keys = batch.Select(e => e.Key).Where(k => string.CompareOrdinal(k, endKey) <= 0).ToList();
                if (keys.Count == 0) break;
                await firebase.DeleteChildrenAsync($"stations/{station.Code}/readings", keys, ct);
                deleted += keys.Count;
                if (batch.Count < 1000) break;
            }
            if (deleted > 0) logger.LogInformation("Estación {Code}: {Count} lecturas antiguas eliminadas de Firebase", station.Code, deleted);
        }
    }

    private async Task IngestReadingsAsync(AgroSenseDbContext db, IngestionService ingestion, Station station, CancellationToken ct)
    {
        var cursor = await db.IngestionCursors.FindAsync([station.Id], ct);

        while (true)
        {
            var query = new Dictionary<string, string>
            {
                ["orderBy"] = FirebaseRtdbClient.QueryString("$key"),
                ["limitToFirst"] = _options.BatchSize.ToString(),
            };
            if (cursor is not null) query["startAt"] = FirebaseRtdbClient.QueryString(cursor.LastKey);

            if (await firebase.GetAsync($"stations/{station.Code}/readings", query, ct) is not JsonObject batch) return;

            // startAt es inclusivo: se descarta la clave ya procesada.
            var entries = batch
                .Where(e => cursor is null || string.CompareOrdinal(e.Key, cursor.LastKey) > 0)
                .OrderBy(e => e.Key, StringComparer.Ordinal)
                .ToList();
            if (entries.Count == 0) return;

            var now = clock.GetUtcNow();
            var readings = entries
                .Select(e => ReadingParser.Parse(e.Key, e.Value, now))
                .OfType<IncomingReading>()
                .ToList();

            var inserted = await ingestion.IngestAsync(station, readings, ct);

            var lastKey = entries[^1].Key;
            if (cursor is null)
            {
                cursor = new IngestionCursor { StationId = station.Id, LastKey = lastKey };
                db.IngestionCursors.Add(cursor);
            }
            else
            {
                cursor.LastKey = lastKey;
                cursor.UpdatedAt = now;
            }
            await db.SaveChangesAsync(ct);

            if (inserted > 0) logger.LogInformation("Estación {Code}: {Count} lecturas ingeridas desde Firebase", station.Code, inserted);
            if (batch.Count < _options.BatchSize) return;
        }
    }
}
