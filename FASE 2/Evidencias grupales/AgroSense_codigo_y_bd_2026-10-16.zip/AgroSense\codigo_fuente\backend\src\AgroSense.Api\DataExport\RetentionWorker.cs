using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.DataExport;

/// <summary>
/// Borra lecturas crudas antiguas de PostgreSQL (los resúmenes por minuto se conservan).
/// Si BigQuery está activo, solo borra lecturas que ya fueron exportadas.
/// </summary>
public class RetentionWorker(
    IServiceScopeFactory scopes,
    IOptions<RetentionOptions> retention,
    IOptions<BigQueryOptions> bigQuery,
    TimeProvider clock,
    ILogger<RetentionWorker> logger) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var days = retention.Value.RawReadingDays;
        if (days <= 0)
        {
            logger.LogInformation("Retención desactivada: se conservan todas las lecturas crudas.");
            return;
        }

        using var timer = new PeriodicTimer(TimeSpan.FromHours(6));
        do
        {
            try
            {
                using var scope = scopes.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AgroSenseDbContext>();
                var cutoff = clock.GetUtcNow().AddDays(-days);
                var query = db.Readings.Where(r => r.Timestamp < cutoff);

                if (bigQuery.Value.Enabled)
                {
                    var exported = await db.ExportStates.AsNoTracking()
                        .Where(s => s.Key == BigQueryExporter.ReadingsKey)
                        .Select(s => (long?)s.LastId)
                        .FirstOrDefaultAsync(stoppingToken) ?? 0;
                    query = query.Where(r => r.Id <= exported);
                }

                var deleted = await query.ExecuteDeleteAsync(stoppingToken);
                if (deleted > 0) logger.LogInformation("Retención: {Count} lecturas crudas de más de {Days} días eliminadas", deleted, days);
            }
            catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
            {
                logger.LogError(ex, "Error aplicando la retención de lecturas");
            }
        }
        while (await timer.WaitForNextTickAsync(stoppingToken));
    }
}
