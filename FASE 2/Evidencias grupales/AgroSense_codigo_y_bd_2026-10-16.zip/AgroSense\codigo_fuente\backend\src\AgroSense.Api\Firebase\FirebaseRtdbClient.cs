using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using AgroSense.Api.Infrastructure;
using Google.Apis.Auth.OAuth2;
using Microsoft.Extensions.Options;

namespace AgroSense.Api.Firebase;

/// <summary>
/// Cliente mínimo para la API REST de Firebase Realtime Database.
/// https://firebase.google.com/docs/reference/rest/database
/// </summary>
public class FirebaseRtdbClient
{
    private static readonly string[] Scopes =
    [
        "https://www.googleapis.com/auth/firebase.database",
        "https://www.googleapis.com/auth/userinfo.email",
    ];

    private readonly HttpClient _http;
    private readonly FirebaseOptions _options;
    private readonly ITokenAccess? _credential;

    public FirebaseRtdbClient(HttpClient http, IOptions<FirebaseOptions> options)
    {
        _http = http;
        _options = options.Value;

        if (_options.Enabled)
        {
            _http.BaseAddress = new Uri(_options.DatabaseUrl.TrimEnd('/') + "/");
        }

        if (_options.Enabled && !string.IsNullOrWhiteSpace(_options.ServiceAccountPath))
        {
            _credential = CredentialFactory
                .FromFile<ServiceAccountCredential>(_options.ServiceAccountPath)
                .ToGoogleCredential()
                .CreateScoped(Scopes);
        }
    }

    public bool Enabled => _options.Enabled;

    public async Task<JsonNode?> GetAsync(string path, IDictionary<string, string>? query = null, CancellationToken ct = default)
    {
        using var response = await _http.GetAsync(await BuildUriAsync(path, query, ct), ct);
        await EnsureSuccessAsync(response, path, ct);
        var stream = await response.Content.ReadAsStreamAsync(ct);
        return await JsonNode.ParseAsync(stream, cancellationToken: ct);
    }

    public async Task PatchAsync(string path, object value, CancellationToken ct = default)
    {
        using var response = await _http.PatchAsJsonAsync(await BuildUriAsync(path, null, ct), value, JsonOptions, ct);
        await EnsureSuccessAsync(response, path, ct);
    }

    public async Task PostAsync(string path, object value, CancellationToken ct = default)
    {
        using var response = await _http.PostAsJsonAsync(await BuildUriAsync(path, null, ct), value, JsonOptions, ct);
        await EnsureSuccessAsync(response, path, ct);
    }

    /// <summary>Borra varias claves hijas de <paramref name="path"/> en una sola escritura (PATCH con null).</summary>
    public Task DeleteChildrenAsync(string path, IEnumerable<string> keys, CancellationToken ct = default) =>
        PatchAsync(path, keys.ToDictionary(k => k, _ => (object?)null), ct);

    private const string PushChars = "-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz";

    /// <summary>
    /// Prefijo de 8 caracteres de una clave push de Firebase para un instante dado. Las claves push
    /// empiezan con el tiempo de creación, así que toda clave &lt; este prefijo es anterior a ese instante.
    /// </summary>
    public static string PushKeyPrefix(DateTimeOffset time)
    {
        var ms = time.ToUnixTimeMilliseconds();
        var chars = new char[8];
        for (var i = 7; i >= 0; i--)
        {
            chars[i] = PushChars[(int)(ms % 64)];
            ms /= 64;
        }
        return new string(chars);
    }

    public static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    /// <summary>Codifica un valor como parámetro de consulta de Firebase (las cadenas van entre comillas).</summary>
    public static string QueryString(string value) => JsonSerializer.Serialize(value);

    private async Task<string> BuildUriAsync(string path, IDictionary<string, string>? query, CancellationToken ct)
    {
        if (!Enabled)
        {
            throw new InvalidOperationException("Firebase no está configurado (Firebase:DatabaseUrl).");
        }

        var parameters = new Dictionary<string, string>(query ?? new Dictionary<string, string>());
        if (_credential is not null)
        {
            parameters["access_token"] = await _credential.GetAccessTokenForRequestAsync(cancellationToken: ct);
        }
        else if (!string.IsNullOrWhiteSpace(_options.DatabaseSecret))
        {
            parameters["auth"] = _options.DatabaseSecret;
        }

        var queryString = string.Join("&", parameters.Select(p => $"{Uri.EscapeDataString(p.Key)}={Uri.EscapeDataString(p.Value)}"));
        var relative = path.Trim('/') + ".json";
        return queryString.Length > 0 ? $"{relative}?{queryString}" : relative;
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, string path, CancellationToken ct)
    {
        if (response.IsSuccessStatusCode) return;
        var body = await response.Content.ReadAsStringAsync(ct);
        throw new HttpRequestException(
            $"Firebase respondió {(int)response.StatusCode} en '{path}': {body}", null, response.StatusCode);
    }
}
