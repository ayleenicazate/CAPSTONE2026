// Colores de los gráficos. La paleta se validó con el validador de la guía dataviz
// (contraste ≥ 3:1 sobre blanco y distinguibles con daltonismo): verde de marca + azul.

export const chart = {
  series: '#4a7d3c', // serie principal (medido)
  forecast: '#2a78d6', // estimado / pronóstico (siempre con línea discontinua)
  water: '#2a78d6', // agua / riego
  band: '#4a7d3c', // banda mín–máx (con opacidad baja)
  grid: '#e5ebe3',
  axis: '#94a3b8',
  activation: '#b45309', // umbral de activación (texto ámbar oscuro, legible)
  deactivation: '#15803d',
} as const

/** Rampa secuencial azul (claro → oscuro) para mapas de calor. */
export const sequentialBlue = [
  '#cde2fb', '#b7d3f6', '#9ec5f4', '#86b6ef', '#6da7ec', '#5598e7',
  '#3987e5', '#2a78d6', '#256abf', '#1c5cab', '#184f95', '#104281', '#0d366b',
] as const

export function sequentialColor(value: number, min: number, max: number): string {
  if (max <= min) return sequentialBlue[6]
  const t = Math.min(1, Math.max(0, (value - min) / (max - min)))
  return sequentialBlue[Math.round(t * (sequentialBlue.length - 1))]
}

export const tooltipStyle = {
  contentStyle: {
    borderRadius: 12,
    border: '1px solid #e2e8f0',
    boxShadow: '0 8px 24px rgba(15, 23, 42, 0.08)',
    fontSize: 12,
  },
  labelStyle: { color: '#0f172a', fontWeight: 600 },
  itemStyle: { color: '#334155' },
} as const
