import { useQuery } from '@tanstack/react-query'
import { Cpu, KeyRound, Lock, Mail, User } from 'lucide-react'
import { useState, type FormEvent, type ReactNode } from 'react'
import { Link, useNavigate } from 'react-router-dom'

import { useAuth } from '@/auth/AuthContext'
import { AuthCard, BrandMark } from '@/components/auth/AuthShell'
import { api } from '@/services/api'

const fieldClass =
  'w-full rounded-lg border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-[#1a7a3a] focus:ring-2 focus:ring-[#1a7a3a]/15'

function Field({
  label,
  icon,
  children,
}: {
  label: string
  icon: ReactNode
  children: ReactNode
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-slate-700">{label}</span>
      <div className="relative">
        <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">{icon}</span>
        {children}
      </div>
    </label>
  )
}

export function RegisterPage() {
  const navigate = useNavigate()
  const { register } = useAuth()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [stationId, setStationId] = useState('')
  const [inviteCode, setInviteCode] = useState('')
  const { data: authOptions } = useQuery({ queryKey: ['auth-options'], queryFn: api.authOptions, staleTime: Infinity })
  const [accepted, setAccepted] = useState(false)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    if (!accepted) {
      setError('Debes aceptar los términos para continuar.')
      return
    }

    setBusy(true)
    try {
      await register(name, email, password, stationId, inviteCode)
      navigate('/', { replace: true })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo crear la cuenta.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthCard wide>
      <BrandMark />

      <h2 className="mt-5 text-[1.65rem] font-bold tracking-tight text-slate-900">Crear Cuenta</h2>
      <p className="mt-1 text-sm text-slate-500">Registra tus datos para vincular tu primera estación IoT</p>

      <form className="mt-5 space-y-3.5" onSubmit={(event) => void handleSubmit(event)}>
        <Field label="Nombre completo" icon={<User size={16} />}>
          <input
            required
            autoComplete="name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Ej. Juan Pérez"
            className={fieldClass}
          />
        </Field>

        <Field label="Correo institucional o personal" icon={<Mail size={16} />}>
          <input
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="ejemplo@correo.com"
            className={fieldClass}
          />
        </Field>

        <Field label="Contraseña" icon={<Lock size={16} />}>
          <input
            type="password"
            required
            minLength={8}
            autoComplete="new-password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Mínimo 8 caracteres"
            className={fieldClass}
          />
        </Field>

        {authOptions?.inviteRequired ? (
          <Field label="Código de invitación" icon={<KeyRound size={16} />}>
            <input
              required
              value={inviteCode}
              onChange={(event) => setInviteCode(event.target.value)}
              placeholder="Entregado por el equipo del proyecto"
              className={fieldClass}
            />
          </Field>
        ) : null}

        <Field label="ID de estación AgroSense (opcional)" icon={<Cpu size={16} />}>
          <input
            value={stationId}
            onChange={(event) => setStationId(event.target.value)}
            placeholder="Ej. agrosense-01 (vacío = estación principal)"
            className={fieldClass}
          />
        </Field>

        <label className="flex items-start gap-2.5 pt-1 text-sm leading-snug text-slate-600">
          <input
            type="checkbox"
            checked={accepted}
            onChange={(event) => setAccepted(event.target.checked)}
            className="mt-0.5 h-4 w-4 shrink-0 rounded border-slate-300 accent-[#1a7a3a]"
          />
          <span>
            Acepto los{' '}
            <Link to="/terminos" className="font-medium text-[#1a7a3a] underline">
              Términos de servicio
            </Link>{' '}
            y la{' '}
            <Link to="/privacidad" className="font-medium text-[#1a7a3a] underline">
              Política de privacidad
            </Link>{' '}
            de AgroSense.
          </span>
        </label>

        {error ? <p className="text-sm text-red-600">{error}</p> : null}

        <button
          type="submit"
          disabled={busy}
          className="mt-1 w-full rounded-lg bg-[#1a7a3a] py-2.5 text-sm font-semibold text-white transition hover:bg-[#166834] disabled:opacity-60"
        >
          {busy ? 'Creando cuenta...' : 'Registrarse y Comenzar'}
        </button>
      </form>

      <p className="mt-5 text-center text-sm text-slate-500">
        ¿Ya tienes una cuenta?{' '}
        <Link to="/login" className="font-semibold text-[#1a7a3a] hover:underline">
          Inicia sesión aquí
        </Link>
      </p>
    </AuthCard>
  )
}
