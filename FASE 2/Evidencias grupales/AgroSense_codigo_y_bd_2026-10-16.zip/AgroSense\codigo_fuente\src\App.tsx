import { Navigate, Outlet, Route, Routes } from 'react-router-dom'

import { useAuth } from '@/auth/AuthContext'
import { AuthShell } from '@/components/auth/AuthShell'
import { AppLayout } from '@/layouts/AppLayout'
import { AnalysisPage } from '@/pages/AnalysisPage'
import { ConfigurationPage } from '@/pages/ConfigurationPage'
import { ForgotPasswordPage } from '@/pages/ForgotPasswordPage'
import { HistoryPage } from '@/pages/HistoryPage'
import { IrrigationPage } from '@/pages/IrrigationPage'
import { PrivacyPage, TermsPage } from '@/pages/LegalPages'
import { LoginPage } from '@/pages/LoginPage'
import { RegisterPage } from '@/pages/RegisterPage'
import { ResetPasswordPage } from '@/pages/ResetPasswordPage'
import { SensorsPage } from '@/pages/SensorsPage'
import { SummaryPage } from '@/pages/SummaryPage'
import { LoadingState } from '@/components/ui/States'

function RequireAuth() {
  const { user, loading } = useAuth()
  if (loading) return <LoadingState label="Verificando sesión..." />
  if (!user) return <Navigate to="/login" replace />
  return <Outlet />
}

function GuestRoute() {
  const { user, loading } = useAuth()
  if (loading) return <LoadingState label="Verificando sesión..." />
  if (user) return <Navigate to="/" replace />
  return (
    <AuthShell>
      <Outlet />
    </AuthShell>
  )
}

export default function App() {
  return (
    <Routes>
      <Route element={<GuestRoute />}>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/registro" element={<RegisterPage />} />
        <Route path="/recuperar" element={<ForgotPasswordPage />} />
        <Route path="/restablecer" element={<ResetPasswordPage />} />
        <Route path="/terminos" element={<TermsPage />} />
        <Route path="/privacidad" element={<PrivacyPage />} />
      </Route>

      <Route element={<RequireAuth />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<SummaryPage />} />
          <Route path="/sensores" element={<SensorsPage />} />
          <Route path="/riego" element={<IrrigationPage />} />
          <Route path="/historial" element={<HistoryPage />} />
          <Route path="/analisis" element={<AnalysisPage />} />
          <Route path="/configuracion" element={<ConfigurationPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Route>
    </Routes>
  )
}
