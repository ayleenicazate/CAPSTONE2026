﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AgroSense.Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class AddSpectralAndAirQuality : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AirQualityRaw",
                table: "readings",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "AirQualityVoltage",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SoilRaw",
                table: "readings",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralBlue",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralGreen",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralOrange",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralRed",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralTotal",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralViolet",
                table: "readings",
                type: "double precision",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "SpectralYellow",
                table: "readings",
                type: "double precision",
                nullable: true);

            // Reinicia la lectura incremental de Firebase: el worker vuelve a recorrer las lecturas
            // y completa las ya guardadas con los campos nuevos (sin duplicarlas).
            migrationBuilder.Sql("DELETE FROM ingestion_cursors;");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AirQualityRaw",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "AirQualityVoltage",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SoilRaw",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralBlue",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralGreen",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralOrange",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralRed",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralTotal",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralViolet",
                table: "readings");

            migrationBuilder.DropColumn(
                name: "SpectralYellow",
                table: "readings");
        }
    }
}
