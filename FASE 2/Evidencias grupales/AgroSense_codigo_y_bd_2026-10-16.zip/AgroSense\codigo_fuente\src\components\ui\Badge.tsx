import type { PropsWithChildren } from 'react'

import type { StatusTone } from '@/types/api'

const toneClassMap: Record<StatusTone, string> = {
  normal: 'bg-emerald-50 text-emerald-700',
  warning: 'bg-amber-50 text-amber-700',
  info: 'bg-sky-50 text-sky-700',
  neutral: 'bg-slate-100 text-slate-600',
  success: 'bg-green-100 text-green-700',
}

interface BadgeProps extends PropsWithChildren {
  tone?: StatusTone
}

export function Badge({ children, tone = 'normal' }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${toneClassMap[tone]}`}
    >
      {children}
    </span>
  )
}
