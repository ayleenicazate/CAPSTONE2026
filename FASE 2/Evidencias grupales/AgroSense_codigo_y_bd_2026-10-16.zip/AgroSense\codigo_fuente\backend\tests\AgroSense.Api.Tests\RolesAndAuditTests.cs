using AgroSense.Api.Data;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Stations;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;

namespace AgroSense.Api.Tests;

public class RolesAndAuditTests
{
    private static (AgroSenseDbContext Db, StationService Stations, Station Station) Setup()
    {
        var db = new AgroSenseDbContext(new DbContextOptionsBuilder<AgroSenseDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options);
        var station = new Station { Code = "test-01", Name = "Test" };
        db.Stations.Add(station);
        db.SaveChanges();
        var service = new StationService(db, Options.Create(new StationOptions()), new FakeTimeProvider());
        return (db, service, station);
    }

    private static User NewUser(AgroSenseDbContext db, string name)
    {
        var user = new User { Name = name, Email = $"{name.ToLowerInvariant()}@test.cl" };
        db.Users.Add(user);
        db.SaveChanges();
        return user;
    }

    [Fact]
    public async Task First_member_is_admin_and_the_rest_are_viewers()
    {
        var (db, stations, station) = Setup();
        var ana = await stations.AddMemberAsync(NewUser(db, "Ana"), station);
        var beto = await stations.AddMemberAsync(NewUser(db, "Beto"), station);

        Assert.Equal(StationRoles.Admin, ana!.Role);
        Assert.Equal(StationRoles.Viewer, beto!.Role);
    }

    [Fact]
    public async Task Adding_an_existing_member_again_does_nothing()
    {
        var (db, stations, station) = Setup();
        var ana = NewUser(db, "Ana");
        await stations.AddMemberAsync(ana, station);
        Assert.Null(await stations.AddMemberAsync(ana, station));
        Assert.Equal(1, await db.StationMembers.CountAsync());
    }

    [Fact]
    public async Task Membership_lookup_returns_role_only_for_members()
    {
        var (db, stations, station) = Setup();
        var ana = NewUser(db, "Ana");
        var outsider = NewUser(db, "Carla");
        await stations.AddMemberAsync(ana, station);

        Assert.Equal(StationRoles.Admin, (await stations.FindMembershipAsync(station.Id, ana.Id))?.Role);
        Assert.Null(await stations.FindMembershipAsync(station.Id, outsider.Id));
    }

    [Fact]
    public void Diff_lists_only_changed_fields_in_readable_form()
    {
        var changes = AuditService.Diff(
            ("Riego automático", true, false),
            ("Umbral de activación (%)", 30.0, 25.5),
            ("Umbral de desactivación (%)", 60.0, 60.0));

        Assert.Equal(["Riego automático: sí → no", "Umbral de activación (%): 30 → 25,5"], changes);
    }
}
