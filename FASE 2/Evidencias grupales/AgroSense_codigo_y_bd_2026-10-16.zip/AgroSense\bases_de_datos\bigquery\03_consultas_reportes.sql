-- @q1
SELECT estacion, origen, COUNT(*) AS dias, SUM(lecturas) AS lecturas, MIN(dia) AS desde, MAX(dia) AS hasta
FROM `agrosense-a1b2c.agrosense.reporte_resumen_diario`
GROUP BY estacion, origen
ORDER BY estacion, origen;
-- @q2
SELECT DATETIME(ts, 'America/Santiago') AS hora, temperature, air_humidity, soil_moisture, soil_raw,
       air_quality_voltage, light_total, pump_on, pump_mode
FROM `agrosense-a1b2c.agrosense.readings`
WHERE station_code = 'agrosense-01' AND soil_raw IS NOT NULL
ORDER BY ts DESC
LIMIT 50;
-- @q3
SELECT dia, estacion, lecturas, temp_prom_c, temp_min_c, temp_max_c, humedad_aire_prom, humedad_suelo_prom, riegos, minutos_riego
FROM `agrosense-a1b2c.agrosense.reporte_resumen_diario`
ORDER BY dia DESC, estacion;
-- @q4
SELECT hora_del_dia, ROUND(AVG(temperatura_c), 1) AS temperatura, ROUND(AVG(humedad_aire_pct), 1) AS humedad_aire,
       ROUND(AVG(luz_total), 0) AS luz
FROM `agrosense-a1b2c.agrosense.reporte_lecturas_hora`
WHERE estacion = 'simulador-01'
GROUP BY hora_del_dia
ORDER BY hora_del_dia;
-- @q5
SELECT inicio, estacion, origen, modo, duracion_s, suelo_antes_pct, suelo_despues_pct, aumento_suelo_pct
FROM `agrosense-a1b2c.agrosense.reporte_riegos`
ORDER BY inicio DESC;
-- @q6
SELECT CORR(temperatura_c, humedad_aire_pct) AS corr_temp_humedad,
       CORR(temperatura_c, luz_total) AS corr_temp_luz
FROM `agrosense-a1b2c.agrosense.reporte_lecturas_hora`
WHERE estacion = 'simulador-01';
-- @q7
SELECT variable, hora, valor, minimo, maximo
FROM `agrosense-a1b2c.agrosense.reporte_prediccion`
WHERE variable = 'Temperatura (C)'
ORDER BY hora;
-- @q8
SELECT station_code, non_seasonal_p, non_seasonal_d, non_seasonal_q, has_drift, log_likelihood, AIC, variance, seasonal_periods
FROM ML.ARIMA_EVALUATE(MODEL `agrosense-a1b2c.agrosense.forecast_temperature`);
-- @q9
SELECT COUNT(*) AS lecturas_exportadas, MAX(DATETIME(received_at, 'America/Santiago')) AS ultima_exportada
FROM `agrosense-a1b2c.agrosense.readings`;
