import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

import { Card } from '@/components/ui/Card'
import { EmptyState } from '@/components/ui/States'
import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatDateTime, formatNumber } from '@/lib/format'
import type { SpectralPoint } from '@/types/api'

// Los colores representan el color físico de cada banda; cada fila tiene su etiqueta (no se depende del color).
const BANDS: Array<{ key: keyof Omit<SpectralPoint, 'timestamp'>; label: string; nm: number; color: string }> = [
  { key: 'violet', label: 'Violeta', nm: 450, color: '#8b5cf6' },
  { key: 'blue', label: 'Azul', nm: 500, color: '#3b82f6' },
  { key: 'green', label: 'Verde', nm: 550, color: '#22c55e' },
  { key: 'yellow', label: 'Amarillo', nm: 570, color: '#eab308' },
  { key: 'orange', label: 'Naranja', nm: 600, color: '#f97316' },
  { key: 'red', label: 'Rojo', nm: 650, color: '#ef4444' },
]

/** Evolución de cada banda del AS7262 (múltiplos pequeños con la misma escala para comparar intensidades). */
export function SpectralSeriesChart({ data, hours }: { data: SpectralPoint[]; hours: number }) {
  const points = data.map((p) => ({ ...p, t: new Date(p.timestamp).getTime() }))
  const max = Math.max(1, ...data.flatMap((p) => BANDS.map((b) => p[b.key] ?? 0)))

  return (
    <Card>
      <h3 className="text-lg font-semibold text-slate-800">Espectro en el tiempo</h3>
      <p className="mb-4 text-sm text-slate-500">
        Intensidad de cada color en las últimas {hours} h (µW/cm², misma escala en todas las filas).
      </p>
      {points.length < 2 ? (
        <EmptyState>Aún no hay suficientes lecturas del AS7262.</EmptyState>
      ) : (
        <div className="space-y-1">
          {BANDS.map((band) => (
            <div key={band.key} className="grid grid-cols-[96px_minmax(0,1fr)_56px] items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-medium text-slate-700">{band.label}</p>
                <p className="text-[11px] text-slate-400">{band.nm} nm</p>
              </div>
              <div className="h-10">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={points} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
                    <XAxis dataKey="t" type="number" scale="time" domain={['dataMin', 'dataMax']} hide />
                    <YAxis hide domain={[0, max]} />
                    <Tooltip
                      {...tooltipStyle}
                      cursor={{ stroke: chart.axis, strokeDasharray: '3 3' }}
                      labelFormatter={(t) => formatDateTime(new Date(Number(t)).toISOString())}
                      formatter={(value: number) => [`${formatNumber(value, 1)} µW/cm²`, band.label]}
                    />
                    <Area
                      type="monotone"
                      dataKey={band.key}
                      stroke={band.color}
                      strokeWidth={1.5}
                      fill={band.color}
                      fillOpacity={0.25}
                      connectNulls
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <p className="text-right text-sm tabular-nums text-slate-600">{formatNumber(data.at(-1)?.[band.key] ?? null, 0)}</p>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
