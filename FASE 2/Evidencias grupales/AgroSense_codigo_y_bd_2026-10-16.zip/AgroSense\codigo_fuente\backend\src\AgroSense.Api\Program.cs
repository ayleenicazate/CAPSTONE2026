using System.Threading.RateLimiting;
using AgroSense.Api.Auth;
using AgroSense.Api.Data;
using AgroSense.Api.DataExport;
using AgroSense.Api.Firebase;
using AgroSense.Api.Infrastructure;
using AgroSense.Api.Ingestion;
using AgroSense.Api.Notifications;
using AgroSense.Api.Stations;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);
var config = builder.Configuration;

builder.Services.Configure<JwtOptions>(config.GetSection(JwtOptions.Section));
builder.Services.Configure<FirebaseOptions>(config.GetSection(FirebaseOptions.Section));
builder.Services.Configure<StationOptions>(config.GetSection(StationOptions.Section));
builder.Services.Configure<DeviceIngestOptions>(config.GetSection(DeviceIngestOptions.Section));
builder.Services.Configure<SeedOptions>(config.GetSection(SeedOptions.Section));
builder.Services.Configure<AppOptions>(config.GetSection(AppOptions.Section));
builder.Services.Configure<RetentionOptions>(config.GetSection(RetentionOptions.Section));
builder.Services.Configure<BigQueryOptions>(config.GetSection(BigQueryOptions.Section));
builder.Services.Configure<TelegramOptions>(config.GetSection(TelegramOptions.Section));
builder.Services.Configure<SmtpOptions>(config.GetSection(SmtpOptions.Section));

builder.Services.AddDbContext<AgroSenseDbContext>(options =>
    options.UseNpgsql(config.GetConnectionString("Postgres")));

// ---- Autenticación JWT
var jwt = config.GetSection(JwtOptions.Section).Get<JwtOptions>() ?? new JwtOptions();
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidIssuer = jwt.Issuer,
            ValidAudience = jwt.Audience,
            IssuerSigningKey = TokenService.GetSigningKey(jwt),
            ClockSkew = TimeSpan.FromMinutes(1),
        };
    });
builder.Services.AddAuthorization();

// Detrás del proxy (Caddy) la IP real del cliente llega en X-Forwarded-For.
// La API no expone su puerto fuera de la red de Docker, así que se confía en el proxy.
builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
    options.KnownIPNetworks.Clear();
    options.KnownProxies.Clear();
});

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("auth", http => RateLimitPartition.GetFixedWindowLimiter(
        http.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        _ => new FixedWindowRateLimiterOptions { PermitLimit = 20, Window = TimeSpan.FromMinutes(1) }));
});

var corsOrigins = config.GetSection($"{AppOptions.Section}:CorsOrigins").Get<string[]>() ?? [];
builder.Services.AddCors(options => options.AddDefaultPolicy(policy =>
    policy.WithOrigins(corsOrigins).AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddProblemDetails();
builder.Services.AddOpenApi();
builder.Services.AddSingleton(TimeProvider.System);

// ---- Servicios de dominio
builder.Services.AddSingleton<IPasswordHasher<User>, PasswordHasher<User>>();
builder.Services.AddSingleton<TokenService>();
// Correo real si hay SMTP configurado; si no, los correos solo se escriben en el log.
if (config.GetSection(SmtpOptions.Section).Get<SmtpOptions>() is { Enabled: true })
    builder.Services.AddSingleton<IEmailSender, SmtpEmailSender>();
else
    builder.Services.AddSingleton<IEmailSender, LoggingEmailSender>();
builder.Services.AddScoped<StationService>();
builder.Services.AddScoped<DashboardService>();
builder.Services.AddScoped<IngestionService>();
builder.Services.AddScoped<RollupService>();
builder.Services.AddSingleton<LiveBroadcaster>();
builder.Services.AddScoped<DataSeeder>();
builder.Services.AddScoped<AuditService>();

// ---- Notificaciones (Telegram y correo) y alertas
builder.Services.AddHttpClient<TelegramClient>(client => client.Timeout = TimeSpan.FromSeconds(40));
builder.Services.AddScoped<Notifier>();
builder.Services.AddHostedService<TelegramBotWorker>();
builder.Services.AddHostedService<AlertMonitor>();

// ---- Firebase Realtime Database
builder.Services.AddHttpClient<FirebaseRtdbClient>(client => client.Timeout = TimeSpan.FromSeconds(20));
builder.Services.AddScoped<IDeviceConfigPublisher, FirebaseDeviceConfigPublisher>();
builder.Services.AddHostedService<FirebaseIngestionWorker>();

// ---- Analítica: BigQuery (histórico completo) y retención de lecturas crudas
builder.Services.AddSingleton<BigQueryClientFactory>();
builder.Services.AddHostedService<BigQueryExporter>();
builder.Services.AddHostedService<BigQueryMlService>();
builder.Services.AddScoped<AnalyticsService>();
builder.Services.AddMemoryCache();
builder.Services.AddHostedService<RetentionWorker>();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    await scope.ServiceProvider.GetRequiredService<DataSeeder>().RunAsync();
}

app.UseForwardedHeaders();

app.UseExceptionHandler(new ExceptionHandlerOptions
{
    // JSON mal formado o parámetros inválidos son errores del cliente, no del servidor.
    StatusCodeSelector = ex => ex is BadHttpRequestException bad ? bad.StatusCode : StatusCodes.Status500InternalServerError,
});
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference("/docs", options => options.WithTitle("AgroSense API"));
}

app.UseCors();
app.UseRateLimiter();
app.UseAuthentication();
app.UseAuthorization();

app.MapGet("/api/health", async (AgroSenseDbContext db, FirebaseRtdbClient firebase) => Results.Ok(new
{
    status = "ok",
    database = await db.Database.CanConnectAsync(),
    firebase = firebase.Enabled,
})).AllowAnonymous().WithTags("Sistema");

app.MapAuthEndpoints();
app.MapStationEndpoints();
app.MapDeviceEndpoints();
app.MapSystemEndpoints();

app.Run();

public partial class Program;
