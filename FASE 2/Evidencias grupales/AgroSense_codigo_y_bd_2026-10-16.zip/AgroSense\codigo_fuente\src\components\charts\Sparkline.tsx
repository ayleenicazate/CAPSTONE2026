import { Line, LineChart, ResponsiveContainer, Tooltip, YAxis } from 'recharts'

import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatTime, formatValue } from '@/lib/format'
import type { Point } from '@/types/api'

interface SparklineProps {
  data: Point[]
  unit: string
  height?: number
  color?: string
  digits?: number
}

/** Mini gráfico de la última hora para las tarjetas de métricas (sin ejes; con tooltip al pasar el mouse). */
export function Sparkline({ data, unit, height = 36, color = chart.series, digits = 1 }: SparklineProps) {
  if (data.length < 2) return <div style={{ height }} />

  return (
    <div style={{ height }} aria-hidden="true">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 4, right: 2, left: 2, bottom: 2 }}>
          <YAxis hide domain={['dataMin', 'dataMax']} />
          <Tooltip
            {...tooltipStyle}
            cursor={{ stroke: chart.axis, strokeDasharray: '3 3' }}
            labelFormatter={(_, payload) => (payload?.[0] ? formatTime(payload[0].payload.timestamp) : '')}
            formatter={(value: number) => [formatValue(value, unit, digits), '']}
            separator=""
          />
          <Line type="monotone" dataKey="value" stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
