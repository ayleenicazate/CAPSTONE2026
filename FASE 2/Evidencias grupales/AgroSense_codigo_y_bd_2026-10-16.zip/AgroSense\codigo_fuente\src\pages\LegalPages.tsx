import { Link } from 'react-router-dom'

import { AuthCard, BrandMark } from '@/components/auth/AuthShell'

function LegalCard({ title, children }: { title: string; children: string }) {
  return (
    <AuthCard>
      <BrandMark />
      <h2 className="mt-5 text-[1.65rem] font-bold tracking-tight text-slate-900">{title}</h2>
      <p className="mt-4 text-sm leading-relaxed text-slate-600">{children}</p>
      <p className="mt-6 text-center text-sm text-slate-500">
        <Link to="/registro" className="font-semibold text-[#1a7a3a] hover:underline">
          Volver al registro
        </Link>
      </p>
    </AuthCard>
  )
}

export function TermsPage() {
  return (
    <LegalCard title="Términos de servicio">
      AgroSense es un panel demostrativo de la estación agroambiental. Al crear una cuenta aceptas usar la plataforma
      para consultar sensores, riego e historial de tu estación, y mantener la confidencialidad de tus credenciales.
    </LegalCard>
  )
}

export function PrivacyPage() {
  return (
    <LegalCard title="Política de privacidad">
      Guardamos tu nombre, correo y las estaciones que vinculas en la base de datos de AgroSense. La contraseña se
      almacena cifrada (hash) y nunca en texto plano. Las mediciones de la estación se usan solo para mostrar el
      monitoreo, el historial y las estimaciones de riego. No compartimos estos datos con terceros.
    </LegalCard>
  )
}