import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

import { Card } from '@/components/ui/Card'
import { chart, tooltipStyle } from '@/lib/chartTheme'
import { formatNumber } from '@/lib/format'

interface DailyBarChartProps {
  title: string
  subtitle?: string
  data: Array<{ date: string; liters: number; count: number; minutes: number }>
}

/** Agua estimada por día (una sola serie: sin leyenda, el título la nombra). */
export function DailyBarChart({ title, subtitle, data }: DailyBarChartProps) {
  const points = data.map((d) => ({
    ...d,
    label: new Date(`${d.date}T12:00:00`).toLocaleDateString('es-CL', { day: '2-digit', month: 'short' }),
  }))
  const total = data.reduce((sum, d) => sum + d.liters, 0)

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-1 md:flex-row md:items-start md:justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-800">{title}</h3>
          {subtitle ? <p className="text-sm text-slate-500">{subtitle}</p> : null}
        </div>
        <p className="text-sm text-slate-500">
          Total: <span className="font-semibold text-slate-800">{formatNumber(total)} L</span>
        </p>
      </div>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={points} margin={{ top: 8, right: 8, left: -8, bottom: 0 }} barCategoryGap={4}>
            <CartesianGrid stroke={chart.grid} strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="label" axisLine={false} tickLine={false} interval="preserveStartEnd" tick={{ fill: chart.axis, fontSize: 11 }} />
            <YAxis axisLine={false} tickLine={false} width={48} tick={{ fill: chart.axis, fontSize: 12 }} tickFormatter={(v: number) => `${v} L`} />
            <Tooltip
              {...tooltipStyle}
              cursor={{ fill: '#f1f5f9' }}
              formatter={(value: number, _name, item) => [
                `${formatNumber(value)} L · ${item.payload.count} riego${item.payload.count === 1 ? '' : 's'} · ${formatNumber(item.payload.minutes)} min`,
                'Agua estimada',
              ]}
            />
            <Bar dataKey="liters" fill={chart.water} radius={[4, 4, 0, 0]} maxBarSize={36} isAnimationActive={false} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
