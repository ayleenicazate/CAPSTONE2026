import { useEffect, useMemo, useRef, useState } from 'react'

import { apiBaseUrl, getToken } from '@/services/api'
import { useLiveQuery } from '@/services/queries'
import type { LiveReading, StationInfo } from '@/types/api'

export type LiveStatus = 'connecting' | 'live' | 'polling'

const RETRY_DELAYS_MS = [2_000, 5_000, 10_000, 30_000]

/**
 * Lecturas en tiempo real de una estación.
 * 1. Carga las lecturas de los últimos `windowMinutes` (endpoint /live).
 * 2. Abre un canal Server-Sent Events (/stream) por el que el servidor empuja cada lectura nueva al instante.
 * 3. Si el canal se cae, reintenta con espera creciente y mientras tanto consulta /live periódicamente.
 */
export function useLiveStream(station: StationInfo, windowMinutes: number) {
  const [status, setStatus] = useState<LiveStatus>('connecting')
  const [pushed, setPushed] = useState<LiveReading[]>([])
  const pollMs = Math.max(2, Math.min(station.readingIntervalSeconds, 10)) * 1000
  // Con el canal activo, /live solo resincroniza cada minuto.
  const { data } = useLiveQuery(station.id, windowMinutes, status === 'live' ? 60_000 : pollMs)
  const attempt = useRef(0)

  useEffect(() => {
    setPushed([])
    setStatus('connecting')
    const controller = new AbortController()
    let retryTimer: ReturnType<typeof setTimeout> | undefined

    const connect = async () => {
      try {
        const response = await fetch(`${apiBaseUrl}/stations/${station.id}/stream`, {
          headers: { Authorization: `Bearer ${getToken() ?? ''}`, Accept: 'text/event-stream' },
          signal: controller.signal,
        })
        if (!response.ok || !response.body) throw new Error(`stream ${response.status}`)

        const reader = response.body.pipeThrough(new TextDecoderStream()).getReader()
        let buffer = ''
        while (true) {
          const { value, done } = await reader.read()
          if (done) break
          buffer += value
          let separator: number
          while ((separator = buffer.indexOf('\n\n')) >= 0) {
            const rawEvent = buffer.slice(0, separator)
            buffer = buffer.slice(separator + 2)
            handleEvent(rawEvent)
          }
        }
        throw new Error('stream cerrado')
      } catch {
        if (controller.signal.aborted) return
        setStatus('polling')
        const delay = RETRY_DELAYS_MS[Math.min(attempt.current, RETRY_DELAYS_MS.length - 1)]
        attempt.current += 1
        retryTimer = setTimeout(() => void connect(), delay)
      }
    }

    const handleEvent = (rawEvent: string) => {
      const lines = rawEvent.split('\n')
      const event = lines.find((l) => l.startsWith('event:'))?.slice(6).trim()
      const payload = lines
        .filter((l) => l.startsWith('data:'))
        .map((l) => l.slice(5).trim())
        .join('\n')
      if (event === 'ready') {
        attempt.current = 0
        setStatus('live')
        return
      }
      if (!payload) return // comentario de "ping"
      try {
        const reading = JSON.parse(payload) as LiveReading
        setPushed((previous) => [...previous.slice(-2000), reading])
      } catch {
        // evento malformado: se ignora
      }
    }

    void connect()
    return () => {
      controller.abort()
      if (retryTimer) clearTimeout(retryTimer)
    }
  }, [station.id])

  // Une lo cargado por /live con lo recibido por el canal, sin duplicados y en orden.
  const readings = useMemo(() => {
    const byTime = new Map<string, LiveReading>()
    for (const r of data?.readings ?? []) byTime.set(r.timestamp, r)
    for (const r of pushed) byTime.set(r.timestamp, r)
    return [...byTime.values()].sort((a, b) => a.timestamp.localeCompare(b.timestamp))
  }, [data, pushed])

  const latest = readings.at(-1) ?? data?.latest ?? null
  return { readings, latest, status }
}
